# TOOLS.md

## Purpose

This file describes how tools are registered, granted, invoked, observed, and revoked.

A tool is not merely a capability. It is a permissioned interface that can change the world, read the world, or alter memory.

## Tool categories

### Read tools
Search, retrieval, file reads, logs, metrics, memory queries.

### Write tools
File writes, issue creation, PRs, database updates, notes, alerts.

### Execute tools
Shell execution, deployment, workflow triggers, remote tasks, browser automation.

### Communication tools
Email, chat posting, webhook dispatch, queue publication.

## Tool contract schema

```yaml
tool_id: string
name: string
category: read|write|execute|communicate
surface: api|cli|browser|webhook|queue|filesystem
owner: string
allowed_agents: [string]
side_effects: [string]
required_secrets: [string]
rate_limit: string
observability:
  logs: boolean
  traces: boolean
  replayable: boolean
rollback: manual|automatic|none
```

## Tool grant rules

- No tool is implicitly inherited unless declared in the child contract.
- High-side-effect tools require explicit grant.
- Browser automation is allowed only on user-owned or authorized sessions.
- Provider-specific adapters must use official, permitted surfaces where available.

## Tool invocation record

Every tool use should emit:
- who called it,
- why,
- with what arguments,
- what changed,
- whether it succeeded,
- whether rollback is possible.

## Tool quality gates

A tool is considered production-grade only if it is:
- observable,
- rate-limited,
- replayable or at least auditable,
- revocable,
- bounded by permissions.
