# CHRONICLE.md

## Purpose

This file defines the temporal self-log format.

A chronicle entry is the durable answer to:
- what happened,
- why it mattered,
- what changed,
- what remains unresolved,
- what the system now believes or refuses.

## Entry schema

```yaml
entry_id: string
timestamp: string
agent_id: string
event_type: string
summary: string
causal_trigger: string
artifacts: [string]
state_change:
  before: object
  after: object
unresolved: [string]
```

## Chronicle quality

A good chronicle entry should be short, causal, and reusable.
