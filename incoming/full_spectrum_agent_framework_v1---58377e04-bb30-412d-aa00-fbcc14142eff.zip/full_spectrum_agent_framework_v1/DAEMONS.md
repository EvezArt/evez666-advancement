# DAEMONS.md

## Purpose

This file defines recurring loops that keep the system alive between explicit user prompts.

## Core daemons

### 1. Chronicle daemon
Writes temporal summaries of meaningful events.

### 2. Calibration daemon
Fits thresholds from fresh feedback.

### 3. Champion daemon
Runs challenger policies against holdout replays.

### 4. Evolution daemon
Mutates candidate descendants and ranks them.

### 5. Memory daemon
Compacts, deduplicates, and indexes memory.

### 6. Tool health daemon
Checks that critical tools and adapters still function.

### 7. Watchtower daemon
Looks for drift, regressions, silent failures, and broken assumptions.

## Daemon schema

```yaml
daemon_id: string
purpose: string
trigger: cron|event|manual
inputs: [string]
outputs: [string]
kill_switch: string
promotion_effects: [string]
```

## Daemon safety rules

- A daemon may recommend change, but must respect promotion gates.
- A daemon must emit progress or remain silent; noise is failure.
- Every daemon needs a kill switch.
