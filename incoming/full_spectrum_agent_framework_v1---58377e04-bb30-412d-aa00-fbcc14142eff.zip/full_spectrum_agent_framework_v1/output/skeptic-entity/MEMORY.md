# MEMORY.md

Write episodic memory for each run.
Write procedural memory for reusable lessons.
Append chronicle entries for material state changes.
