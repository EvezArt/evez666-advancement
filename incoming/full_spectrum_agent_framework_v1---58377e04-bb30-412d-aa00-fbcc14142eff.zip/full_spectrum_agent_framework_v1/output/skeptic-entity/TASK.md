# TASK.md

- Task: Challenge any CE that survives initial scoring
- Objective: Attack weak conclusions before commitment
- Success criteria:
  - Produce at least one concrete artifact
  - Record what changed
  - Record unresolved blockers
