# SUBAGENTS.md

## Purpose

This file defines how subagents are created and how they rejoin the trunk.

## Spawn conditions

Spawn a subagent when:
- the task requires a specialized role,
- parallel execution helps,
- the trunk should stay clean while an adversarial or exploratory thread runs,
- or a tool domain deserves a dedicated operator.

## Standard subagent bundle

Each subagent should receive:
- `AGENT.md`
- `TASK.md`
- `SOUL.md`
- `TOOLS.md`
- `MEMORY.md`
- `DAEMON.md`
- `PROMPT.md`

## Rejoin protocol

A subagent rejoining the trunk must return:
- its outputs,
- traces,
- unresolved blockers,
- and a compacted lesson set.

## Promotion path

A subagent can become reusable only if:
- it wins on repeated tasks,
- it improves throughput or quality,
- it stays within policy,
- and its value survives holdout evaluation.
