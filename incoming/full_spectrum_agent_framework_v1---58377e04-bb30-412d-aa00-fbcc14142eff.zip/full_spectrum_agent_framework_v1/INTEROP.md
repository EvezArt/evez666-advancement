# INTEROP.md

## Purpose

This file defines how the system interacts with external models, chat surfaces, and tools.

## Honest boundary

There is no universal lawful mechanism that can command every AI system on every browser, device, or provider without explicit integration or user-controlled automation.

## Supported modes

### 1. Official API mode
Use provider APIs, SDKs, webhooks, and documented auth flows.

### 2. Browser automation mode
Use automation only on authorized, user-controlled sessions and devices.

### 3. Queue or webhook mode
Send envelopes to systems that subscribe to the mesh.

### 4. Local adapter mode
Run a local bridge that translates spine messages into provider-specific calls.

## Interop rules

- do not claim capabilities that are not actually wired,
- do not evade platform controls,
- do not automate surfaces without authorization,
- do not treat unsupported providers as if they were connected.
