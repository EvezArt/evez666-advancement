# POLICY.md

## Sensory Entity Proof Grammar & Invariance Policy

A Cognitive Event (CE) becomes action only after it survives the battery.

## Battery

1. Time Shift
2. State Shift
3. Frame Shift
4. Adversarial Shift
5. Identity / Goal Shift

## Defeater rules

- Failure on any required shift defeats action.
- Test results themselves must be stress-tested.
- Identity roots are not silently rewritten.

## Commitment outcomes

- `ACT`
- `HOLD`
- `TEST`
- `DISCARD`

## Promotion gates

No policy change is adopted without:
- replay evidence,
- holdout comparison,
- regression checks,
- lineage log,
- explainability artifact.
