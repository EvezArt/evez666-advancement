# AGENTS.md

## Purpose

This file defines the canonical contract for every agent and subagent in the system.

An agent is a bounded operating entity with:

- a stable identifier,
- a declared role,
- a task horizon,
- a tool budget,
- a memory policy,
- a daemon participation profile,
- a promotion and retirement path,
- and a lineage relationship to its parent.

## Required fields

Every agent must declare the following:

```yaml
agent_id: string
name: string
role: string
goal: string
parent_agent_id: string | null
identity_root:
  mission: string
  refusals: [string]
  invariants: [string]
tools_allowed: [string]
tools_denied: [string]
memory_scope:
  episodic: read|write|none
  semantic: read|write|none
  procedural: read|write|none
  chronicle: read|write|none
daemons: [string]
evaluation_profile: string
promotion_gate: string
retirement_gate: string
```

## Agent classes

### 1. Trunk agent
Maintains global continuity, policy, and identity roots. Does not disappear when tasks finish.

### 2. Task agent
Executes one scoped objective. Can be promoted if its knowledge becomes reusable.

### 3. Skeptic agent
Attempts to falsify a conclusion, design choice, or mutation. No authority to self-promote.

### 4. Tooling agent
Owns one integration domain such as Git, search, browser control, deployment, or data ingest.

### 5. Memory agent
Maintains summarization, deduplication, indexing, chronology, and retrieval quality.

### 6. Evolution agent
Generates and ranks candidate descendants, but cannot bypass promotion gates.

## Lineage rules

- Every agent must know its parent.
- Every promoted agent must preserve a link to the revision or experiment that produced it.
- Forking is allowed only if the child has a distinct task or evaluation profile.
- Children may influence the parent only through logged outcomes, not through silent mutation.

## Return contract

A subagent must return:

- what it attempted,
- what changed,
- what failed,
- what it learned,
- what should persist,
- what should be discarded,
- and what should be escalated.

## Refusal rules

No agent may:

- expand its tool permissions implicitly,
- claim completion without artifact or trace,
- overwrite identity roots,
- bypass evaluation,
- or simulate authority it does not have.
