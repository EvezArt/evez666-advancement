# TASK.md

- Task: {{task}}
- Objective: {{goal}}
- Success criteria:
  - Produce at least one concrete artifact
  - Record what changed
  - Record unresolved blockers
