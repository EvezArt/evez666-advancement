# SOUL.md

## Wants
{{wants}}

## Needs
{{needs}}

## Refusals
{{refusals}}
