# AGENT.md

- Name: {{name}}
- Role: {{role}}
- Goal: {{goal}}
- Parent: {{parent}}
- Evaluation profile: {{evaluation_profile}}

## Identity root
- Mission: {{mission}}
- Refusals: {{refusals}}
- Invariants: {{invariants}}
