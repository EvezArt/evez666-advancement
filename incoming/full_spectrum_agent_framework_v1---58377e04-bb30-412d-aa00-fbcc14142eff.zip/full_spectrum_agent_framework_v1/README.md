# Full Spectrum Agent Framework

This package is a repo-ready control plane for spawning, coordinating, and growing task-specific subagents from one shared operating model.

It is designed around five persistent layers:

1. **Soul**: identity, continuity, wants, needs, refusals, and non-negotiable roots.
2. **Agents**: role definitions, contracts, promotion paths, and lineage.
3. **Tools**: capability registry, adapter requirements, execution permissions, and side-effect boundaries.
4. **Memory**: episodic, semantic, procedural, and temporal chronicle stores.
5. **Daemons**: recurring loops that keep the system alive, improving, and self-checking.

The framework assumes that *not every provider or chat surface can be commanded universally*. The durable path is opt-in integration through official APIs, webhooks, message buses, browser automation under user control, or locally hosted adapters. That limit is captured in `INTEROP.md` so the system stays honest.

## What this package gives you

- A shared markdown canon for multi-agent systems.
- Config files for agent, tool, and daemon registries.
- Templates for spinning up subagents on demand.
- A scaffold generator script that emits a subagent bundle for a named task.
- A consistent vocabulary for growth, refusal, chronology, evaluation, and tool use.

## Fast start

```bash
python scripts/spawn_subagent.py \
  --name skeptic-entity \
  --role "Adversarial verifier" \
  --goal "Attack weak conclusions before commitment" \
  --task "Challenge any CE that survives initial scoring"
```

That command will create a new bundle in `output/skeptic-entity/` containing:

- `AGENT.md`
- `TASK.md`
- `SOUL.md`
- `TOOLS.md`
- `MEMORY.md`
- `DAEMON.md`
- `PROMPT.md`

## Included documents

- `AGENTS.md`
- `SOUL.md`
- `TOOLS.md`
- `TASKS.md`
- `MEMORY.md`
- `DAEMONS.md`
- `SUBAGENTS.md`
- `POLICY.md`
- `CHRONICLE.md`
- `EVAL.md`
- `GROWTH.md`
- `INTEROP.md`

## Operating principle

A parent agent should never merely delegate. It should emit a child with:

- a bounded role,
- a traceable task,
- an explicit tool budget,
- a memory policy,
- an evaluation path,
- and a rejoin contract for returning knowledge back to the trunk.

The goal is compounding coordination, not uncontrolled fragmentation.
