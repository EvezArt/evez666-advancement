# EVAL.md

## Purpose

This file defines how work is judged.

## Evaluation layers

### Online evaluation
Immediate task success, latency, artifact quality, tool correctness.

### Replay evaluation
Held-out datasets, historical scenarios, simulation batches.

### Policy evaluation
Did the new thresholds, weights, or descendants beat the incumbent without unacceptable regressions?

### System evaluation
Did the change improve the whole graph, not just one metric?

## Minimum eval bundle

Every meaningful change should have:
- one direct test,
- one replay or benchmark,
- one regression check,
- one summary artifact.
