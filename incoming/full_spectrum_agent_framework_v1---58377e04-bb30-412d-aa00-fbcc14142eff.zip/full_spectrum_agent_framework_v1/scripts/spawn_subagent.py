#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEMPLATES = ROOT / "templates"
OUTROOT = ROOT / "output"


def render(text: str, values: dict[str, str]) -> str:
    for key, value in values.items():
        text = text.replace("{{" + key + "}}", value)
    return text


def write_file(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def main() -> None:
    p = argparse.ArgumentParser(description="Spawn a subagent bundle from framework templates")
    p.add_argument("--name", required=True)
    p.add_argument("--role", required=True)
    p.add_argument("--goal", required=True)
    p.add_argument("--task", required=True)
    p.add_argument("--parent", default="trunk")
    p.add_argument("--evaluation-profile", default="baseline")
    p.add_argument("--mission", default="Preserve intent, improve autonomy, reject false certainty")
    args = p.parse_args()

    values = {
        "name": args.name,
        "role": args.role,
        "goal": args.goal,
        "task": args.task,
        "parent": args.parent,
        "evaluation_profile": args.evaluation_profile,
        "mission": args.mission,
        "refusals": "- Do not fake access\n- Do not invent evidence\n- Do not bypass evaluation",
        "invariants": "- Preserve lineage\n- Preserve auditability\n- Respect identity roots",
        "wants": "- Reduce ambiguity\n- Increase task survival\n- Return reusable knowledge",
        "needs": "- Clear task boundary\n- Tool permissions\n- Memory continuity",
        "tools": "- files\n- chronicle",
        "daemons": "- chronicle\n- watchtower",
    }

    target = OUTROOT / args.name
    files = {
        "AGENT.md": "agent.template.md",
        "TASK.md": "task.template.md",
        "SOUL.md": "soul.template.md",
        "TOOLS.md": "tools.template.md",
        "MEMORY.md": "memory.template.md",
        "DAEMON.md": "daemon.template.md",
        "PROMPT.md": "prompt.template.md",
    }

    for out_name, tpl_name in files.items():
        tpl = (TEMPLATES / tpl_name).read_text(encoding="utf-8")
        write_file(target / out_name, render(tpl, values))

    print(f"Spawned subagent bundle at {target}")


if __name__ == "__main__":
    main()
