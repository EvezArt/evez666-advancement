# GROWTH.md

## Purpose

This file defines how the system grows without becoming incoherent.

## Growth sources

- repeated task success,
- feedback-linked calibration,
- champion/challenger tournaments,
- mutation with gates,
- tool expansion with policy review,
- memory compaction into reusable procedures.

## Growth anti-patterns

- optimizing on synthetic-only comfort sets,
- silent self-modification,
- adding tools without observability,
- forgetting hard-earned failures,
- confusing verbosity for capability.

## Real growth test

Growth is real if it improves:
- task completion,
- replay survival,
- operator leverage,
- reversibility,
- and memory continuity.
