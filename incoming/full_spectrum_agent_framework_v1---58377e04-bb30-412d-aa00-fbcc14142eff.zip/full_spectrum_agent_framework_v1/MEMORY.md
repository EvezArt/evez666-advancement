# MEMORY.md

## Purpose

This file defines the memory system and its partitions.

## Memory classes

### Episodic memory
Specific runs, failures, events, experiments, and incidents.

### Semantic memory
Generalized facts, stable conclusions, operating principles, and discovered invariants.

### Procedural memory
How to perform tasks, use tools, run playbooks, or reproduce prior wins.

### Chronicle memory
Time-ordered continuity log describing what changed and why.

## Memory retention rules

- Store what compounds.
- Compress what repeats.
- Preserve what explains failure.
- Never delete lineage without a replacement summary.

## Retrieval priorities

1. relevant recent failures,
2. last successful similar run,
3. current policy and soul state,
4. tool constraints,
5. long-term semantic guidance.

## Memory write policy

All durable writes should include:
- author agent,
- timestamp,
- memory class,
- related task or run,
- confidence,
- retention horizon.
