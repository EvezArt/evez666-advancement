# TASKS.md

## Purpose

This file defines task decomposition, claims, ownership, and completion criteria.

A task is a bounded transformation from current state to target state.

## Task schema

```yaml
task_id: string
title: string
objective: string
owner_agent_id: string
parent_task_id: string | null
inputs: [string]
artifacts_required: [string]
success_criteria: [string]
constraints: [string]
status: queued|active|blocked|done|discarded
```

## Task decomposition rules

- A parent task may spawn sub-tasks only when the decomposition reduces ambiguity or parallelizes work.
- Each sub-task must have a distinct owner.
- No task may remain active without at least one of: artifact, blocker, or progress delta.
- A task without measurable success criteria is a research thread, not an execution task.

## Completion standard

A task is done only if it has:
- an artifact,
- a trace of what changed,
- a summary of failures or unresolved edges,
- and a recommended next step.
