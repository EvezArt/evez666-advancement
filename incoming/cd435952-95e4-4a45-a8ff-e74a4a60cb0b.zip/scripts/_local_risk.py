
def score(cmd_type):
    risk_table = {
        "system.info": (0.05, False),
        "notifications.send": (0.20, False),
        "speaker.speak": (0.20, False),
        "location.get": (0.40, False),
        "screen.capture": (0.70, True),
        "microphone.listen": (0.75, True),
        "camera.capture": (0.80, True),
        "shell": (0.95, True),
        "verify": (0.0, False),
        "nodes": (0.0, False),
        "history": (0.0, False),
        "health": (0.0, False),
        "manifest": (0.0, False),
        "pending_list": (0.0, False),
        "confirm": (0.0, False),
        "reject": (0.0, False),
    }
    return risk_table.get(cmd_type, (0.50, False))
