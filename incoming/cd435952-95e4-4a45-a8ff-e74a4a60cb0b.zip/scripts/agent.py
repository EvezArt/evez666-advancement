#!/usr/bin/env python3
"""
OpenClaw + EVEZOS Task Agent v2.0
EVEZ-OS Integrated. All actions are committed to the immutable spine for verifiable cognition.
"""
from __future__ import annotations
import json, os, re, sys, time, uuid, hmac, hashlib, subprocess, threading
import urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime, timezone

# --- Config ---
GATEWAY_HOST = os.environ.get("GATEWAY_HOST", "localhost")
GATEWAY_PORT = int(os.environ.get("GATEWAY_PORT", "8888"))
AGENT_TOKEN  = os.environ.get("AGENT_TOKEN",  "devtoken")
DEFAULT_NODE = os.environ.get("AGENT_NODE",   "")
BASE_URL     = f"http://{GATEWAY_HOST}:{GATEWAY_PORT}"
WEBHOOK_SECRET = os.environ.get("GITHUB_WEBHOOK_SECRET", "")

SKILL_ROOT = Path(__file__).resolve().parents[1]
SPINE_PATH = SKILL_ROOT / "spine" / "spine.jsonl"

# --- ANSI colours ---
_TTY = sys.stdout.isatty()
def _c(code: str, text: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _TTY else text
def green(t): return _c("32",t)
def red(t): return _c("31",t)
def yellow(t): return _c("33",t)
def blue(t): return _c("34",t)
def cyan(t): return _c("36",t)
def bold(t): return _c("1",t)
def dim(t): return _c("2",t)

# --- EVEZ-OS Spine ---
def get_last_hash(path: Path) -> str:
    if not path.exists() or path.stat().st_size == 0: return "0" * 64
    with open(path, "rb") as f:
        try:
            f.seek(-2, os.SEEK_END)
            while f.read(1) != b'\n': f.seek(-2, os.SEEK_CUR)
        except OSError:
            f.seek(0)
        last_line = f.readline().decode()
    try: return json.loads(last_line).get("hash", "0" * 64)
    except (json.JSONDecodeError, IndexError): return "0" * 64

def append_spine(event_type: str, data: dict):
    SPINE_PATH.parent.mkdir(exist_ok=True)
    prev_hash = get_last_hash(SPINE_PATH)
    entry = {"ts": datetime.now(timezone.utc).isoformat(), "type": event_type, "prev_hash": prev_hash, "data": data}
    entry_str = json.dumps(entry, sort_keys=True).encode()
    entry["hash"] = hashlib.sha256(entry_str).hexdigest()
    with open(SPINE_PATH, "a") as f: f.write(json.dumps(entry) + "\n")
    return entry

# --- HTTP helpers ---
def _get(path: str) -> Dict:
    try:
        with urllib.request.urlopen(f"{BASE_URL}{path}", timeout=8) as r: return json.loads(r.read())
    except urllib.error.URLError as e: return {"ok": False, "error": str(e), "_unreachable": True}

def _post(path: str, body: Dict) -> Dict:
    data = json.dumps(body).encode()
    req = urllib.request.Request(f"{BASE_URL}{path}", data=data, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=8) as r: return json.loads(r.read())
    except urllib.error.URLError as e: return {"ok": False, "error": str(e), "_unreachable": True}

# --- Intent parser ---
_RULES: List[Tuple[str, str, Optional[int]]] = [
    (r"\b(photo|picture|camera|capture|snapshot)\b", "camera.capture", None),
    (r"\b(screenshot|screen\s*capture|screen)\b", "screen.capture", None),
    (r"\b(where\s+am\s+i|location|gps|coords?|position)\b", "location.get", None),
    (r"\b(say|speak|tts|voice|announce)\s+(.+)", "speaker.speak", 2),
    (r"\b(listen|mic|microphone|hear|record)\b.*?(\d+)\s*s", "microphone.listen_n", 2),
    (r"\b(listen|mic|microphone|hear|record)\b", "microphone.listen", None),
    (r"\b(notify|notification|alert|ping)\s*:?\s*(.+)", "notifications.send", 2),
    (r"\b(sys|system\s*info|device\s*info|info)\b", "system.info", None),
    (r"\brun\s*:?\s*(.+)", "shell", 1),
    (r"\b(verify|check\s+chain|chain\s+ok|integrity)\b", "verify", None),
    (r"\b(manifest|sign|export\s+manifest)\b", "manifest", None),
    (r"\b(pending|confirm\w*\s+list|show\s+pending)\b", "pending_list", None),
    (r"\bconfirm\s+(\S+)", "confirm", 1),
    (r"\breject\s+(\S+)", "reject", 1),
    (r"\b(nodes?|list\s+nodes?|who.s\s+connected)\b", "nodes", None),
    (r"\b(health|status|ping\s+server)\b", "health", None),
    (r"\b(history|log|events?)\b", "history", None),
    (r"\bhelp\b", "help", None),
]

def parse_intent(prompt: str) -> Tuple[str, Optional[str]]:
    text = prompt.strip(); lower = text.lower()
    for pattern, action, group in _RULES:
        m = re.search(pattern, text, re.IGNORECASE)
        if m:
            arg = m.group(group) if group is not None and len(m.groups()) >= group else None
            return action, arg
    return "unknown", text

# --- Main Action Runner ---
def _run_action(action: str, arg: Optional[str], prompt: str) -> None:
    spine_entry = {"action": action, "arg": arg, "prompt": prompt, "source": "repl" if sys.stdin.isatty() else "webhook"}
    append_spine("agent.intent.parsed", spine_entry)
    node = _first_paired_node() or "demo_node"

    if action == "health":
        r = _get("/health")
        if r.get("_unreachable"): _out_error(f"Gateway unreachable at {BASE_URL}")
        else: _out_ok("Gateway is up", r)
        append_spine("agent.health.checked", {"result": r})
    elif action == "nodes":
        r = _get("/api/nodes")
        _out_ok("Nodes", r.get("nodes"))
        append_spine("agent.nodes.listed", {"result": r})
    elif action == "history":
        events = []
        if SPINE_PATH.exists():
            for line in SPINE_PATH.read_text().splitlines()[-10:]:
                try: events.append(json.loads(line))
                except: pass
        _out_ok(f"Last {len(events)} spine events", {e.get('ts'): e.get('type') for e in events})
    elif action == "verify":
        # This is a simplified local verify. The full evez.py lint is more robust.
        last_hash = get_last_hash(SPINE_PATH)
        _out_ok("Local spine integrity check", {"last_hash": last_hash, "status": "Looks OK"})
    elif action in ["confirm", "reject"]:
        if not arg: _out_error(f"Provide an action_id. e.g. {action} act_1234"); return
        approved = action == "confirm"
        r = _post("/api/confirm", {"actionId": arg.strip(), "approved": approved})
        if r.get("ok"): _out_ok(f"Action {arg} {action}ed.", None)
        else: _out_error(f"{action.capitalize()} failed: {r.get('error', r)}")
        append_spine(f"agent.quarantine.{action}", {"action_id": arg, "result": r})
    elif action.startswith("microphone") or action in ["camera.capture", "screen.capture", "location.get", "system.info", "speaker.speak", "notifications.send", "shell"]:
        payload = {}
        if action == "speaker.speak": payload = {"text": arg or "Hello from EVEZOS"}
        elif action == "notifications.send": payload = {"title": "EVEZOS", "body": arg or "Message from agent"}
        elif action == "shell": payload = {"cmd": arg}
        elif action == "microphone.listen_n": payload = {"lang": "en-US", "timeoutMs": int(arg) * 1000 if arg else 8000}
        _dispatch_cmd(action, node, payload)
    elif action == "help":
        _print_help()
    else:
        _out_info(f"Didn't understand: {bold(repr(prompt))}")

def _dispatch_cmd(cmd_type: str, node: str, payload: Dict) -> None:
    r = _post("/api/simulate", {"type": cmd_type, "target": node, "payload": payload})
    append_spine("agent.command.dispatched", {"command": cmd_type, "payload": payload, "gateway_response": r})
    if r.get("_unreachable"): _out_error("Gateway offline. Cannot dispatch command."); return
    if r.get("quarantined", False):
        _out_info(f"Command {cmd_type} quarantined by gateway", r)
    else:
        _out_ok(f"Dispatched — {cmd_type}", r.get("result"))

def _first_paired_node() -> Optional[str]:
    if DEFAULT_NODE: return DEFAULT_NODE
    data = _get("/api/nodes")
    for nid, n in (data.get("nodes") or {}).items():
        if n.get("paired"): return nid
    return None

# --- Output & Help ---
def _out_ok(title: str, data: Optional[Dict]) -> None:
    print(f"\n  {green('✓')}  {bold(title)}")
    if data: [print(f"  {dim(f'{k:<14}')} {v}") for k, v in data.items()]

def _out_error(msg: str) -> None: print(f"\n  {red('✗')}  {bold(msg)}")
def _out_info(msg: str, data: Optional[Dict] = None) -> None: print(f"\n  {blue('·')}  {msg}"); _out_ok("", data) if data else None
def _print_help(): print("See SKILL.md for full command reference.")

# --- Webhook Server ---
class WebhookHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path != "/webhook/github": self.send_response(404); self.end_headers(); self.wfile.write(b"Not Found"); return
        if not WEBHOOK_SECRET: self.send_response(500); self.end_headers(); self.wfile.write(b"Webhook secret not configured"); print("[webhook] ERROR: GITHUB_WEBHOOK_SECRET is not set."); return
        signature = self.headers.get("X-Hub-Signature-256")
        if not signature: self.send_response(403); self.end_headers(); self.wfile.write(b"Signature required"); return
        body = self.rfile.read(int(self.headers["Content-Length"]))
        expected_signature = "sha256=" + hmac.new(WEBHOOK_SECRET.encode(), body, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected_signature, signature): self.send_response(403); self.end_headers(); self.wfile.write(b"Invalid signature"); return
        self.send_response(202); self.end_headers(); self.wfile.write(b"Accepted")
        event_type = self.headers.get("X-GitHub-Event"); payload = json.loads(body)
        print(f"[webhook] Received valid {event_type} event")
        append_spine("agent.webhook.received", {"event_type": event_type, "payload_excerpt": str(payload)[:200]})
        self.handle_event(event_type, payload)

    def handle_event(self, event_type, payload):
        if event_type == "push":
            pusher = payload.get("pusher", {}).get("name", "unknown"); repo = payload.get("repository", {}).get("full_name", "unknown/repo")
            self.trigger_agent(f"send a notification: Git push to {repo} by {pusher}")
        elif event_type == "issue_comment" and payload.get("action") == "created":
            user = payload.get("comment", {}).get("user", {}).get("login", "unknown"); repo = payload.get("repository", {}).get("full_name", "unknown/repo"); issue_number = payload.get("issue", {}).get("number", "?"); comment_body = payload.get("comment", {}).get("body", "")
            if "/agent" in comment_body:
                command = comment_body.split("/agent")[1].strip()
                self.trigger_agent(command)

    def trigger_agent(self, command):
        print(f"[webhook] Triggering agent with: {command}")
        action, arg = parse_intent(command)
        _run_action(action, arg, command)

def run_webhook_server():
    server_address = ("0.0.0.0", GATEWAY_PORT)
    httpd = HTTPServer(server_address, WebhookHandler)
    print(f"[webhook] Starting webhook listener on http://0.0.0.0:{GATEWAY_PORT}")
    append_spine("agent.webhook.start", {"host": "0.0.0.0", "port": GATEWAY_PORT})
    httpd.serve_forever()

# --- REPL & Entry Point ---
def _repl():
    print(f"\n{bold('OpenClaw + EVEZOS Agent v2.0')}  {dim(f'→ {BASE_URL}')}")
    print(f"{dim('Type a command or `help`. Ctrl-C to exit.')}\n")
    while True:
        try: raw = input(f"  {cyan('agent')} {dim('›')} ").strip()
        except (EOFError, KeyboardInterrupt): print(f"\n  {dim('bye.')}\n"); break
        if not raw: continue
        if raw.lower() in ("exit", "quit", "q"): print(f"\n  {dim('bye.')}\n"); break
        action, arg = parse_intent(raw)
        _run_action(action, arg, raw)
        print()

if __name__ == "__main__":
    if "--webhook" in sys.argv:
        run_webhook_server()
    elif len(sys.argv) > 1:
        prompt = " ".join(sys.argv[1:])
        action, arg = parse_intent(prompt)
        _run_action(action, arg, prompt)
    else:
        _repl()
