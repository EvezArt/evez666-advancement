---
name: openclaw-evezos-agent
description: >
  EVEZ-OS integrated device agent. Executes device commands (camera, mic, shell) and manages the EVEZOS chain (verify, manifest, confirm). All actions are logged to the immutable EVEZ-OS spine for verifiable cognition.
metadata:
  openclaw:
    requires:
      bins:
        - python3
    emoji: "\U0001F990"
    homepage: https://github.com/EvezArt/openclaw
---

# OpenClaw EVEZOS Agent v2.0

**EVEZ-OS Integrated Device Agent & Chain Manager**

This skill transforms the OpenClaw agent into a native citizen of the EVEZ ecosystem. It provides a secure, auditable interface for controlling connected devices and managing the EVEZOS blockchain. Every action is committed to the immutable EVEZ-OS `spine.jsonl`, creating a verifiable, tamper-evident chain of thought and execution.

## Core Philosophy: Verifiable Cognition

In the EVEZ ecosystem, trust is not assumed—it is proven. This agent adheres to that principle by:

1.  **Committing Everything to the Spine**: All commands, whether executed, quarantined, or rejected, are recorded as signed events in the `spine.jsonl` file, inheriting the cryptographic provenance of the entire EVEZ-OS.
2.  **Adopting EVEZ-OS Tooling**: The agent is invoked through the standard `evez.py` dispatcher, ensuring a consistent developer experience across the ecosystem.
3.  **Integrating with the Bus Architecture**: The agent acts as a capability on the EVEZ-OS bus, allowing it to be orchestrated and validated by the `MasterBus` and `ValidatorBus`.

## Quick Start

```bash
# Run the agent in an interactive loop
python3 agent.py

# Execute a single command
python3 agent.py "take a photo"

# Trigger from GitHub webhook (see Webhook Integration)
# POST /webhook/github with a valid X-Hub-Signature-256
```

## Command Reference

Commands are parsed from natural language and mapped to the actions below.

### Device Commands (via OpenClaw Gateway)

These commands interact with physical devices. All are subject to the EVEZOS risk-gating and quarantine process.

| Command | Action Key | Description | Default Risk |
| :--- | :--- | :--- | :--- |
| `take a photo` | `camera.capture` | Capture an image. | 0.80 |
| `where am i` | `location.get` | Get GPS coordinates. | 0.40 |
| `say <text>` | `speaker.speak` | Text-to-speech output. | 0.20 |
| `listen [for N s]` | `microphone.listen`| Record audio. | 0.75 |
| `screenshot` | `screen.capture` | Capture the device screen. | 0.70 |
| `send a notification` | `notifications.send` | Send a system notification. | 0.20 |
| `system info` | `system.info` | Get device hardware/software info. | 0.05 |
| `run: <command>` | `shell` | **HIGH RISK** Execute a shell command. | 0.95 |

### EVEZOS Chain Operations

These commands manage the local EVEZOS agent and its connection to the chain.

| Command | Action Key | Description |
| :--- | :--- | :--- |
| `verify` | `verify` | Check the integrity of the local chain spine. |
| `manifest` | `manifest` | Build and sign a manifest of the current chain state. |
| `show pending` | `pending_list` | List actions quarantined by the risk gate. |
| `confirm <id>` | `confirm` | Approve a quarantined action. |
| `reject <id>` | `reject` | Reject a quarantined action. |
| `history` | `history` | Show recent events from the spine. |
| `nodes` | `nodes` | List connected OpenClaw nodes. |
| `health` | `health` | Check gateway and agent health. |

## Webhook Integration (GitHub)

The agent can be triggered by GitHub webhooks, enabling complex CI/CD and automation workflows. The `/webhook/github` endpoint listens for `push` and `issue_comment` events.

**Setup:**

1.  **Secret**: Configure a webhook secret in your GitHub repository settings.
2.  **Environment**: Set the `GITHUB_WEBHOOK_SECRET` environment variable for the agent.
3.  **Endpoint**: Point the GitHub webhook to `http://<your-agent-host>:8888/webhook/github`.

When a valid, signed webhook is received, the agent will parse the event payload and can trigger other commands, creating a powerful feedback loop between your code and your devices.

## Developer's Guide: The "Let's Play" Walkthrough

This repository is not just a skill; it's a tutorial. The accompanying `LETS_PLAY.md` document provides a full, narrated walkthrough of this skill's creation and evolution. It covers:

1.  **Initial Audit**: Deconstructing the original `openclaw-evezos-agent`.
2.  **Ecosystem Integration**: Cloning the full EVEZ-OS and identifying key integration points (`spine`, `bus`, `agentvault`).
3.  **Refactoring**: Rewriting the agent to use the EVEZ-OS spine and command patterns.
4.  **Webhook Implementation**: Adding the GitHub webhook receiver for event-driven automation.
5.  **Narration & Documentation**: Crafting the final walkthrough document you are reading about now.

To follow the walkthrough, see `LETS_PLAY.md`.

## Resources

*   **`scripts/agent.py`**: The core agent logic, refactored for EVEZ-OS integration.
*   **`scripts/webhook.py`**: The GitHub webhook receiver.
*   **`scripts/_local_risk.py`**: The local risk scoring model for offline fallback.
*   **`LETS_PLAY.md`**: The full development walkthrough and narration.
