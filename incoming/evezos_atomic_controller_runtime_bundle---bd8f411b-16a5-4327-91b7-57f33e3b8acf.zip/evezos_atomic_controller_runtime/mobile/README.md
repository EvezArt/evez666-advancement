# EVEZOS Mobile Grounded Shell

This mobile package now defaults to the grounded runtime contract instead of ad-hoc endpoint drift.

Key changes:
- `apiBaseUrl` can prefix all local route defaults
- default routes point at `/api/health`, `/api/registry`, `/api/agent-run`, `/api/ledger`, `/api/settlements`, `/api/wallet/*`
- the home screen surfaces runtime health, bus connectivity, and ledger verification
- screens still return explicit not-connected states if the backend is not wired
