import { useEffect, useState } from 'react';
import NavBar from '../components/NavBar';
import { loadSettings } from '../lib/settings';

export default function LedgerPage() {
  const [entries, setEntries] = useState([]);
  const [message, setMessage] = useState('Checking ledger endpoint…');

  useEffect(() => {
    async function run() {
      const settings = loadSettings();
      if (!settings.ledgerUrl) {
        setMessage('Not connected. Add a live ledger endpoint in Settings.');
        return;
      }
      try {
        const res = await fetch(settings.ledgerUrl);
        const data = await res.json();
        setEntries(data.entries || []);
        setMessage(null);
      } catch {
        setMessage('Failed to load ledger.');
      }
    }
    run();
  }, []);

  return (
    <>
      <div className="container">
        <div className="card">
          <h2>Ledger</h2>
          {message && <p>{message}</p>}
          {!message && entries.length === 0 && <p>No live ledger entries returned.</p>}
          {entries.map((e, idx) => (
            <div key={idx} style={{ marginBottom: '8px' }}>
              <div style={{ fontSize: '12px', color: '#9fc7fc' }}>{e.timestamp || e.ts}</div>
              <strong>{e.action || e.type}</strong>: {e.details ? JSON.stringify(e.details) : e.message}
            </div>
          ))}
        </div>
      </div>
      <NavBar />
    </>
  );
}
