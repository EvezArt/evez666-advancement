import { useEffect, useState } from 'react';
import NavBar from '../components/NavBar';
import { loadSettings } from '../lib/settings';

export default function Workflows() {
  const [workflows, setWorkflows] = useState([]);
  const [message, setMessage] = useState('Checking workflow endpoint…');

  useEffect(() => {
    async function run() {
      const settings = loadSettings();
      if (!settings.workflowsUrl) {
        setMessage('Not connected. Add a live n8n workflow status endpoint in Settings.');
        return;
      }
      try {
        const res = await fetch(settings.workflowsUrl);
        const data = await res.json();
        setWorkflows(data.workflows || []);
        setMessage(null);
      } catch {
        setMessage('Failed to load workflow status.');
      }
    }
    run();
  }, []);

  return (
    <>
      <div className="container">
        <div className="card">
          <h2>n8n Workflows</h2>
          {message && <p>{message}</p>}
          {!message && workflows.length === 0 && <p>No live workflows returned.</p>}
          {workflows.map((wf, idx) => (
            <div key={idx} style={{ marginBottom: '12px' }}>
              <strong>{wf.name}</strong>
              <div style={{ fontSize: '12px', color: '#9fc7fc' }}>
                Status: {wf.status} | Trigger: {wf.trigger} | Latency: {wf.latency} | Backlog: {wf.backlog}
              </div>
            </div>
          ))}
        </div>
      </div>
      <NavBar />
    </>
  );
}
