import { useEffect, useState } from 'react';
import NavBar from '../components/NavBar';
import { loadSettings } from '../lib/settings';

export default function Home() {
  const [state, setState] = useState({ wallet: null, settlements: [], health: null, message: 'Checking live connections…' });

  useEffect(() => {
    async function run() {
      const settings = loadSettings();
      try {
        const [walletRes, settlementsRes, healthRes] = await Promise.all([
          fetch(settings.walletUrl),
          fetch(settings.settlementsUrl),
          fetch(settings.healthUrl),
        ]);
        const walletJson = await walletRes.json();
        const settlementsJson = await settlementsRes.json();
        const healthJson = await healthRes.json();
        setState({
          wallet: walletJson.wallet || null,
          settlements: settlementsJson.settlements || [],
          health: healthJson,
          message: walletJson.message || settlementsJson.message || null,
        });
      } catch {
        setState({ wallet: null, settlements: [], health: null, message: 'Failed to fetch grounded runtime data.' });
      }
    }
    run();
  }, []);

  const confirmed = state.settlements.filter((x) => x.status === 'confirmed');

  return (
    <>
      <div className="container">
        <div className="card">
          <h1>EVEZOS</h1>
          <p>Grounded mobile console. Reads one registry and one runtime truth boundary.</p>
          {!state.wallet ? <p>{state.message}</p> : (
            <>
              <p><strong>Treasury wallet:</strong> {state.wallet.address}</p>
              <p><strong>Chain:</strong> {state.wallet.chainId}</p>
              <p><strong>Provider:</strong> {state.wallet.provider}</p>
              <p><strong>Confirmed settlements:</strong> {confirmed.length}</p>
            </>
          )}
          {state.health && (
            <div style={{ marginTop: '12px', fontSize: '13px', color: '#9fc7fc' }}>
              <div>Mode: {state.health.mode}</div>
              <div>Ledger: {state.health.ledgerVerification?.connected ? (state.health.ledgerVerification.valid ? 'valid' : 'invalid') : 'not connected'}</div>
              <div>Bus: {state.health.envStatus?.redis ? 'connected' : 'not connected'}</div>
            </div>
          )}
        </div>
      </div>
      <NavBar />
    </>
  );
}
