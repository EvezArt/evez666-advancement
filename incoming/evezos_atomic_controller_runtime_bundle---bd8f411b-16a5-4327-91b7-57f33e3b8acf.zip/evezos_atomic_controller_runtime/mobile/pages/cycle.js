import { useState } from 'react';
import NavBar from '../components/NavBar';
import { loadSettings } from '../lib/settings';

export default function Cycle() {
  const [status, setStatus] = useState('ready');
  const [log, setLog] = useState([]);

  const runCycle = async () => {
    const settings = loadSettings();
    if (!settings.agentRunUrl) {
      setLog(['n8n agent-run webhook not configured.']);
      return;
    }
    setStatus('running');
    setLog(['Triggering live n8n workflow…']);
    try {
      const res = await fetch(settings.agentRunUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ source: 'mobile' }) });
      const data = await res.json();
      setLog((l) => [...l, JSON.stringify(data)]);
    } catch (e) {
      setLog((l) => [...l, 'Failed to reach live n8n workflow.']);
    } finally {
      setStatus('ready');
    }
  };

  return (
    <>
      <div className="container">
        <div className="card">
          <h2>Run Agent Cycle</h2>
          <p>This screen only triggers a real configured endpoint. It does not simulate cycle phases.</p>
          <button onClick={runCycle} disabled={status === 'running'} style={{ padding: '12px 24px', marginBottom: '8px', background: 'var(--primary)', color: '#000', border: 'none', borderRadius: '8px' }}>
            {status === 'running' ? 'Running...' : 'Trigger Live Cycle'}
          </button>
          <ul style={{ fontSize: '12px', color: '#9fc7fc' }}>
            {log.map((line, idx) => <li key={idx}>{line}</li>)}
          </ul>
        </div>
      </div>
      <NavBar />
    </>
  );
}
