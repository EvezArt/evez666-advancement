import { useEffect, useState } from 'react';
import NavBar from '../components/NavBar';
import { loadSettings } from '../lib/settings';

export default function Deliverables() {
  const [deliverables, setDeliverables] = useState([]);
  const [message, setMessage] = useState('Checking deliverables endpoint…');

  useEffect(() => {
    async function run() {
      const settings = loadSettings();
      if (!settings.deliverablesUrl) {
        setMessage('Not connected. Add a live deliverables endpoint in Settings.');
        return;
      }
      try {
        const res = await fetch(settings.deliverablesUrl);
        const data = await res.json();
        setDeliverables(data.deliverables || []);
        setMessage(null);
      } catch {
        setMessage('Failed to load deliverables.');
      }
    }
    run();
  }, []);

  return (
    <>
      <div className="container">
        <div className="card">
          <h2>Deliverables</h2>
          {message && <p>{message}</p>}
          {!message && deliverables.length === 0 && <p>No live deliverables returned.</p>}
          {deliverables.map((deliv, idx) => (
            <div key={idx} style={{ marginBottom: '12px' }}>
              <strong>{deliv.type || 'ITEM'}</strong>: {deliv.content}
              <div style={{ fontSize: '12px', color: '#9fc7fc' }}>
                Status: {deliv.status}
              </div>
            </div>
          ))}
        </div>
      </div>
      <NavBar />
    </>
  );
}
