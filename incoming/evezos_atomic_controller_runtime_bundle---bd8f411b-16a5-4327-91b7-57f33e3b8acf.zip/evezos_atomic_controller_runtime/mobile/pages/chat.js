import { useState } from 'react';
import NavBar from '../components/NavBar';
import { loadSettings } from '../lib/settings';

export default function Chat() {
  const [messages, setMessages] = useState([{ role: 'assistant', content: 'Chat is inactive until a live chat endpoint is configured.' }]);
  const [input, setInput] = useState('');

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;
    const settings = loadSettings();
    const next = [...messages, { role: 'user', content: input.trim() }];
    setMessages(next);
    const prompt = input.trim();
    setInput('');
    if (!settings.chatUrl) {
      setMessages((prev) => [...prev, { role: 'assistant', content: 'No live chat endpoint configured.' }]);
      return;
    }
    try {
      const res = await fetch(settings.chatUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next }),
      });
      const data = await res.json();
      setMessages((prev) => [...prev, data.reply || { role: 'assistant', content: JSON.stringify(data) }]);
    } catch {
      setMessages((prev) => [...prev, { role: 'assistant', content: 'Failed to reach live chat endpoint.' }]);
    }
  };

  return (
    <>
      <div className="container">
        <div className="card" style={{ minHeight: '50vh' }}>
          <h2>Chat</h2>
          <div style={{ maxHeight: '40vh', overflowY: 'auto', marginBottom: '8px', fontSize: '14px' }}>
            {messages.map((m, idx) => (
              <div key={idx} style={{ marginBottom: '4px', textAlign: m.role === 'user' ? 'right' : 'left' }}>
                <span style={{ color: m.role === 'user' ? 'var(--primary)' : 'var(--secondary)' }}>{m.role === 'user' ? 'You' : 'AI'}</span>: {m.content}
              </div>
            ))}
          </div>
          <form onSubmit={sendMessage} style={{ display: 'flex' }}>
            <input type="text" value={input} onChange={(e) => setInput(e.target.value)} placeholder="Type message…" style={{ flex: 1, padding: '8px', borderRadius: '8px', border: '1px solid var(--card-border)', background: 'rgba(255,255,255,0.05)', color: '#fff' }} />
          </form>
        </div>
      </div>
      <NavBar />
    </>
  );
}
