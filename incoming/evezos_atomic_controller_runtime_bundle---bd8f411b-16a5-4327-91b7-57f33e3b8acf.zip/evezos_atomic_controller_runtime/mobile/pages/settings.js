import { useEffect, useState } from 'react';
import NavBar from '../components/NavBar';
import { defaults, loadSettings, saveSettings } from '../lib/settings';

export default function Settings() {
  const [settings, setSettings] = useState(defaults);

  useEffect(() => {
    setSettings({ ...defaults, ...loadSettings() });
  }, []);

  const handleChange = (field, value) => setSettings((prev) => ({ ...prev, [field]: value }));
  const handleSave = () => {
    saveSettings(settings);
    alert('Grounded endpoint settings saved on this device.');
  };
  const applyDefaults = () => setSettings({ ...settings, ...defaults });

  return (
    <>
      <div className="container">
        <div className="card">
          <h2>Settings</h2>
          <p>Use one API base URL and let the phone shell resolve the grounded runtime endpoints from there.</p>
          {Object.keys(settings).map((key) => (
            <div key={key} style={{ marginBottom: '12px' }}>
              <label style={{ display: 'block', marginBottom: '4px' }}>{key}</label>
              <input
                type="text"
                value={settings[key] ?? ''}
                onChange={(e) => handleChange(key, e.target.value)}
                placeholder={`Enter ${key}`}
                style={{ width: '100%', padding: '8px', borderRadius: '8px', border: '1px solid var(--card-border)', background: 'rgba(255,255,255,0.05)', color: '#fff' }}
              />
            </div>
          ))}
          <button onClick={handleSave} style={{ padding: '12px 24px', background: 'var(--accent)', border: 'none', borderRadius: '8px', color: '#000', marginRight: '8px' }}>Save</button>
          <button onClick={applyDefaults} style={{ padding: '12px 24px', background: 'rgba(255,255,255,0.08)', border: '1px solid var(--card-border)', borderRadius: '8px', color: '#fff' }}>Use grounded defaults</button>
        </div>
      </div>
      <NavBar />
    </>
  );
}
