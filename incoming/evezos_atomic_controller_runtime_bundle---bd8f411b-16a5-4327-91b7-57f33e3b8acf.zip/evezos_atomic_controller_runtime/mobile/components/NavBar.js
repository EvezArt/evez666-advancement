import { useRouter } from 'next/router';

export default function NavBar() {
  const router = useRouter();
  const current = router.pathname;

  const navLinks = [
    { href: '/', label: 'Home' },
    { href: '/cycle', label: 'Cycle' },
    { href: '/workflows', label: 'Workflows' },
    { href: '/deliverables', label: 'Deliverables' },
    { href: '/ledger', label: 'Ledger' },
    { href: '/chat', label: 'Chat' },
    { href: '/settings', label: 'Settings' },
  ];

  return (
    <nav className="nav">
      {navLinks.map(({ href, label }) => (
        <a
          key={href}
          href={href}
          className={current === href ? 'active' : ''}
        >
          {label}
        </a>
      ))}
    </nav>
  );
}