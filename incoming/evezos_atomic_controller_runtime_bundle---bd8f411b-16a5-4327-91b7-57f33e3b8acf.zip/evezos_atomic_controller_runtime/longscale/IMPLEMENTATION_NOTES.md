# EVEZOS Runtime Enforcement Patch

This patch converts the grounded runtime from observation-only to receipt-bound execution.

## What changed
- Added a canonical surface registry and proof route.
- Added a Postgres-backed canonical state chain with:
  - state hash
  - state version
  - monotonic sequence
  - commit-backed receipts
  - rejection log
- Added `/api/execute` as the single authoritative mutation gateway.
- Rewired `/api/bus` and `/api/agent-run` to mutate through the gateway.
- Updated the board to display authority proof and to show receipts/rejections.

## What is enforced
- No receipt is emitted unless a canonical state commit succeeds.
- Mutations are rejected if:
  - falsifier is missing
  - expected hash mismatches
  - expected version mismatches
  - sequence is out of order
- Redis is now a derived mirror for bus tasks; Postgres canonical state is the authority.

## What is still external
- Vercel project deletion / authority collapse
- Runtime deploy / env wiring
- CI strict-mode enforcement in the actual repo
- Connector retry shutdown outside this runtime package

## Required env
- `POSTGRES_URL` (or host/db split)
- optional `REDIS_URL`
- optional `N8N_AGENT_RUN_WEBHOOK_URL`
