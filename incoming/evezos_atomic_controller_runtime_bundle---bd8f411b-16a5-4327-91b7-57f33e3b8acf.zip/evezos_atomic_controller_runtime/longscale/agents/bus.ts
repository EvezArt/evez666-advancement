import { createClient, type RedisClientType } from "redis";

export interface BusTask {
  id: string;
  title: string;
  payload: unknown;
  status: "pending" | "in_progress" | "completed";
  createdAt: string;
}

const BUS_KEY = "evez:bus:tasks";
let clientPromise: Promise<RedisClientType | null> | null = null;

async function getClient(): Promise<RedisClientType | null> {
  if (clientPromise) return clientPromise;
  clientPromise = (async () => {
    const url = process.env.REDIS_URL;
    const host = process.env.REDIS_HOST;
    const port = process.env.REDIS_PORT;
    if (!url && !(host && port)) return null;
    const client = createClient(url ? { url } : { socket: { host, port: Number(port) } });
    client.on("error", () => undefined);
    await client.connect();
    return client;
  })().catch(() => null);
  return clientPromise;
}

export async function isBusConnected() {
  return Boolean(await getClient());
}

export async function mirrorTasks(tasks: BusTask[]): Promise<void> {
  const client = await getClient();
  if (!client) return;
  const multi = client.multi();
  multi.del(BUS_KEY);
  for (const task of [...tasks].reverse()) {
    multi.lPush(BUS_KEY, JSON.stringify(task));
  }
  await multi.exec();
}

export async function getMirroredTasks(): Promise<BusTask[]> {
  const client = await getClient();
  if (!client) return [];
  const rows = await client.lRange(BUS_KEY, 0, -1);
  return rows.map((row) => JSON.parse(row) as BusTask).reverse();
}
