export async function generate(): Promise<never> {
  throw new Error("Mock generator disabled. Route live generation through n8n or a real model endpoint.");
}
