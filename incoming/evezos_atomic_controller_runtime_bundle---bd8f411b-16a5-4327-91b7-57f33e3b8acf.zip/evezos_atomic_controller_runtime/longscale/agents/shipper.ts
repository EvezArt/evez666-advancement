export async function ship(): Promise<never> {
  throw new Error("Mock shipper disabled. Connect real publishing or payout infrastructure.");
}
