export async function simulateStep(): Promise<never> {
  throw new Error("World simulation disabled in live-only build. Use real workflow outputs instead.");
}

export function getState(): never {
  throw new Error("No simulated state is exposed in the live-only build.");
}
