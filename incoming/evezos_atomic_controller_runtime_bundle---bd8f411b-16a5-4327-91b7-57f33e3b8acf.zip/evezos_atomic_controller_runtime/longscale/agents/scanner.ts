export async function scan(): Promise<never> {
  throw new Error("Mock scanner disabled. Connect a live source through n8n or LIVE_OPPORTUNITIES_URL.");
}
