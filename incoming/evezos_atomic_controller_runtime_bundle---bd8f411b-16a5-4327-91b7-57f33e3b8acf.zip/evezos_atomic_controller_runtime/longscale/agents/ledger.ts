import crypto from "crypto";
import { getPool, withClient } from "../lib/db";

export interface LedgerEntry {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  details: unknown;
  payloadHash: string;
  prevHash: string | null;
  entryHash: string;
}

function sha256Hex(input: string) {
  return crypto.createHash("sha256").update(input).digest("hex");
}

export async function isLedgerConnected() {
  return Boolean(await getPool());
}

export async function logAction(action: string, details: unknown, actor = "ui.operator"): Promise<LedgerEntry> {
  return withClient(async (client) => {
    const id = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
    const timestamp = new Date().toISOString();
    const normalized = JSON.stringify(details ?? {});
    const payloadHash = sha256Hex(normalized);
    const prevResult = await client.query(`SELECT entry_hash FROM ledger_events ORDER BY ts DESC LIMIT 1`);
    const prevHash = prevResult.rows[0]?.entry_hash ?? null;
    const entryHash = sha256Hex(`${id}|${timestamp}|${actor}|${action}|${payloadHash}|${prevHash ?? ""}`);
    await client.query(
      `INSERT INTO ledger_events (id, ts, actor, action, payload_hash, prev_hash, entry_hash, metadata)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [id, timestamp, actor, action, payloadHash, prevHash, entryHash, details ?? {}],
    );
    return { id, timestamp, actor, action, details, payloadHash, prevHash, entryHash };
  });
}

export async function getLedger(limit = 100): Promise<LedgerEntry[]> {
  const pool = await getPool();
  if (!pool) return [];
  const result = await pool.query(
    `SELECT id, ts, actor, action, metadata, payload_hash, prev_hash, entry_hash FROM ledger_events ORDER BY ts DESC LIMIT $1`,
    [limit],
  );
  return result.rows.map((row) => ({
    id: row.id,
    timestamp: new Date(row.ts).toISOString(),
    actor: row.actor,
    action: row.action,
    details: row.metadata,
    payloadHash: row.payload_hash,
    prevHash: row.prev_hash,
    entryHash: row.entry_hash,
  }));
}

export async function clearLedger(): Promise<void> {
  const pool = await getPool();
  if (!pool) return;
  await pool.query(`DELETE FROM ledger_events`);
  await pool.query(`DELETE FROM execution_receipts`);
  await pool.query(`DELETE FROM execution_rejections`);
  await pool.query(`DELETE FROM canonical_state`);
}

export async function verifyLedger() {
  const pool = await getPool();
  if (!pool) return { connected: false, valid: false, count: 0, message: "Ledger not connected." };
  const result = await pool.query(`SELECT id, ts, actor, action, metadata, payload_hash, prev_hash, entry_hash FROM ledger_events ORDER BY ts ASC`);
  const rows = result.rows;
  for (let i = 0; i < rows.length; i += 1) {
    const row = rows[i];
    const expectedEntryHash = sha256Hex(`${row.id}|${new Date(row.ts).toISOString()}|${row.actor}|${row.action}|${row.payload_hash}|${row.prev_hash ?? ""}`);
    if (expectedEntryHash !== row.entry_hash) {
      return { connected: true, valid: false, count: rows.length, brokenAt: i, reason: "entry_hash_mismatch" };
    }
    if (i > 0 && row.prev_hash !== rows[i - 1].entry_hash) {
      return { connected: true, valid: false, count: rows.length, brokenAt: i, reason: "prev_hash_mismatch" };
    }
  }
  const stateResult = await pool.query(`SELECT state_key, version, state_hash, last_sequence, last_receipt_id, updated_at FROM canonical_state ORDER BY updated_at DESC LIMIT 1`);
  return {
    connected: true,
    valid: true,
    count: rows.length,
    canonicalState: stateResult.rows[0]
      ? {
          stateKey: stateResult.rows[0].state_key,
          version: Number(stateResult.rows[0].version),
          stateHash: stateResult.rows[0].state_hash,
          lastSequence: Number(stateResult.rows[0].last_sequence),
          lastReceiptId: stateResult.rows[0].last_receipt_id,
          updatedAt: new Date(stateResult.rows[0].updated_at).toISOString(),
        }
      : null,
  };
}

export async function getExecutionRejections(limit = 25) {
  const pool = await getPool();
  if (!pool) return [];
  const result = await pool.query(`SELECT * FROM execution_rejections ORDER BY created_at DESC LIMIT $1`, [limit]);
  return result.rows.map((row) => ({
    rejectionId: row.rejection_id,
    stateKey: row.state_key,
    attemptedSequence: row.attempted_sequence,
    attemptedVersion: row.attempted_version,
    attemptedHash: row.attempted_hash,
    actor: row.actor,
    action: row.action,
    falsifier: row.falsifier,
    reason: row.reason,
    details: row.details,
    createdAt: new Date(row.created_at).toISOString(),
  }));
}
