export async function predict(): Promise<never> {
  throw new Error("Mock predictor disabled. Route live predictions through n8n or a real model endpoint.");
}
