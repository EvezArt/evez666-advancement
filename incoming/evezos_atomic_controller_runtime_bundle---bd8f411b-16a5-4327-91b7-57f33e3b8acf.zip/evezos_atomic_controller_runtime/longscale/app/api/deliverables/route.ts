import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    success: false,
    connected: false,
    deliverables: [],
    message: "Deliverable worker is phase-A defined but no live deliverables endpoint is wired yet.",
  }, { status: 503 });
}
