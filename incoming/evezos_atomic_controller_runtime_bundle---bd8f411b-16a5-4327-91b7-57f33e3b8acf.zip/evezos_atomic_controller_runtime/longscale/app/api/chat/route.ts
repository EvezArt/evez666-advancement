import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const endpoint = process.env.OPENAI_RESPONSES_PROXY_URL;
  if (!endpoint) {
    return NextResponse.json(
      {
        success: false,
        connected: false,
        message: "OPENAI_RESPONSES_PROXY_URL is not configured.",
      },
      { status: 503 },
    );
  }

  try {
    const body = await req.json();
    const upstream = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await upstream.json().catch(() => ({}));
    return NextResponse.json({ success: upstream.ok, connected: true, ...data }, { status: upstream.status });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        connected: true,
        message: error instanceof Error ? error.message : "Failed to reach chat provider.",
      },
      { status: 502 },
    );
  }
}
