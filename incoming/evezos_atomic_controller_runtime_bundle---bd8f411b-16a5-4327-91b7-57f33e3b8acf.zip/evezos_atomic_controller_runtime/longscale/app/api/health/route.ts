import { NextResponse } from "next/server";
import { isBusConnected } from "../../../agents/bus";
import { isLedgerConnected, verifyLedger, getExecutionRejections } from "../../../agents/ledger";
import { getAgentManifest } from "../../../lib/registry";
import { getCanonicalState, getRecentReceipts } from "../../../lib/execution";
import { getCanonicalRegistry } from "../../../lib/canonical";

export async function GET() {
  const manifest = getAgentManifest();
  const registry = getCanonicalRegistry();
  const [busConnected, ledgerConnected, ledgerVerification, canonicalState, receipts, rejections] = await Promise.all([
    isBusConnected(),
    isLedgerConnected(),
    verifyLedger(),
    getCanonicalState().catch(() => null),
    getRecentReceipts(5).catch(() => []),
    getExecutionRejections(5).catch(() => []),
  ]);
  const envStatus = {
    cycleRunner: Boolean(process.env.N8N_AGENT_RUN_WEBHOOK_URL),
    chatProxy: Boolean(process.env.OPENAI_RESPONSES_PROXY_URL),
    opportunities: Boolean(process.env.LIVE_OPPORTUNITIES_URL),
    treasury: Boolean(process.env.TREASURY_WALLET_ADDRESS && process.env.TREASURY_CHAIN_ID && process.env.WALLET_PROVIDER),
    balances: Boolean(process.env.WALLET_BALANCE_API_URL),
    settlements: Boolean(process.env.SETTLEMENTS_API_URL),
    redis: busConnected,
    postgres: ledgerConnected,
  };
  return NextResponse.json({
    service: "evezos-grounded-runtime",
    mode: manifest.bundle.mode,
    generatedAt: manifest.bundle.generatedAt,
    agentCount: manifest.agents.length,
    enabledAgents: manifest.agents.filter((agent) => !String(agent.status).startsWith("disabled")).length,
    envStatus,
    ledgerVerification,
    canonicalRuntime: canonicalState,
    recentReceipts: receipts,
    recentRejections: rejections,
    canonicalSurfaces: registry.canonical,
    nonCanonicalCount: registry.nonCanonical.length,
  });
}
