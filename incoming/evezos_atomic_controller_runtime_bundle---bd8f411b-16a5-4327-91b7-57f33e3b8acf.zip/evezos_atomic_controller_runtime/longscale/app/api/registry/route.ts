import { NextResponse } from "next/server";
import { getAgentManifest, getWorkspacePlan } from "../../../lib/registry";

export async function GET() {
  return NextResponse.json({ success: true, manifest: getAgentManifest(), workspacePlan: getWorkspacePlan() });
}
