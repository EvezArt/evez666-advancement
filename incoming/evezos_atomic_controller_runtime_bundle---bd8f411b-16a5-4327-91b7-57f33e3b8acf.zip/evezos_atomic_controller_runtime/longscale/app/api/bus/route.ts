import { NextRequest, NextResponse } from "next/server";
import { getCanonicalState } from "../../../lib/execution";
import { isBusConnected, mirrorTasks } from "../../../agents/bus";
import { ExecutionRejection, executeMutation } from "../../../lib/execution";

export async function GET() {
  const [connected, state] = await Promise.all([isBusConnected(), getCanonicalState().catch(() => null)]);
  const tasks = state?.snapshot?.bus?.tasks ?? [];
  return NextResponse.json({
    success: Boolean(state),
    connected,
    authoritative: Boolean(state),
    tasks,
    canonicalState: state,
    message: state ? null : "Canonical state is not available. Configure Postgres to make bus state authoritative.",
  }, { status: state ? 200 : 503 });
}

export async function POST(req: NextRequest) {
  try {
    const state = await getCanonicalState();
    const { title, payload, falsifier } = await req.json();
    const { receipt, canonicalState } = await executeMutation({
      action: "bus.add_task",
      actor: "ui.bus",
      falsifier: String(falsifier || "bus.add_task.ui"),
      idempotencyKey: `bus-add-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
      sequence: state.lastSequence + 1,
      expectedVersion: state.version,
      expectedHash: state.stateHash,
      details: { title, payload: payload ?? {} },
    });
    await mirrorTasks(canonicalState.snapshot.bus.tasks).catch(() => undefined);
    return NextResponse.json({ success: true, connected: true, receipt, canonicalState, tasks: canonicalState.snapshot.bus.tasks });
  } catch (error) {
    if (error instanceof ExecutionRejection) {
      return NextResponse.json({ success: false, reason: error.reason, context: error.context ?? null }, { status: error.status });
    }
    return NextResponse.json({ success: false, connected: false, message: error instanceof Error ? error.message : "Failed to add task." }, { status: 503 });
  }
}

export async function PUT(req: NextRequest) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (!id) return NextResponse.json({ success: false, message: "Task id is required." }, { status: 400 });
  try {
    const state = await getCanonicalState();
    const { status, falsifier } = await req.json();
    const { receipt, canonicalState } = await executeMutation({
      action: "bus.update_task",
      actor: "ui.bus",
      falsifier: String(falsifier || "bus.update_task.ui"),
      idempotencyKey: `bus-update-${id}-${status}-${Date.now()}`,
      sequence: state.lastSequence + 1,
      expectedVersion: state.version,
      expectedHash: state.stateHash,
      details: { taskId: id, status },
    });
    await mirrorTasks(canonicalState.snapshot.bus.tasks).catch(() => undefined);
    return NextResponse.json({ success: true, connected: true, receipt, canonicalState, tasks: canonicalState.snapshot.bus.tasks });
  } catch (error) {
    if (error instanceof ExecutionRejection) {
      return NextResponse.json({ success: false, reason: error.reason, context: error.context ?? null }, { status: error.status });
    }
    return NextResponse.json({ success: false, connected: false, message: error instanceof Error ? error.message : "Failed to update task." }, { status: 503 });
  }
}

export async function DELETE() {
  try {
    const state = await getCanonicalState();
    const { receipt, canonicalState } = await executeMutation({
      action: "bus.clear",
      actor: "ui.bus",
      falsifier: "bus.clear.ui",
      idempotencyKey: `bus-clear-${Date.now()}`,
      sequence: state.lastSequence + 1,
      expectedVersion: state.version,
      expectedHash: state.stateHash,
      details: {},
    });
    await mirrorTasks(canonicalState.snapshot.bus.tasks).catch(() => undefined);
    return NextResponse.json({ success: true, receipt, canonicalState, tasks: canonicalState.snapshot.bus.tasks });
  } catch (error) {
    if (error instanceof ExecutionRejection) {
      return NextResponse.json({ success: false, reason: error.reason, context: error.context ?? null }, { status: error.status });
    }
    return NextResponse.json({ success: false, message: error instanceof Error ? error.message : "Failed to clear tasks." }, { status: 503 });
  }
}
