import { NextRequest, NextResponse } from "next/server";
import { clearLedger, getExecutionRejections, getLedger, isLedgerConnected, logAction, verifyLedger } from "../../../agents/ledger";
import { getCanonicalState, getRecentReceipts } from "../../../lib/execution";

export async function GET(req: NextRequest) {
  const limit = Number(new URL(req.url).searchParams.get("limit") || 100);
  const connected = await isLedgerConnected();
  const [entries, verification, receipts, rejections, canonicalState] = await Promise.all([
    getLedger(limit),
    verifyLedger(),
    getRecentReceipts(Math.min(limit, 25)).catch(() => []),
    getExecutionRejections(Math.min(limit, 25)).catch(() => []),
    getCanonicalState().catch(() => null),
  ]);
  return NextResponse.json({
    success: connected,
    connected,
    entries,
    receipts,
    rejections,
    verification,
    canonicalState,
    message: connected ? null : "Ledger is not connected. Configure Postgres to make audit state authoritative.",
  }, { status: connected ? 200 : 503 });
}

export async function POST(req: NextRequest) {
  try {
    const { action, details, actor } = await req.json();
    if (!action || typeof action !== "string") {
      return NextResponse.json({ success: false, message: "Action is required." }, { status: 400 });
    }
    const entry = await logAction(action, details ?? {}, actor ?? "ui.operator");
    return NextResponse.json({ success: true, connected: true, entry });
  } catch (error) {
    return NextResponse.json({ success: false, connected: false, message: error instanceof Error ? error.message : "Failed to append ledger entry." }, { status: 503 });
  }
}

export async function DELETE() {
  await clearLedger();
  return NextResponse.json({ success: true });
}
