import { NextRequest, NextResponse } from "next/server";
import { ExecutionRejection, executeMutation, getCanonicalState } from "../../../lib/execution";
import { mirrorTasks } from "../../../agents/bus";

export async function GET() {
  const state = await getCanonicalState().catch(() => null);
  return NextResponse.json({ success: Boolean(state), canonicalState: state }, { status: state ? 200 : 503 });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const current = await getCanonicalState();
    const idempotencyKey = String(body.idempotencyKey || req.headers.get("x-idempotency-key") || `${body.action || "action"}-${Date.now()}`);
    const sequence = Number(body.sequence ?? current.lastSequence + 1);
    const expectedVersion = Number(body.expectedVersion ?? current.version);
    const expectedHash = String(body.expectedHash ?? current.stateHash);
    const falsifier = String(body.falsifier || "operator.asserted");
    const { receipt, canonicalState } = await executeMutation({
      stateKey: String(body.stateKey || "runtime"),
      action: String(body.action || ""),
      actor: String(body.actor || "ui.operator"),
      falsifier,
      idempotencyKey,
      sequence,
      expectedVersion,
      expectedHash,
      details: (body.details ?? {}) as Record<string, unknown>,
    });
    await mirrorTasks(canonicalState.snapshot.bus.tasks).catch(() => undefined);
    return NextResponse.json({ success: true, receipt, canonicalState });
  } catch (error) {
    if (error instanceof ExecutionRejection) {
      return NextResponse.json({ success: false, reason: error.reason, context: error.context ?? null }, { status: error.status });
    }
    return NextResponse.json({ success: false, message: error instanceof Error ? error.message : "Execution failed." }, { status: 500 });
  }
}
