import { NextResponse } from "next/server";

export async function GET() {
  const address = process.env.TREASURY_WALLET_ADDRESS;
  const chainId = process.env.TREASURY_CHAIN_ID;
  const provider = process.env.WALLET_PROVIDER;

  if (!address || !chainId || !provider) {
    return NextResponse.json(
      {
        success: false,
        connected: false,
        wallet: null,
        message: "Treasury wallet is not configured. Set TREASURY_WALLET_ADDRESS, TREASURY_CHAIN_ID, and WALLET_PROVIDER.",
      },
      { status: 503 },
    );
  }

  return NextResponse.json({
    success: true,
    connected: true,
    wallet: {
      address,
      chainId,
      provider,
      ownerType: "treasury",
      updatedAt: new Date().toISOString(),
    },
  });
}
