import { NextResponse } from "next/server";

export async function GET() {
  const endpoint = process.env.SETTLEMENTS_API_URL;
  if (!endpoint) {
    return NextResponse.json(
      {
        success: false,
        connected: false,
        settlements: [],
        confirmedRevenue: null,
        pendingRevenue: null,
        message: "SETTLEMENTS_API_URL is not configured.",
      },
      { status: 503 },
    );
  }

  try {
    const upstream = await fetch(endpoint, { cache: "no-store" });
    const data = await upstream.json().catch(() => ({}));
    return NextResponse.json({ success: upstream.ok, connected: true, ...data }, { status: upstream.status });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        connected: true,
        settlements: [],
        confirmedRevenue: null,
        pendingRevenue: null,
        message: error instanceof Error ? error.message : "Failed to fetch settlement data.",
      },
      { status: 502 },
    );
  }
}
