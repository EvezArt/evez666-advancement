import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    success: false,
    connected: false,
    workflows: [],
    message: "Workflow telemetry is phase-A defined but no live telemetry endpoint is wired yet.",
  }, { status: 503 });
}
