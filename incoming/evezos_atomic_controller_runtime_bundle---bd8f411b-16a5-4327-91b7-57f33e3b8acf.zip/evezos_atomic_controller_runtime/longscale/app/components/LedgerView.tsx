"use client";

import { useEffect, useState } from "react";

export function LedgerView() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/ledger", { cache: "no-store" });
      const payload = await res.json();
      setData(payload);
      if (!res.ok) setError(payload.message || "Failed to load ledger.");
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }

  async function clear() {
    await fetch("/api/ledger", { method: "DELETE" });
    await load();
  }

  useEffect(() => { load(); }, []);

  const entries = data?.entries ?? [];
  const receipts = data?.receipts ?? [];
  const rejections = data?.rejections ?? [];
  const verification = data?.verification;
  const connected = Boolean(data?.connected);

  return (
    <div className="card section">
      <h2>Ledger + receipts</h2>
      <p className="muted">Proof is only real if a receipt maps to canonical state and the ledger hash chain stays valid.</p>
      {!connected && <p className="muted">Not connected. Configure Postgres to make the ledger authoritative.</p>}
      <button className="secondary" onClick={clear} style={{ marginBottom: 8 }} disabled={!connected}>Clear ledger</button>
      {verification && <p className="muted">Verification: {verification.valid ? `valid (${verification.count})` : verification.message || verification.reason || "invalid"}</p>}
      {data?.canonicalState && <p className="muted code" style={{ fontSize: 12 }}>canonical: v{data.canonicalState.version} · {data.canonicalState.stateHash}</p>}
      {loading && <p className="muted">Loading...</p>}
      {error && <p style={{ color: "var(--danger)" }}>Error: {error}</p>}
      {!loading && entries.length === 0 && <p className="muted">No authoritative entries yet.</p>}
      {!!receipts.length && (
        <div style={{ marginBottom: 16 }}>
          <h3>Recent receipts</h3>
          <ul style={{ listStyle: "none", padding: 0 }}>
            {receipts.map((receipt: any) => (
              <li key={receipt.receiptId} style={{ marginBottom: 10, borderTop: "1px solid var(--border)", paddingTop: 10 }}>
                <div className="muted code" style={{ fontSize: 12 }}>{receipt.receiptId}</div>
                <div><strong>{receipt.action}</strong> · seq {receipt.sequence} · v{receipt.resultingVersion}</div>
                <div className="muted code" style={{ fontSize: 12 }}>proof: {receipt.commitProof}</div>
              </li>
            ))}
          </ul>
        </div>
      )}
      {!!rejections.length && (
        <div style={{ marginBottom: 16 }}>
          <h3>Recent rejected mutations</h3>
          <ul style={{ listStyle: "none", padding: 0 }}>
            {rejections.map((item: any) => (
              <li key={item.rejectionId} style={{ marginBottom: 10, borderTop: "1px solid var(--border)", paddingTop: 10 }}>
                <strong>{item.reason}</strong> <span className="muted">· {item.action}</span>
                <div className="muted code" style={{ fontSize: 12 }}>{item.attemptedHash ? `${item.attemptedHash.slice(0, 20)}…` : "no attempted hash"}</div>
              </li>
            ))}
          </ul>
        </div>
      )}
      <ul style={{ listStyle: "none", padding: 0 }}>
        {entries.map((entry: any) => (
          <li key={entry.id} style={{ marginBottom: 12, borderTop: "1px solid var(--border)", paddingTop: 12 }}>
            <div className="muted" style={{ fontSize: 12 }}>{new Date(entry.timestamp).toLocaleString()}</div>
            <strong>{entry.action}</strong> <span className="muted">by {entry.actor}</span>
            <div className="muted code" style={{ fontSize: 12, marginTop: 4 }}>entry_hash: {entry.entryHash.slice(0, 16)}…</div>
            <div className="muted code" style={{ fontSize: 12 }}>prev_hash: {entry.prevHash ? `${entry.prevHash.slice(0, 16)}…` : "GENESIS"}</div>
            <pre className="output" style={{ whiteSpace: "pre-wrap", wordBreak: "break-word", fontSize: 12, marginTop: 8 }}>{JSON.stringify(entry.details, null, 2)}</pre>
          </li>
        ))}
      </ul>
    </div>
  );
}
