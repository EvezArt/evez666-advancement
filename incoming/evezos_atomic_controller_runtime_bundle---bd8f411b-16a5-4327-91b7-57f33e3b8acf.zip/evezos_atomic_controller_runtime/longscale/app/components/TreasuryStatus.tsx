"use client";

import { useEffect, useState } from "react";

export function TreasuryStatus() {
  const [wallet, setWallet] = useState<any>(null);
  const [balances, setBalances] = useState<any[]>([]);
  const [settlements, setSettlements] = useState<any[]>([]);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      const [walletRes, balanceRes, settlementRes] = await Promise.all([
        fetch("/api/wallet/treasury").catch(() => null),
        fetch("/api/wallet/balances").catch(() => null),
        fetch("/api/settlements").catch(() => null),
      ]);
      const walletJson = walletRes ? await walletRes.json().catch(() => ({})) : {};
      const balanceJson = balanceRes ? await balanceRes.json().catch(() => ({})) : {};
      const settlementJson = settlementRes ? await settlementRes.json().catch(() => ({})) : {};
      setWallet(walletJson.wallet ?? null);
      setBalances(balanceJson.balances ?? []);
      setSettlements(settlementJson.settlements ?? []);
      setMessage(walletJson.message || balanceJson.message || settlementJson.message || null);
    }
    load();
  }, []);

  const confirmed = settlements.filter((s) => s.status === "confirmed");
  const confirmedRevenue = confirmed.reduce((sum, s) => sum + Number(s.netAmount || s.grossAmount || 0), 0);

  return (
    <div className="card section">
      <h2>Treasury and verifiable money state</h2>
      {!wallet ? (
        <p className="muted">Not connected. No wallet address, no live balances, and no revenue totals are shown until real providers are configured.</p>
      ) : (
        <>
          <p><strong>Wallet:</strong> {wallet.address}</p>
          <p><strong>Chain:</strong> {wallet.chainId}</p>
          <p><strong>Provider:</strong> {wallet.provider}</p>
          <p><strong>Confirmed settlements:</strong> {confirmed.length}</p>
          <p><strong>Confirmed net revenue:</strong> {Number.isFinite(confirmedRevenue) ? confirmedRevenue.toFixed(2) : "0.00"}</p>
        </>
      )}
      {balances.length > 0 && (
        <div>
          <h3>Balances</h3>
          <ul>
            {balances.map((b, i) => (<li key={i}>{b.symbol}: {b.formattedBalance}{b.usdValue ? ` ($${b.usdValue})` : ""}</li>))}
          </ul>
        </div>
      )}
      {settlements.length > 0 && (
        <div>
          <h3>Recent settlements</h3>
          <ul>
            {settlements.slice(0, 5).map((s) => (<li key={s.id}>{s.assetSymbol} {s.grossAmount} — {s.status}{s.txHash ? ` — ${s.txHash}` : ""}</li>))}
          </ul>
        </div>
      )}
      {message && <p className="muted">{message}</p>}
    </div>
  );
}
