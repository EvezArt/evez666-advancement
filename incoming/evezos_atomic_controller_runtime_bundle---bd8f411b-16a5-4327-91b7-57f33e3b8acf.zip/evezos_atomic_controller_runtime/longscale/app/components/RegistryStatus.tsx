"use client";

import { useEffect, useState } from "react";

export function RegistryStatus() {
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      try {
        const [registryRes, healthRes] = await Promise.all([fetch("/api/registry"), fetch("/api/health")]);
        const registry = await registryRes.json();
        const health = await healthRes.json();
        setData({ registry, health });
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err));
      }
    }
    load();
  }, []);

  if (error) return <div className="card section"><h2>Registry</h2><p className="muted">{error}</p></div>;
  if (!data) return <div className="card section"><h2>Registry</h2><p className="muted">Loading registry…</p></div>;

  const agents = data.registry.manifest.agents;
  return (
    <div className="card section">
      <h2>Grounded agent registry</h2>
      <p className="muted">Manifest-driven control plane. Canonical state, receipts, and rejections are now first-class health signals.</p>
      <div className="registryGrid">
        {agents.map((agent: any) => (
          <div key={agent.id} className="registryCard card">
            <div className="statusTag">{agent.kind}</div>
            <h3 style={{ marginTop: 8, marginBottom: 8 }}>{agent.name}</h3>
            <p className="muted code" style={{ marginTop: 0 }}>{agent.id}</p>
            <p className="muted">{agent.route || agent.routes?.join(", ") || agent.runtime}</p>
            <p><strong>Status:</strong> {agent.status}</p>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 16 }} className="kv">
        <span>Mode</span><span>{data.health.mode}</span>
        <span>Agent count</span><span>{data.health.agentCount}</span>
        <span>Ledger</span><span>{data.health.ledgerVerification.connected ? (data.health.ledgerVerification.valid ? `connected / valid (${data.health.ledgerVerification.count})` : `connected / invalid`) : "not connected"}</span>
        <span>Bus mirror</span><span>{data.health.envStatus.redis ? "connected" : "not connected"}</span>
        <span>Canonical version</span><span>{data.health.canonicalRuntime?.version ?? 0}</span>
        <span>Last receipt</span><span className="code">{data.health.canonicalRuntime?.lastReceiptId ? `${String(data.health.canonicalRuntime.lastReceiptId).slice(0, 18)}…` : "none"}</span>
        <span>Recent rejections</span><span>{data.health.recentRejections?.length ?? 0}</span>
      </div>
    </div>
  );
}
