"use client";

import { useEffect, useState } from "react";

export function AuthorityProof() {
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/proof", { cache: "no-store" })
      .then((res) => res.json())
      .then(setData)
      .catch((err) => setError(err instanceof Error ? err.message : String(err)));
  }, []);

  if (error) return <div className="card section"><h2>Authority proof</h2><p className="muted">{error}</p></div>;
  if (!data) return <div className="card section"><h2>Authority proof</h2><p className="muted">Loading proof…</p></div>;

  const authoritative = Boolean(data.runtime?.authoritative);
  const latest = data.receipts?.[0];

  return (
    <div className="card section">
      <h2>Authority proof</h2>
      <p className="muted">No receipt means no reality. No canonical commit means no board update.</p>
      <div className="statusTag" style={{ marginBottom: 12, background: authoritative ? "rgba(0,200,120,.15)" : "rgba(255,80,80,.15)", borderColor: authoritative ? "rgba(0,200,120,.35)" : "rgba(255,80,80,.35)" }}>
        {authoritative ? "authoritative runtime" : "untrusted runtime"}
      </div>
      <div className="kv">
        <span>Website</span><span>{data.canonical?.website?.domains?.[0] ?? "missing"}</span>
        <span>Operator</span><span>{data.canonical?.operator?.domains?.[0] ?? "missing"}</span>
        <span>State version</span><span>{data.runtime?.version ?? 0}</span>
        <span>State hash</span><span className="code">{data.runtime?.stateHash ? `${data.runtime.stateHash.slice(0, 16)}…` : "none"}</span>
        <span>Last receipt</span><span className="code">{latest?.receiptId ? `${latest.receiptId.slice(0, 24)}…` : "none"}</span>
        <span>Recent rejections</span><span>{data.rejections?.length ?? 0}</span>
      </div>
      {!!data.issues?.length && (
        <div style={{ marginTop: 16 }}>
          <h3 style={{ marginBottom: 8 }}>Why truth is blocked</h3>
          <ul>
            {data.issues.map((issue: string) => <li key={issue} className="muted">{issue}</li>)}
          </ul>
        </div>
      )}
    </div>
  );
}
