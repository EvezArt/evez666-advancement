"use client";

import { useEffect, useState } from "react";

interface BusTask {
  id: string;
  title: string;
  payload: any;
  status: "pending" | "in_progress" | "completed";
  createdAt: string;
}

export function BusManager() {
  const [tasks, setTasks] = useState<BusTask[]>([]);
  const [title, setTitle] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [connected, setConnected] = useState(false);
  const [lastReceipt, setLastReceipt] = useState<any>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/bus", { cache: "no-store" });
      const data = await res.json();
      setConnected(Boolean(data.authoritative && res.ok));
      setTasks(data.tasks ?? []);
      if (!res.ok) setError(data.message || "Mission bus is not authoritative.");
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setConnected(false);
    } finally {
      setLoading(false);
    }
  }

  async function add() {
    if (!title.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/bus", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, payload: { source: "ui.bus" }, falsifier: "bus.add_task.ui" }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.reason || data.message || "Failed to add task.");
      } else {
        setLastReceipt(data.receipt ?? null);
        setTitle("");
      }
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }

  async function update(id: string, status: BusTask["status"]) {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/bus?id=${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, falsifier: "bus.update_task.ui" }),
      });
      const data = await res.json();
      if (!res.ok) setError(data.reason || data.message || "Failed to update task.");
      else setLastReceipt(data.receipt ?? null);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }

  async function clear() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/bus", { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) setError(data.reason || data.message || "Failed to clear tasks.");
      else setLastReceipt(data.receipt ?? null);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  return (
    <div className="card section">
      <h2>Mission bus</h2>
      <p className="muted">Canonical task state comes from the execution gateway, then mirrors to Redis if available.</p>
      {!connected && <p className="muted">Not authoritative. Configure Postgres and let /api/execute own state before you trust this bus.</p>}
      <div style={{ marginBottom: 8 }}>
        <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="New task title" style={{ padding: 10, width: "70%", marginRight: 8, borderRadius: 10, border: "1px solid var(--border)", background: "rgba(255,255,255,.03)", color: "var(--text)" }} />
        <button className="primary" onClick={add} disabled={loading || !title.trim() || !connected}>Add task</button>
        <button className="secondary" onClick={clear} style={{ marginLeft: 8 }} disabled={!connected}>Clear all</button>
      </div>
      {lastReceipt && <p className="muted code" style={{ fontSize: 12 }}>last_receipt: {lastReceipt.receiptId} · proof {lastReceipt.commitProof}</p>}
      {error && <p style={{ color: "var(--danger)" }}>Error: {error}</p>}
      {loading && <p className="muted">Loading…</p>}
      <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
        {tasks.map((task) => (
          <li key={task.id} style={{ marginBottom: 12, borderTop: "1px solid var(--border)", paddingTop: 12 }}>
            <strong>{task.title}</strong> <span className="muted">({task.status})</span>
            <div className="muted" style={{ fontSize: 12 }}>{new Date(task.createdAt).toLocaleString()}</div>
            <div style={{ marginTop: 6 }}>
              {task.status !== "pending" && <button className="secondary" style={{ marginRight: 4 }} onClick={() => update(task.id, "pending")}>Set pending</button>}
              {task.status !== "in_progress" && <button className="secondary" style={{ marginRight: 4 }} onClick={() => update(task.id, "in_progress")}>In progress</button>}
              {task.status !== "completed" && <button className="secondary" onClick={() => update(task.id, "completed")}>Completed</button>}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
