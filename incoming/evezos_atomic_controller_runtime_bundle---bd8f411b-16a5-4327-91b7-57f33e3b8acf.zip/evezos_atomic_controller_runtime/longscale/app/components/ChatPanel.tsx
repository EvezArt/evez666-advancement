"use client";

import { useState } from "react";

export function ChatPanel() {
  const [messages, setMessages] = useState<{ role: string; content: string }[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault();
    if (!input.trim()) return;

    const nextMessages = [...messages, { role: "user", content: input.trim() }];
    setMessages(nextMessages);
    setInput("");
    setLoading(true);
    setError(null);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: nextMessages }),
      });
      const data = await res.json();
      if (!res.ok || data.success === false) {
        setError(data.message || "Chat provider not connected.");
      } else {
        const reply = data.reply ?? data.output ?? { role: "assistant", content: JSON.stringify(data) };
        setMessages((prev) => [...prev, reply]);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="chatPanel">
      <div className="messages" style={{ maxHeight: "200px", overflowY: "auto" }}>
        {messages.map((m, idx) => (
          <div key={idx} className={m.role === "user" ? "msg user" : "msg assistant"}>
            <strong>{m.role === "user" ? "You" : "AI"}:</strong> {m.content}
          </div>
        ))}
        {loading && <p className="muted">Thinking…</p>}
        {error && <p style={{ color: "#f66" }}>{error}</p>}
        {messages.length === 0 && !loading && !error && <p className="muted">Chat is inactive until a real provider proxy is configured.</p>}
      </div>
      <form onSubmit={sendMessage} style={{ marginTop: "8px" }}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type a message…"
          style={{ width: "100%", padding: "8px" }}
        />
      </form>
    </div>
  );
}
