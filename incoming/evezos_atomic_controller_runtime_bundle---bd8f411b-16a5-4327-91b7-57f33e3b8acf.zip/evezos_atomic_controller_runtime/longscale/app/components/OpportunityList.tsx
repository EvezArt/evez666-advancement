"use client";

import type { Opportunity } from "../../lib/types";

interface Props {
  items: Opportunity[];
  connected?: boolean;
  message?: string | null;
}

export function OpportunityList({ items, connected = false, message }: Props) {
  if (!connected) {
    return <p className="muted">Live opportunities are not connected. {message ?? "Configure LIVE_OPPORTUNITIES_URL."}</p>;
  }

  if (items.length === 0) {
    return <p className="muted">No live opportunities returned.</p>;
  }

  return (
    <div className="opportunityList">
      {items.map((opp) => (
        <div key={opp.id} className="card opportunity">
          <h3>{opp.title}</h3>
          <p className="muted" style={{ marginBottom: "4px" }}>{opp.source}</p>
          <p>{opp.angle}</p>
          <div className="metricsRow">
            {opp.status && <span className="metricTag">Status: {opp.status}</span>}
            {opp.agent && <span className="metricTag">Agent: {opp.agent}</span>}
            {typeof opp.confidence === "number" && <span className="metricTag">Confidence: {opp.confidence}%</span>}
          </div>
        </div>
      ))}
    </div>
  );
}
