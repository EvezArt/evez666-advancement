"use client";

import { useEffect, useState } from "react";
import { OpportunityList } from "./OpportunityList";

export function OpportunitiesLive() {
  const [items, setItems] = useState<any[]>([]);
  const [connected, setConnected] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/opportunities");
        const data = await res.json();
        setItems(data.items ?? []);
        setConnected(Boolean(data.connected && res.ok));
        setMessage(data.message ?? null);
      } catch (error) {
        setConnected(false);
        setMessage(error instanceof Error ? error.message : "Failed to fetch live opportunities.");
      }
    }
    load();
  }, []);

  return <OpportunityList items={items} connected={connected} message={message} />;
}
