# EVEZOS Grounded Runtime Cutover

This package upgrades the live-only longscale surface into a manifest-aware runtime shell.

What changed:
- `data/agents.manifest.json` and `data/workspace-plan.json` are loaded at runtime
- `/api/health` reports env readiness, bus connectivity, and ledger verification
- `/api/registry` exposes the grounded agent manifest and workspace plan
- mission bus moved from module-scope memory to Redis-backed storage
- ledger moved from module-scope memory to Postgres-backed append-only hash chain
- disabled roles remain declared but unavailable until real upstreams exist

Required env for authoritative state:
- `REDIS_URL` or `REDIS_HOST` + `REDIS_PORT`
- `POSTGRES_URL` or `POSTGRES_HOST` + `POSTGRES_DB` (+ credentials)

Still required for live-only finance surfaces:
- `TREASURY_WALLET_ADDRESS`
- `TREASURY_CHAIN_ID`
- `WALLET_PROVIDER`
- `WALLET_BALANCE_API_URL`
- `SETTLEMENTS_API_URL`
- `LIVE_OPPORTUNITIES_URL`
- `OPENAI_RESPONSES_PROXY_URL`
- `N8N_AGENT_RUN_WEBHOOK_URL`
