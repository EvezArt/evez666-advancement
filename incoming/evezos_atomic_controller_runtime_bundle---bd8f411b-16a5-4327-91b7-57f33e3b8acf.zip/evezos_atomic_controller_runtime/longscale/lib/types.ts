export interface Opportunity {
  id: string;
  title: string;
  source: string;
  angle: string;
  revenuePotential?: number | null;
  confidence?: number | null;
  agent?: string | null;
  status?: "live" | "pending" | "not_connected";
}

export interface WalletAccount {
  address: string;
  chainId: string;
  provider: string;
  ownerType: "user" | "treasury";
  updatedAt: string;
}

export interface TokenBalance {
  symbol: string;
  contractAddress?: string | null;
  formattedBalance: string;
  usdValue?: string | null;
  updatedAt: string;
}

export interface SettlementEvent {
  id: string;
  source: "onchain" | "payment_webhook";
  txHash?: string | null;
  externalId?: string | null;
  assetSymbol: string;
  grossAmount: string;
  feeAmount?: string | null;
  netAmount?: string | null;
  status: "pending" | "confirmed" | "failed";
  confirmedAt?: string | null;
  createdAt: string;
}
