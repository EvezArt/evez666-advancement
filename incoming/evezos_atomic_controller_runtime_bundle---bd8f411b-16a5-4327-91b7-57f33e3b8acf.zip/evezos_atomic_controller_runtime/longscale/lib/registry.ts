import manifest from "../data/agents.manifest.json";
import workspacePlan from "../data/workspace-plan.json";

export type AgentManifest = typeof manifest;
export type WorkspacePlan = typeof workspacePlan;

export function getAgentManifest() { return manifest; }
export function getWorkspacePlan() { return workspacePlan; }
export function getAgentById(id: string) { return manifest.agents.find((agent) => agent.id === id) ?? null; }
