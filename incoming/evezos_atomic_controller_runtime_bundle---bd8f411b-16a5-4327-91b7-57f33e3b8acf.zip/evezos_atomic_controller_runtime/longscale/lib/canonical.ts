import registry from "../data/canonical-surface-registry.json";

export function getCanonicalRegistry() {
  return registry;
}

export function getCanonicalWebsite() {
  return registry.canonical.website;
}

export function getCanonicalOperator() {
  return registry.canonical.operator;
}

export function getNonCanonicalSurfaces() {
  return registry.nonCanonical;
}
