export function getPersistenceEnv() {
  return {
    redisUrl: process.env.REDIS_URL || null,
    redisHost: process.env.REDIS_HOST || null,
    redisPort: process.env.REDIS_PORT || null,
    postgresUrl: process.env.POSTGRES_URL || null,
    postgresHost: process.env.POSTGRES_HOST || null,
    postgresPort: process.env.POSTGRES_PORT || null,
    postgresDb: process.env.POSTGRES_DB || null,
  };
}
