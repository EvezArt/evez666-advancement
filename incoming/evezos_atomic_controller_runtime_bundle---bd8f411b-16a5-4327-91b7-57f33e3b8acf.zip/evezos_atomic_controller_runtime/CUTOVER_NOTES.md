# EVEZOS Grounded Runtime Cutover Notes

This package applies the real bridge from UI-only state to backend-owned state.

Included changes:
- `longscale/data/agents.manifest.json` + `workspace-plan.json`
- `/api/registry` and `/api/health`
- Redis-backed mission bus (`agents/bus.ts`)
- Postgres-backed append-only hash-chain ledger (`agents/ledger.ts`)
- mobile shell defaults pointed at the grounded runtime contract

Authoritative-state requirements:
- Redis configured via `REDIS_URL` or `REDIS_HOST` / `REDIS_PORT`
- Postgres configured via `POSTGRES_URL` or host/db credentials
- live provider/webhook envs still required for treasury, chat, opportunities, and cycle run

Still intentionally disabled:
- scanner / predictor / generator / shipper / worldsim remain declared-only until real upstreams exist
- deliverables/workflow telemetry return explicit `not connected` until wired

Do not treat duplicate Vercel rails as truth if they are misconfigured shadow projects.
