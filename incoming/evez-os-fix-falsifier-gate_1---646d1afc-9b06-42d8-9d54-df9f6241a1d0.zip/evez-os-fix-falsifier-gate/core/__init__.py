# EVEZ-OS core package
