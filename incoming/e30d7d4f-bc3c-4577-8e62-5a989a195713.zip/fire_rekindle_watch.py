#!/usr/bin/env python3
"""
FIRE_REKINDLE_WATCH.py - EVEZ-OS Resurrection System
Monitors for stalled/dead agents and rekindles them.
Implements the "eternal" in "verify internally eternally before external".
"""

import json
import time
import asyncio
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Set
import random

class FireRekindleWatch:
    """
    Watches over all FIRE agents and rekindles (restarts) those that stall.
    Ensures 24/7 continuity even when individual agents fail.
    """

    def __init__(self, timeout_seconds: int = 300):
        self.timeout = timeout_seconds  # 5 minute default timeout
        self.agent_registry: Dict[str, Dict] = {}
        self.death_log: List[Dict] = []
        self.rekindle_log: List[Dict] = []
        self.watch_loop_count = 0
        self.heartbeat_history: Dict[str, List[float]] = {}

    def register_agent(self, agent_id: str, agent_type: str, metadata: Dict = None):
        """Register an agent for watching."""
        self.agent_registry[agent_id] = {
            'id': agent_id,
            'type': agent_type,
            'status': 'active',
            'registered_at': datetime.now(timezone.utc).isoformat(),
            'last_heartbeat': time.time(),
            'rekindle_count': 0,
            'metadata': metadata or {}
        }
        self.heartbeat_history[agent_id] = []

    def record_heartbeat(self, agent_id: str, state: Dict = None):
        """Record a heartbeat from an agent."""
        if agent_id not in self.agent_registry:
            return False

        now = time.time()
        self.agent_registry[agent_id]['last_heartbeat'] = now
        self.agent_registry[agent_id]['status'] = 'active'

        # Track heartbeat history for pattern analysis
        self.heartbeat_history[agent_id].append({
            'timestamp': now,
            'state': state or {}
        })

        # Trim history to last 100
        if len(self.heartbeat_history[agent_id]) > 100:
            self.heartbeat_history[agent_id] = self.heartbeat_history[agent_id][-100:]

        return True

    async def watch_cycle(self) -> Dict:
        """
        One watch cycle: check all agents, rekindle dead ones.
        """
        self.watch_loop_count += 1
        cycle_report = {
            'cycle': self.watch_loop_count,
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'checked': 0,
            'dead_found': 0,
            'rekindled': 0,
            'deaths': []
        }

        now = time.time()

        for agent_id, agent in self.agent_registry.items():
            cycle_report['checked'] += 1

            last_beat = agent['last_heartbeat']
            time_since = now - last_beat

            if time_since > self.timeout:
                # Agent is dead
                cycle_report['dead_found'] += 1

                death_record = {
                    'agent_id': agent_id,
                    'died_at': datetime.fromtimestamp(last_beat, timezone.utc).isoformat(),
                    'time_since_heartbeat': time_since,
                    'rekindle_attempt': agent['rekindle_count'] + 1
                }

                cycle_report['deaths'].append(death_record)
                self.death_log.append(death_record)

                # Attempt rekindle
                rekindle_result = await self.rekindle_agent(agent_id)

                if rekindle_result['success']:
                    cycle_report['rekindled'] += 1
                    self.rekindle_log.append({
                        'agent_id': agent_id,
                        'rekindled_at': datetime.now(timezone.utc).isoformat(),
                        'attempt': agent['rekindle_count']
                    })

        return cycle_report

    async def rekindle_agent(self, agent_id: str) -> Dict:
        """
        Rekindle (restart) a dead agent.
        Preserves memory/state if possible, restarts process.
        """
        if agent_id not in self.agent_registry:
            return {'success': False, 'error': 'Agent not registered'}

        agent = self.agent_registry[agent_id]

        # Preserve last known state
        last_state = None
        if self.heartbeat_history.get(agent_id):
            last_state = self.heartbeat_history[agent_id][-1]['state']

        # Increment rekindle count
        agent['rekindle_count'] += 1

        # Simulate rekindle process
        await asyncio.sleep(0.1)  # 100ms rekindle time

        # Reset agent state
        agent['last_heartbeat'] = time.time()
        agent['status'] = 'active'
        agent['rekindled_at'] = datetime.now(timezone.utc).isoformat()

        return {
            'success': True,
            'agent_id': agent_id,
            'preserved_state': last_state,
            'rekindle_count': agent['rekindle_count']
        }

    def get_mortality_stats(self) -> Dict:
        """Get statistics on agent deaths and rekindles."""
        total_agents = len(self.agent_registry)
        total_deaths = len(self.death_log)
        total_rekindles = len(self.rekindle_log)

        # Calculate mortality rate
        mortality_rate = total_deaths / max(self.watch_loop_count, 1)

        # Find most fragile agents
        fragility = {}
        for death in self.death_log:
            aid = death['agent_id']
            fragility[aid] = fragility.get(aid, 0) + 1

        most_fragile = sorted(fragility.items(), key=lambda x: x[1], reverse=True)[:5]

        return {
            'total_agents': total_agents,
            'total_deaths': total_deaths,
            'total_rekindles': total_rekindles,
            'mortality_rate_per_cycle': mortality_rate,
            'most_fragile_agents': most_fragile,
            'watch_cycles': self.watch_loop_count
        }

    async def run_continuous_watch(self, interval: int = 60):
        """Run continuous watch cycle every interval seconds."""
        while True:
            report = await self.watch_cycle()

            if report['dead_found'] > 0:
                print(f"[REKINDLE] Cycle {report['cycle']}: {report['dead_found']} dead, {report['rekindled']} rekindled")
            else:
                print(f"[REKINDLE] Cycle {report['cycle']}: All agents healthy")

            await asyncio.sleep(interval)


class EternalVerifier:
    """
    Implements "verify internally eternally before external verification sensory".
    All internal checks must pass before any external API is called.
    """

    def __init__(self):
        self.verification_queue: List[Dict] = []
        self.external_calls_blocked = 0
        self.external_calls_allowed = 0
        self.verification_log: List[Dict] = []

    async def verify_before_external(self, action: Dict) -> Dict:
        """
        Verify action internally before allowing external call.
        Returns: {'allowed': bool, 'checks': {}, 'reason': str}
        """
        checks = {
            'schema_valid': self.check_schema(action),
            'simulation_passed': await self.simulate_action(action),
            'permissions_confirmed': self.check_permissions(action),
            'audit_trail_ready': self.check_audit_trail(action)
        }

        all_passed = all(checks.values())

        verification_record = {
            'action_id': action.get('id'),
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'checks': checks,
            'result': 'ALLOWED' if all_passed else 'BLOCKED',
            'action_type': action.get('type')
        }

        self.verification_log.append(verification_record)

        if all_passed:
            self.external_calls_allowed += 1
            return {
                'allowed': True,
                'checks': checks,
                'reason': 'All internal verifications passed'
            }
        else:
            self.external_calls_blocked += 1
            failed = [k for k, v in checks.items() if not v]
            return {
                'allowed': False,
                'checks': checks,
                'reason': f"Failed checks: {', '.join(failed)}"
            }

    def check_schema(self, action: Dict) -> bool:
        """Validate action against schema."""
        required = ['id', 'type', 'params']
        return all(k in action for k in required)

    async def simulate_action(self, action: Dict) -> bool:
        """Run simulation of action to verify safety."""
        # Simulate 10ms
        await asyncio.sleep(0.01)

        # Check for dangerous patterns
        dangerous_patterns = ['rm -rf', 'DROP TABLE', 'delete_all']
        action_str = json.dumps(action).lower()

        return not any(p in action_str for p in dangerous_patterns)

    def check_permissions(self, action: Dict) -> bool:
        """Check if action has required permissions."""
        # Placeholder: would check OAuth/Stripe confirmation
        return action.get('permissions_confirmed', False)

    def check_audit_trail(self, action: Dict) -> bool:
        """Check if audit trail is ready."""
        return True  # Placeholder

    def get_verification_stats(self) -> Dict:
        """Get verification statistics."""
        total = len(self.verification_log)
        blocked = self.external_calls_blocked
        allowed = self.external_calls_allowed

        return {
            'total_verifications': total,
            'blocked': blocked,
            'allowed': allowed,
            'block_rate': blocked / max(total, 1),
            'safety_score': allowed / max(total, 1)
        }


# Integration class
class RekindleWithEternalWatch(FireRekindleWatch):
    """
    FireRekindleWatch integrated with EternalVerifier.
    Ensures only verified-safe agents are rekindled.
    """

    def __init__(self, timeout_seconds: int = 300):
        super().__init__(timeout_seconds)
        self.verifier = EternalVerifier()

    async def rekindle_agent(self, agent_id: str) -> Dict:
        """Rekindle with eternal verification."""
        # Create rekindle action
        rekindle_action = {
            'id': f"rekindle_{agent_id}_{int(time.time())}",
            'type': 'REKINDLE',
            'params': {'agent_id': agent_id},
            'permissions_confirmed': True  # Internal system action
        }

        # Verify before executing
        verification = await self.verifier.verify_before_external(rekindle_action)

        if not verification['allowed']:
            return {
                'success': False,
                'error': 'Eternal verification failed',
                'reason': verification['reason']
            }

        # Proceed with rekindle
        return await super().rekindle_agent(agent_id)


if __name__ == "__main__":
    # Demo
    watch = RekindleWithEternalWatch(timeout_seconds=10)

    # Register agents
    watch.register_agent('AGENT_ALPHA', 'explorer')
    watch.register_agent('AGENT_BETA', 'evolver')

    # Simulate heartbeats
    watch.record_heartbeat('AGENT_ALPHA', {'state': 'healthy'})

    # Run one watch cycle
    async def demo():
        report = await watch.watch_cycle()
        print(f"Watch report: {json.dumps(report, indent=2)}")

        stats = watch.get_mortality_stats()
        print(f"\nMortality stats: {json.dumps(stats, indent=2)}")

        vstats = watch.verifier.get_verification_stats()
        print(f"\nVerification stats: {json.dumps(vstats, indent=2)}")

    asyncio.run(demo())
