#!/usr/bin/env python3
"""
RESONANCE_STABILITY.py - EVEZ-OS Stability Engine
Maintains system resonance through continuous self-correction.
Implements recursive correction: 3 consecutive zeros retire loops.
Part of the Invariance Battery for state maintenance.
"""

import json
import time
import asyncio
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple
import numpy as np

class ResonanceStability:
    """
    Maintains stable oscillation in the EVEZ system.
    Detects resonance drift and applies correction forces.
    """

    def __init__(self, target_frequency: float = 1.0, tolerance: float = 0.1):
        self.target_freq = target_frequency  # Target oscillation frequency (Hz)
        self.tolerance = tolerance  # Acceptable drift
        self.current_freq = target_frequency
        self.amplitude = 1.0
        self.phase = 0.0

        self.history: List[Dict] = []
        self.corrections: List[Dict] = []
        self.stability_score = 1.0

    def measure_state(self, system_metrics: Dict) -> Dict:
        """
        Measure current resonance state from system metrics.
        """
        # Extract frequency from metrics
        if 'tick_rate' in system_metrics:
            measured_freq = system_metrics['tick_rate']
        elif 'events_per_second' in system_metrics:
            measured_freq = system_metrics['events_per_second']
        else:
            measured_freq = self.target_freq

        # Calculate drift
        drift = abs(measured_freq - self.target_freq) / self.target_freq

        state = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'measured_freq': measured_freq,
            'target_freq': self.target_freq,
            'drift': drift,
            'amplitude': self.amplitude,
            'phase': self.phase,
            'stable': drift < self.tolerance
        }

        self.history.append(state)

        # Trim history
        if len(self.history) > 1000:
            self.history = self.history[-1000:]

        return state

    def calculate_correction(self, state: Dict) -> Optional[Dict]:
        """
        Calculate correction force needed to restore resonance.
        Returns None if no correction needed.
        """
        if state['stable']:
            return None

        drift = state['drift']

        # PID-like correction
        # Proportional: correction proportional to drift
        # Integral: accumulate drift over time
        # Derivative: rate of change of drift

        p_term = drift * 0.5  # Proportional gain

        # Calculate integral (accumulated drift)
        recent_drift = [h['drift'] for h in self.history[-10:]]
        i_term = sum(recent_drift) * 0.1  # Integral gain

        # Calculate derivative (rate of change)
        if len(recent_drift) >= 2:
            d_term = (recent_drift[-1] - recent_drift[-2]) * 0.3  # Derivative gain
        else:
            d_term = 0

        correction_force = p_term + i_term + d_term

        correction = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'drift': drift,
            'p_term': p_term,
            'i_term': i_term,
            'd_term': d_term,
            'total_force': correction_force,
            'target_adjustment': self.target_freq * correction_force
        }

        self.corrections.append(correction)
        return correction

    def apply_correction(self, correction: Dict) -> Dict:
        """
        Apply correction force to restore resonance.
        """
        # Adjust target frequency slightly to compensate
        adjustment = correction['target_adjustment']
        self.target_freq += adjustment * 0.1  # Damped adjustment

        # Update amplitude based on stability
        if len(self.history) >= 3:
            recent_stable = all(h['stable'] for h in self.history[-3:])
            if recent_stable:
                self.amplitude = min(2.0, self.amplitude * 1.01)  # Grow slowly
            else:
                self.amplitude = max(0.5, self.amplitude * 0.99)  # Decay slowly

        result = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'adjustment_applied': adjustment,
            'new_target_freq': self.target_freq,
            'new_amplitude': self.amplitude,
            'correction_applied': True
        }

        return result

    async def stability_cycle(self, system_metrics: Dict) -> Dict:
        """
        One stability maintenance cycle.
        """
        # Measure current state
        state = self.measure_state(system_metrics)

        # Calculate correction if needed
        correction = self.calculate_correction(state)

        if correction:
            result = self.apply_correction(correction)
        else:
            result = {
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'correction_applied': False,
                'state': 'STABLE'
            }

        # Update stability score
        self.update_stability_score()

        return {
            'state': state,
            'correction': correction,
            'result': result,
            'stability_score': self.stability_score
        }

    def update_stability_score(self):
        """
        Update overall stability score based on history.
        Score = 1.0 (perfect) to 0.0 (unstable)
        """
        if len(self.history) < 10:
            self.stability_score = 1.0
            return

        recent = self.history[-10:]
        stable_ratio = sum(1 for h in recent if h['stable']) / len(recent)
        avg_drift = sum(h['drift'] for h in recent) / len(recent)

        # Score combines stability ratio and inverse drift
        self.stability_score = stable_ratio * (1.0 - avg_drift)

    def get_stability_report(self) -> Dict:
        """Get comprehensive stability report."""
        return {
            'current_frequency': self.current_freq,
            'target_frequency': self.target_freq,
            'amplitude': self.amplitude,
            'stability_score': self.stability_score,
            'total_corrections': len(self.corrections),
            'history_length': len(self.history),
            'currently_stable': self.history[-1]['stable'] if self.history else True
        }


class RecursiveCorrection:
    """
    Implements recursive correction mechanism.
    3 consecutive zero-performance loops are automatically retired.
    """

    def __init__(self):
        self.loop_performance: Dict[str, List[float]] = {}
        self.retired_loops: List[str] = []
        self.correction_threshold = 3  # 3 consecutive zeros

    def record_loop_performance(self, loop_id: str, performance: float):
        """
        Record performance metric for a loop.
        Performance: 0.0 (failed) to 1.0 (perfect)
        """
        if loop_id not in self.loop_performance:
            self.loop_performance[loop_id] = []

        self.loop_performance[loop_id].append(performance)

        # Keep only last 10 performances
        if len(self.loop_performance[loop_id]) > 10:
            self.loop_performance[loop_id] = self.loop_performance[loop_id][-10:]

        # Check for retirement condition
        self.check_retirement(loop_id)

    def check_retirement(self, loop_id: str):
        """
        Check if loop should be retired due to poor performance.
        """
        performances = self.loop_performance.get(loop_id, [])

        if len(performances) < self.correction_threshold:
            return

        # Check last N performances
        recent = performances[-self.correction_threshold:]

        if all(p == 0.0 for p in recent):
            # Retire the loop
            self.retire_loop(loop_id)

    def retire_loop(self, loop_id: str):
        """Retire a poorly performing loop."""
        if loop_id not in self.retired_loops:
            self.retired_loops.append(loop_id)

            # Log retirement
            print(f"[RECURSIVE_CORRECTION] Loop {loop_id} retired after {self.correction_threshold} consecutive zeros")

    def get_loop_status(self, loop_id: str) -> Dict:
        """Get status of a specific loop."""
        return {
            'loop_id': loop_id,
            'active': loop_id not in self.retired_loops,
            'performance_history': self.loop_performance.get(loop_id, []),
            'retired': loop_id in self.retired_loops
        }

    def get_correction_stats(self) -> Dict:
        """Get statistics on recursive corrections."""
        active_loops = len(self.loop_performance) - len(self.retired_loops)

        return {
            'total_loops': len(self.loop_performance),
            'active_loops': active_loops,
            'retired_loops': len(self.retired_loops),
            'retirement_rate': len(self.retired_loops) / max(len(self.loop_performance), 1)
        }


class ResonanceWithCorrection(ResonanceStability):
    """
    ResonanceStability integrated with RecursiveCorrection.
    Maintains system stability while retiring failed loops.
    """

    def __init__(self, target_frequency: float = 1.0, tolerance: float = 0.1):
        super().__init__(target_frequency, tolerance)
        self.corrector = RecursiveCorrection()

    async def stability_cycle(self, system_metrics: Dict, loop_id: str = "main") -> Dict:
        """
        Stability cycle with recursive correction.
        """
        # Check if loop is retired
        if loop_id in self.corrector.retired_loops:
            return {
                'status': 'RETIRED',
                'loop_id': loop_id,
                'reason': '3 consecutive zero performances'
            }

        # Run stability cycle
        result = await super().stability_cycle(system_metrics)

        # Record performance for recursive correction
        performance = result['stability_score']
        self.corrector.record_loop_performance(loop_id, performance)

        result['recursive_correction'] = self.corrector.get_loop_status(loop_id)

        return result


if __name__ == "__main__":
    # Demo
    stability = ResonanceWithCorrection(target_frequency=1.0)

    async def demo():
        for i in range(10):
            metrics = {'tick_rate': 1.0 + (0.1 if i % 3 == 0 else 0)}
            result = await stability.stability_cycle(metrics, loop_id='TEST_LOOP')

            print(f"Cycle {i}: Score={result['stability_score']:.3f}, "
                  f"Stable={result['state']['stable']}")

        report = stability.get_stability_report()
        print(f"\nFinal report: {json.dumps(report, indent=2)}")

        # Test recursive correction
        stability.corrector.record_loop_performance('BAD_LOOP', 0.0)
        stability.corrector.record_loop_performance('BAD_LOOP', 0.0)
        stability.corrector.record_loop_performance('BAD_LOOP', 0.0)

        stats = stability.corrector.get_correction_stats()
        print(f"\nCorrection stats: {json.dumps(stats, indent=2)}")

    asyncio.run(demo())
