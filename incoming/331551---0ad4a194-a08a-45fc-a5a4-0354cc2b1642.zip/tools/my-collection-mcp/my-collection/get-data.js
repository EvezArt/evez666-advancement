/**
 * Retrieves data from the specified endpoint using GET method.
 * 
 * This tool uses postman-runtime to execute the request,
 * ensuring full compatibility with Postman collections.
 */
import { executeRequest } from '../../../lib/postmanExecutor.js';

// Original Postman request definition
const requestDefinition = {
  "name": "Get data",
  "request": {
    "method": "GET",
    "url": {
      "raw": "postman-echo.com/get",
      "host": [
        "postman-echo",
        "com"
      ],
      "path": [
        "get"
      ]
    },
    "header": [],
    "body": null,
    "auth": null
  }
};

// Collection variables (will be merged with environment)
const collectionVariables = [];

/**
 * Executes the API request
 *
 * @param {Object} args - Function arguments
 * @returns {Promise<Object>} API response
 */
const executeFunction = async ({}) => {
  return executeRequest(requestDefinition, {}, collectionVariables);
};

/**
 * Tool definition for Get data
 */
export const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'get_data',
      description: 'Retrieves data from the specified endpoint using GET method.',
      parameters: {
        type: 'object',
        properties: {

        },
        required: []
      }
    }
  }
};
