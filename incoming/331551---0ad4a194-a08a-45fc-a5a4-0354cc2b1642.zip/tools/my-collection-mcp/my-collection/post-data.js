/**
 * Submits data to the API via POST request, reflecting the input data in response.
 * 
 * This tool uses postman-runtime to execute the request,
 * ensuring full compatibility with Postman collections.
 */
import { executeRequest } from '../../../lib/postmanExecutor.js';

// Original Postman request definition
const requestDefinition = {
  "name": "Post data",
  "request": {
    "method": "POST",
    "url": {
      "raw": "postman-echo.com/post",
      "host": [
        "postman-echo",
        "com"
      ],
      "path": [
        "post"
      ]
    },
    "header": [],
    "body": {
      "mode": "raw",
      "raw": "{\n\t\"name\": \"Add your name in the body\"\n}",
      "options": {
        "raw": {
          "language": "json"
        }
      }
    },
    "auth": null
  }
};

// Collection variables (will be merged with environment)
const collectionVariables = [];

/**
 * Executes the API request
 *
 * @param {Object} args - Function arguments
 * @returns {Promise<Object>} API response
 */
const executeFunction = async ({}) => {
  return executeRequest(requestDefinition, {}, collectionVariables);
};

/**
 * Tool definition for Post data
 */
export const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'post_data',
      description: 'Submits data to the API via POST request, reflecting the input data in response.',
      parameters: {
        type: 'object',
        properties: {

        },
        required: []
      }
    }
  }
};
