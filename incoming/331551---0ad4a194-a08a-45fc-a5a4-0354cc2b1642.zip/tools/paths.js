export const toolPaths = [
  'my-collection-mcp/my-collection/get-data.js',
  'my-collection-mcp/my-collection/post-data.js'
];