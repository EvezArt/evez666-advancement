# EVEZ OneCmd

One-line headless kernel.

## One-line commands

Start the service:
```bash
python evez-onecmd.pyz
```

Run a full prompt:
```bash
python evez-onecmd.pyz "Design the least fragile next move."
```

Explicit triad:
```bash
python evez-onecmd.pyz triad "Research, reason, and synthesize the safest action."
```

Health:
```bash
python evez-onecmd.pyz health
curl http://127.0.0.1:8787/health
```
