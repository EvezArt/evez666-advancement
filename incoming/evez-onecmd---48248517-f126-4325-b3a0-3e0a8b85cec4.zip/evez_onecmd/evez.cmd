@echo off
python "%~dp0\evez-onecmd.pyz" %*
