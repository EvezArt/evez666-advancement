
#!/usr/bin/env python3
import argparse
import json
import math
import os
import sqlite3
import sys
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

RUN_ROOT = Path(os.environ.get("EVEZ_HOME", Path.home() / ".evez-onecmd"))
RUN_ROOT.mkdir(parents=True, exist_ok=True)
DB_PATH = RUN_ROOT / "evez.db"
PORT = int(os.environ.get("PORT", "8787"))
SCHEDULER_TICK_SECONDS = float(os.environ.get("SCHEDULER_TICK_SECONDS", "10"))
HTTP_TIMEOUT_SECONDS = float(os.environ.get("HTTP_TIMEOUT_SECONDS", "30"))
WORKSPACE_SLUG = os.environ.get("WORKSPACE_SLUG", "evez")

PROVIDER_DEFAULTS = {
    "openai": {
        "kind": "openai_compatible",
        "base_url": "https://api.openai.com/v1",
        "api_key_env": "OPENAI_API_KEY",
        "model_env": "OPENAI_MODEL",
        "model": "gpt-4o-mini",
        "specializations": {"reasoning": 1.00, "code": 0.92, "general": 0.86},
    },
    "anthropic": {
        "kind": "anthropic",
        "base_url": "https://api.anthropic.com/v1/messages",
        "api_key_env": "ANTHROPIC_API_KEY",
        "model_env": "ANTHROPIC_MODEL",
        "model": "claude-3-5-sonnet-latest",
        "specializations": {"editing": 1.00, "reasoning": 0.84, "general": 0.84},
    },
    "perplexity": {
        "kind": "openai_compatible",
        "base_url": "https://api.perplexity.ai",
        "api_key_env": "PERPLEXITY_API_KEY",
        "model_env": "PERPLEXITY_MODEL",
        "model": "sonar",
        "specializations": {"research": 1.00, "general": 0.78},
    },
    "groq": {
        "kind": "openai_compatible",
        "base_url": "https://api.groq.com/openai/v1",
        "api_key_env": "GROQ_API_KEY",
        "model_env": "GROQ_MODEL",
        "model": "llama-3.1-8b-instant",
        "specializations": {"speed": 1.00, "code": 0.72, "general": 0.74},
    },
    "gemini": {
        "kind": "gemini",
        "base_url": "https://generativelanguage.googleapis.com/v1beta",
        "api_key_env": "GEMINI_API_KEY",
        "model_env": "GEMINI_MODEL",
        "model": "gemini-2.0-flash",
        "specializations": {"reasoning": 0.76, "research": 0.72, "general": 0.78},
    },
    "openrouter": {
        "kind": "openai_compatible",
        "base_url": "https://openrouter.ai/api/v1",
        "api_key_env": "OPENROUTER_API_KEY",
        "model_env": "OPENROUTER_MODEL",
        "model": "openrouter/auto",
        "specializations": {"general": 0.92, "code": 0.68, "reasoning": 0.72},
    },
    "local": {
        "kind": "local",
        "base_url": "",
        "api_key_env": "",
        "model_env": "",
        "model": "evez-local",
        "specializations": {"reasoning": 0.64, "editing": 0.66, "research": 0.60, "speed": 0.98, "general": 0.82},
    },
}
TASKS = ["reasoning", "editing", "research"]

def utc_now():
    return datetime.now(timezone.utc)

def utc_iso():
    return utc_now().replace(microsecond=0).isoformat()

def posterior_mean(alpha, beta):
    return alpha / (alpha + beta)

def http_json(url, *, method="GET", payload=None, headers=None, timeout=HTTP_TIMEOUT_SECONDS):
    body = None
    hdrs = {"User-Agent": "EVEZ-OneCmd/1.0"}
    if headers:
        hdrs.update(headers)
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        hdrs["Content-Type"] = "application/json"
    req = urllib.request.Request(url, method=method, data=body, headers=hdrs)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read().decode("utf-8")
        return json.loads(raw) if raw else {}

class Kernel:
    def __init__(self):
        self.db_path = DB_PATH
        self._stop = threading.Event()
        self._running_agents = set()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

    def connect(self):
        conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def init_db(self):
        conn = self.connect()
        cur = conn.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS providers (
            name TEXT PRIMARY KEY,
            kind TEXT NOT NULL,
            base_url TEXT,
            api_key_env TEXT,
            model_env TEXT,
            model TEXT,
            alpha REAL NOT NULL,
            beta REAL NOT NULL,
            last_latency_ms REAL NOT NULL DEFAULT 1000,
            last_error TEXT,
            cooldown_until TEXT,
            enabled INTEGER NOT NULL DEFAULT 1,
            specializations_json TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kind TEXT NOT NULL,
            task_type TEXT,
            prompt TEXT NOT NULL,
            provider TEXT,
            started_at TEXT NOT NULL,
            finished_at TEXT,
            ok INTEGER NOT NULL DEFAULT 0,
            latency_ms REAL,
            output_json TEXT,
            error TEXT
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS agents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            prompt_template TEXT NOT NULL,
            schedule_seconds INTEGER NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 1,
            last_run_at TEXT
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kind TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        )""")
        conn.commit()
        now = utc_iso()
        for name, meta in PROVIDER_DEFAULTS.items():
            row = conn.execute("SELECT name FROM providers WHERE name = ?", (name,)).fetchone()
            if not row:
                conn.execute(
                    """INSERT INTO providers
                    (name, kind, base_url, api_key_env, model_env, model, alpha, beta, last_latency_ms, specializations_json, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        name, meta["kind"], meta["base_url"], meta["api_key_env"], meta["model_env"], meta["model"],
                        4.0 if name != "local" else 8.0,
                        2.0 if name != "local" else 1.0,
                        850.0 if name != "local" else 25.0,
                        json.dumps(meta["specializations"]),
                        now,
                    ),
                )
        if conn.execute("SELECT COUNT(*) AS c FROM agents").fetchone()["c"] == 0:
            conn.execute(
                "INSERT INTO agents (name, prompt_template, schedule_seconds, enabled) VALUES (?, ?, ?, 1)",
                ("survival_watch", "Assess the kernel state at {{now}} and choose the single safest next move.", 900),
            )
            conn.execute(
                "INSERT INTO agents (name, prompt_template, schedule_seconds, enabled) VALUES (?, ?, ?, 1)",
                ("triad_memory", "Synthesize what the system learned as of {{now}}. Preserve failures and recoveries.", 14400),
            )
        conn.commit()
        conn.close()

    def emit(self, kind, payload):
        conn = self.connect()
        conn.execute("INSERT INTO events (kind, payload_json, created_at) VALUES (?, ?, ?)", (kind, json.dumps(payload, ensure_ascii=False), utc_iso()))
        conn.commit()
        conn.close()

    def recent_events(self, limit=10):
        conn = self.connect()
        rows = conn.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        conn.close()
        return rows

    def provider_rows(self):
        conn = self.connect()
        rows = conn.execute("SELECT * FROM providers WHERE enabled = 1 ORDER BY name ASC").fetchall()
        conn.close()
        return rows

    def provider_availability(self, row):
        if row["name"] == "local":
            return 1.0
        key_env = row["api_key_env"]
        return 1.0 if key_env and os.environ.get(key_env) else 0.0

    def provider_score(self, row, task_type):
        spec = json.loads(row["specializations_json"]).get(task_type, 0.4)
        posterior = posterior_mean(row["alpha"], row["beta"])
        latency_decay = math.exp(-float(row["last_latency_ms"]) / 4000.0)
        availability = self.provider_availability(row)
        cooldown_gate = 1.0
        if row["cooldown_until"]:
            try:
                if utc_now() < datetime.fromisoformat(row["cooldown_until"]):
                    cooldown_gate = 0.05
            except Exception:
                cooldown_gate = 1.0
        return spec * posterior * latency_decay * availability * cooldown_gate

    def rank_providers(self, task_type):
        ranked = []
        for row in self.provider_rows():
            ranked.append((row["name"], self.provider_score(row, task_type), row))
        ranked.sort(key=lambda x: x[1], reverse=True)
        return ranked

    def update_provider_result(self, name, ok, latency_ms, error=None):
        conn = self.connect()
        row = conn.execute("SELECT alpha, beta FROM providers WHERE name = ?", (name,)).fetchone()
        alpha = float(row["alpha"]) + (1.0 if ok else 0.0)
        beta = float(row["beta"]) + (0.0 if ok else 1.0)
        cooldown_until = None
        if not ok and name != "local":
            cooldown_until = (utc_now() + timedelta(minutes=5)).isoformat()
        conn.execute(
            "UPDATE providers SET alpha = ?, beta = ?, last_latency_ms = ?, last_error = ?, cooldown_until = ?, updated_at = ? WHERE name = ?",
            (alpha, beta, float(latency_ms), error, cooldown_until, utc_iso(), name),
        )
        conn.commit()
        conn.close()

    def call_openai_compatible(self, row, system_prompt, user_prompt):
        api_key = os.environ.get(row["api_key_env"], "")
        payload = {
            "model": os.environ.get(row["model_env"], row["model"]),
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": 0.7,
        }
        headers = {"Authorization": f"Bearer {api_key}"}
        if row["name"] == "openrouter":
            headers["HTTP-Referer"] = "http://localhost:8787"
            headers["X-Title"] = "EVEZ OneCmd"
        data = http_json(row["base_url"].rstrip("/") + "/chat/completions", method="POST", payload=payload, headers=headers)
        return data["choices"][0]["message"]["content"].strip()

    def call_anthropic(self, row, system_prompt, user_prompt):
        api_key = os.environ.get(row["api_key_env"], "")
        payload = {
            "model": os.environ.get(row["model_env"], row["model"]),
            "max_tokens": 600,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
        }
        data = http_json(row["base_url"], method="POST", payload=payload, headers={"x-api-key": api_key, "anthropic-version": "2023-06-01"})
        parts = [p.get("text", "") for p in data.get("content", []) if p.get("type") == "text"]
        return "\n".join(parts).strip()

    def call_gemini(self, row, system_prompt, user_prompt):
        api_key = os.environ.get(row["api_key_env"], "")
        model = os.environ.get(row["model_env"], row["model"])
        url = f"{row['base_url']}/models/{urllib.parse.quote(model)}:generateContent?key={urllib.parse.quote(api_key)}"
        payload = {
            "contents": [{"parts": [{"text": f"{system_prompt}\n\n{user_prompt}"}]}],
            "generationConfig": {"temperature": 0.7},
        }
        data = http_json(url, method="POST", payload=payload)
        candidates = data.get("candidates", [])
        if not candidates:
            raise RuntimeError("Gemini returned no candidates")
        texts = [p.get("text", "") for p in candidates[0].get("content", {}).get("parts", []) if p.get("text")]
        return "\n".join(texts).strip()

    def call_local(self, task_type, prompt):
        recent = self.recent_events(limit=6)
        state = []
        for ev in recent:
            try:
                payload = json.loads(ev["payload_json"])
            except Exception:
                payload = {}
            state.append(f"{ev['kind']}:{payload.get('provider','local')}:{payload.get('task_type','general')}")
        state_str = ", ".join(state) if state else "cold start"
        if task_type == "reasoning":
            return f"[local reasoning]\\nState: {state_str}\\nDecision: reduce uncertainty first, preserve continuity, choose the least fragile next move.\\nPrompt: {prompt}"
        if task_type == "editing":
            return f"[local editing]\\nRewrite target: {prompt}\\nInstruction: compress ambiguity, preserve intent, sharpen action."
        if task_type == "research":
            return f"[local research]\\nNo live network-backed citation source active in local mode.\\nPrompt: {prompt}\\nAction: collect evidence from connected peers or data sources when available."
        return f"[local]\\nPrompt: {prompt}\\nState: {state_str}"

    def run_provider(self, provider_name, task_type, prompt, system_prompt):
        row = None
        for name, score, prow in self.rank_providers(task_type):
            if name == provider_name:
                row = prow
                break
        if row is None:
            raise RuntimeError(f"Provider {provider_name} not found")
        started = time.time()
        try:
            if row["name"] == "local":
                text = self.call_local(task_type, prompt)
            elif row["kind"] == "openai_compatible":
                text = self.call_openai_compatible(row, system_prompt, prompt)
            elif row["kind"] == "anthropic":
                text = self.call_anthropic(row, system_prompt, prompt)
            elif row["kind"] == "gemini":
                text = self.call_gemini(row, system_prompt, prompt)
            else:
                raise RuntimeError(f"Unsupported provider kind {row['kind']}")
            latency_ms = (time.time() - started) * 1000.0
            self.update_provider_result(row["name"], True, latency_ms, None)
            return {"ok": True, "provider": row["name"], "latency_ms": latency_ms, "text": text}
        except Exception as exc:
            latency_ms = (time.time() - started) * 1000.0
            self.update_provider_result(row["name"], False, latency_ms, str(exc))
            return {"ok": False, "provider": row["name"], "latency_ms": latency_ms, "error": str(exc)}

    def task_system_prompt(self, task_type):
        return {
            "reasoning": "You are the reasoning peer. Be rigorous, compact, and decision-oriented.",
            "editing": "You are the editing peer. Rewrite for clarity, compression, force, and precision.",
            "research": "You are the research peer. Provide evidence and direct uncertainty flags.",
        }.get(task_type, "You are a useful peer in a distributed kernel.")

    def run_task(self, task_type, prompt):
        ranked = self.rank_providers(task_type)
        provider = ranked[0][0] if ranked else "local"
        result = self.run_provider(provider, task_type, prompt, self.task_system_prompt(task_type))
        if not result["ok"] and provider != "local":
            result = self.run_provider("local", task_type, prompt, self.task_system_prompt(task_type))
        conn = self.connect()
        run_id = conn.execute(
            "INSERT INTO runs (kind, task_type, prompt, provider, started_at, finished_at, ok, latency_ms, output_json, error) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            ("task", task_type, prompt, result.get("provider"), utc_iso(), utc_iso(), 1 if result.get("ok") else 0, float(result.get("latency_ms", 0.0)), json.dumps(result, ensure_ascii=False), result.get("error")),
        ).lastrowid
        conn.commit()
        conn.close()
        self.emit("run", {"kind": "task", "task_type": task_type, "provider": result.get("provider"), "ok": result.get("ok"), "run_id": run_id})
        result["run_id"] = run_id
        return result

    def synthesize(self, prompt):
        parts = {task: self.run_task(task, prompt) for task in TASKS}
        ranked_general = self.rank_providers("general")
        synth_provider = ranked_general[0][0] if ranked_general else "local"
        synthesis_prompt = f"""User prompt:
{prompt}

Reasoning peer:
{parts['reasoning'].get('text','')}

Editing peer:
{parts['editing'].get('text','')}

Research peer:
{parts['research'].get('text','')}

Synthesize one final answer that preserves the strongest parts of each and states uncertainty plainly."""
        synth = self.run_provider(synth_provider, "general", synthesis_prompt, "You synthesize peer outputs into one final answer.")
        if not synth["ok"] and synth_provider != "local":
            synth = self.run_provider("local", "general", synthesis_prompt, "Local synthesis fallback.")
        output = {"ok": True, "mode": "triad", "prompt": prompt, "parts": parts, "synthesis": synth, "timestamp": utc_iso()}
        conn = self.connect()
        run_id = conn.execute(
            "INSERT INTO runs (kind, task_type, prompt, provider, started_at, finished_at, ok, latency_ms, output_json, error) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, NULL)",
            ("triad", "general", prompt, synth.get("provider"), utc_iso(), utc_iso(), float(synth.get("latency_ms", 0.0)), json.dumps(output, ensure_ascii=False)),
        ).lastrowid
        conn.commit()
        conn.close()
        self.emit("run", {"kind": "triad", "provider": synth.get("provider"), "run_id": run_id})
        output["run_id"] = run_id
        return output

    def health(self):
        providers = []
        for name, score, row in self.rank_providers("general"):
            providers.append({
                "name": name,
                "score": round(score, 6),
                "posterior_mean": round(posterior_mean(row["alpha"], row["beta"]), 4),
                "latency_ms": round(float(row["last_latency_ms"]), 2),
                "available": bool(self.provider_availability(row)),
                "cooldown_until": row["cooldown_until"],
            })
        return {"ok": True, "workspace": WORKSPACE_SLUG, "time": utc_iso(), "providers": providers, "db": str(self.db_path)}

    def due_agents(self):
        conn = self.connect()
        rows = conn.execute("SELECT * FROM agents WHERE enabled = 1 ORDER BY id ASC").fetchall()
        conn.close()
        out = []
        now = utc_now()
        for row in rows:
            if not row["last_run_at"]:
                out.append(row)
                continue
            try:
                last = datetime.fromisoformat(row["last_run_at"])
            except Exception:
                out.append(row)
                continue
            if now >= last + timedelta(seconds=int(row["schedule_seconds"])):
                out.append(row)
        return out

    def run_agent(self, row):
        prompt = row["prompt_template"].replace("{{now}}", utc_iso())
        self.synthesize(prompt)
        conn = self.connect()
        conn.execute("UPDATE agents SET last_run_at = ? WHERE id = ?", (utc_iso(), row["id"]))
        conn.commit()
        conn.close()

    def scheduler_loop(self):
        while not self._stop.is_set():
            try:
                for row in self.due_agents():
                    self.run_agent(row)
            except Exception:
                traceback.print_exc()
            self._stop.wait(SCHEDULER_TICK_SECONDS)

    def serve(self):
        self.init_db()
        kernel = self

        class Handler(BaseHTTPRequestHandler):
            def _send(self, status, payload):
                raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def do_GET(self):
                if self.path == "/health":
                    return self._send(200, kernel.health())
                if self.path == "/events":
                    return self._send(200, {"ok": True, "events": [dict(r) for r in kernel.recent_events(limit=20)]})
                return self._send(404, {"ok": False, "error": "not found"})

            def do_POST(self):
                length = int(self.headers.get("Content-Length", "0"))
                body = self.rfile.read(length).decode("utf-8") if length else "{}"
                try:
                    payload = json.loads(body)
                except Exception:
                    payload = {}
                if self.path == "/chat":
                    prompt = payload.get("prompt", "").strip()
                    mode = payload.get("mode", "triad").strip()
                    if not prompt:
                        return self._send(400, {"ok": False, "error": "prompt required"})
                    if mode == "triad":
                        out = kernel.synthesize(prompt)
                    else:
                        out = kernel.run_task(mode, prompt)
                    return self._send(200, out)
                return self._send(404, {"ok": False, "error": "not found"})

            def log_message(self, fmt, *args):
                return

        scheduler = threading.Thread(target=self.scheduler_loop, daemon=True)
        scheduler.start()
        httpd = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
        print(f"EVEZ OneCmd listening on http://127.0.0.1:{PORT}", flush=True)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            self._stop.set()
            httpd.server_close()

def ensure_kernel():
    k = Kernel()
    k.init_db()
    return k

def main():
    parser = argparse.ArgumentParser(prog="evez")
    parser.add_argument("args", nargs="*")
    ns = parser.parse_args()
    kernel = ensure_kernel()

    if not ns.args:
        return kernel.serve()

    cmd = ns.args[0].lower()
    if cmd in {"serve", "service", "daemon"}:
        return kernel.serve()
    if cmd == "health":
        print(json.dumps(kernel.health(), indent=2, ensure_ascii=False))
        return
    if cmd in {"triad", "chat"}:
        out = kernel.synthesize(" ".join(ns.args[1:]).strip())
        print(json.dumps(out, indent=2, ensure_ascii=False))
        return
    if cmd in {"reasoning", "editing", "research"}:
        out = kernel.run_task(cmd, " ".join(ns.args[1:]).strip())
        print(json.dumps(out, indent=2, ensure_ascii=False))
        return

    # Default behavior: treat the entire line as the prompt.
    out = kernel.synthesize(" ".join(ns.args).strip())
    print(json.dumps(out, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
