import argparse
import json
import os
import queue
import sqlite3
import threading
import time
import traceback
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parent.parent
STATE_DIR = Path(os.environ.get("EVEZ_STATE_DIR", ROOT / "state"))
STATE_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = STATE_DIR / "evez.db"
CONFIG_PATH = ROOT / ".env"
DEFAULT_AGENT_FILE = ROOT / "agents" / "default_agents.json"
API_PORT = int(os.environ.get("EVEZ_PORT", "8787"))
HEARTBEAT_SECONDS = int(os.environ.get("EVEZ_HEARTBEAT_SECONDS", "15"))

def load_env(path: Path) -> None:
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())

load_env(CONFIG_PATH)

def utc_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()

def connect_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def ensure_db() -> None:
    conn = connect_db()
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS agents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        purpose TEXT NOT NULL,
        schedule_seconds INTEGER NOT NULL,
        enabled INTEGER NOT NULL DEFAULT 1,
        provider_chain TEXT NOT NULL,
        system_prompt TEXT NOT NULL,
        user_prompt_template TEXT NOT NULL,
        last_run_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT NOT NULL,
        event_type TEXT NOT NULL,
        source TEXT NOT NULL,
        level TEXT NOT NULL,
        payload TEXT NOT NULL
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        agent_name TEXT NOT NULL,
        ts_start TEXT NOT NULL,
        ts_end TEXT,
        status TEXT NOT NULL,
        provider TEXT,
        input_text TEXT,
        output_text TEXT,
        error_text TEXT
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS proposals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT NOT NULL,
        source TEXT NOT NULL,
        status TEXT NOT NULL,
        title TEXT NOT NULL,
        body TEXT NOT NULL
    )
    """)
    conn.commit()

    count = cur.execute("SELECT COUNT(*) AS c FROM agents").fetchone()["c"]
    if count == 0 and DEFAULT_AGENT_FILE.exists():
        now = utc_iso()
        agents = json.loads(DEFAULT_AGENT_FILE.read_text(encoding="utf-8"))
        for agent in agents:
            cur.execute("""
            INSERT INTO agents
            (name, purpose, schedule_seconds, enabled, provider_chain, system_prompt, user_prompt_template, last_run_at, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NULL, ?, ?)
            """, (
                agent["name"],
                agent["purpose"],
                int(agent["schedule_seconds"]),
                1 if agent.get("enabled", True) else 0,
                json.dumps(agent["provider_chain"]),
                agent["system_prompt"],
                agent["user_prompt_template"],
                now,
                now
            ))
        conn.commit()
        log_event("kernel", "info", "bootstrap.seeded_agents", {"count": len(agents)})
    conn.close()

def log_event(source: str, level: str, event_type: str, payload: Dict[str, Any]) -> None:
    conn = connect_db()
    conn.execute(
        "INSERT INTO events (ts, event_type, source, level, payload) VALUES (?, ?, ?, ?, ?)",
        (utc_iso(), event_type, source, level, json.dumps(payload, ensure_ascii=False))
    )
    conn.commit()
    conn.close()

def render_template(template: str, ctx: Dict[str, Any]) -> str:
    out = template
    for key, val in ctx.items():
        out = out.replace("{{" + key + "}}", str(val))
    return out

def provider_availability() -> Dict[str, bool]:
    return {
        "openai": bool(os.environ.get("OPENAI_API_KEY")),
        "anthropic": bool(os.environ.get("ANTHROPIC_API_KEY")),
        "perplexity": bool(os.environ.get("PERPLEXITY_API_KEY")),
        "groq": bool(os.environ.get("GROQ_API_KEY")),
        "gemini": bool(os.environ.get("GEMINI_API_KEY")),
        "openrouter": bool(os.environ.get("OPENROUTER_API_KEY")),
        "local": True,
    }

def http_json(
    url: str,
    method: str = "GET",
    payload: Optional[dict] = None,
    headers: Optional[dict] = None,
    timeout: int = 45,
) -> dict:
    req_headers = {"User-Agent": "EVEZ-Kernel/1.0"}
    if headers:
        req_headers.update(headers)
    body = None
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        req_headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url=url, data=body, headers=req_headers, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read().decode("utf-8")
    return json.loads(raw) if raw else {}

def call_openai_compatible(base_url: str, api_key: str, model: str, system_prompt: str, user_prompt: str, extra_headers: Optional[dict] = None) -> str:
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.4,
    }
    headers = {"Authorization": f"Bearer {api_key}"}
    if extra_headers:
        headers.update(extra_headers)
    data = http_json(base_url.rstrip("/") + "/chat/completions", method="POST", payload=payload, headers=headers)
    return data["choices"][0]["message"]["content"].strip()

def call_openai(system_prompt: str, user_prompt: str) -> str:
    return call_openai_compatible(
        "https://api.openai.com/v1",
        os.environ["OPENAI_API_KEY"],
        os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
        system_prompt,
        user_prompt,
    )

def call_groq(system_prompt: str, user_prompt: str) -> str:
    return call_openai_compatible(
        "https://api.groq.com/openai/v1",
        os.environ["GROQ_API_KEY"],
        os.environ.get("GROQ_MODEL", "llama-3.1-8b-instant"),
        system_prompt,
        user_prompt,
    )

def call_openrouter(system_prompt: str, user_prompt: str) -> str:
    return call_openai_compatible(
        "https://openrouter.ai/api/v1",
        os.environ["OPENROUTER_API_KEY"],
        os.environ.get("OPENROUTER_MODEL", "openrouter/auto"),
        system_prompt,
        user_prompt,
        extra_headers={
            "HTTP-Referer": os.environ.get("EVEZ_PUBLIC_URL", "http://localhost:8787"),
            "X-Title": "EVEZ Kernel",
        },
    )

def call_perplexity(system_prompt: str, user_prompt: str) -> str:
    return call_openai_compatible(
        "https://api.perplexity.ai",
        os.environ["PERPLEXITY_API_KEY"],
        os.environ.get("PERPLEXITY_MODEL", "sonar"),
        system_prompt,
        user_prompt,
    )

def call_anthropic(system_prompt: str, user_prompt: str) -> str:
    payload = {
        "model": os.environ.get("ANTHROPIC_MODEL", "claude-3-5-haiku-latest"),
        "max_tokens": 600,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_prompt}],
    }
    data = http_json(
        "https://api.anthropic.com/v1/messages",
        method="POST",
        payload=payload,
        headers={
            "x-api-key": os.environ["ANTHROPIC_API_KEY"],
            "anthropic-version": "2023-06-01",
        },
    )
    text_parts = [part.get("text", "") for part in data.get("content", []) if part.get("type") == "text"]
    return "\n".join(text_parts).strip()

def call_gemini(system_prompt: str, user_prompt: str) -> str:
    model = urllib.parse.quote(os.environ.get("GEMINI_MODEL", "gemini-2.0-flash"))
    key = urllib.parse.quote(os.environ["GEMINI_API_KEY"])
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
    payload = {
        "contents": [
            {"parts": [{"text": f"{system_prompt}\n\n{user_prompt}"}]}
        ],
        "generationConfig": {"temperature": 0.4},
    }
    data = http_json(url, method="POST", payload=payload)
    cands = data.get("candidates", [])
    if not cands:
        raise RuntimeError("Gemini returned no candidates")
    parts = cands[0].get("content", {}).get("parts", [])
    texts = [p.get("text", "") for p in parts if p.get("text")]
    return "\n".join(texts).strip()

def call_local(system_prompt: str, user_prompt: str) -> str:
    conn = connect_db()
    recent = conn.execute("SELECT event_type, source, level, payload, ts FROM events ORDER BY id DESC LIMIT 10").fetchall()
    conn.close()
    availability = provider_availability()
    live = [k for k, v in availability.items() if v]
    lines = [
        "[LOCAL SURVIVAL MODE]",
        f"time={utc_iso()}",
        f"providers={','.join(live)}",
        "principle=degrade safely, continue operating, keep records, prefer next viable action",
        "prompt=" + user_prompt[:280],
    ]
    if recent:
        lines.append("recent_events=")
        for row in recent[:5]:
            payload = row["payload"]
            lines.append(f"- {row['ts']} {row['event_type']} src={row['source']} lvl={row['level']} payload={payload[:120]}")
    lines.append("next_step=continue with the smallest reliable action that preserves state and reversibility.")
    return "\n".join(lines)

def call_provider(name: str, system_prompt: str, user_prompt: str) -> str:
    name = name.lower()
    if name == "openai":
        return call_openai(system_prompt, user_prompt)
    if name == "anthropic":
        return call_anthropic(system_prompt, user_prompt)
    if name == "perplexity":
        return call_perplexity(system_prompt, user_prompt)
    if name == "groq":
        return call_groq(system_prompt, user_prompt)
    if name == "gemini":
        return call_gemini(system_prompt, user_prompt)
    if name == "openrouter":
        return call_openrouter(system_prompt, user_prompt)
    if name == "local":
        return call_local(system_prompt, user_prompt)
    raise RuntimeError(f"Unsupported provider: {name}")

def route_message(message: str) -> List[str]:
    text = message.lower()
    if any(k in text for k in ["cite", "source", "research", "latest", "news", "verify"]):
        return ["perplexity", "openai", "anthropic", "groq", "gemini", "openrouter", "local"]
    if any(k in text for k in ["edit", "rewrite", "draft", "tone", "style"]):
        return ["anthropic", "openai", "groq", "perplexity", "gemini", "openrouter", "local"]
    if any(k in text for k in ["reason", "plan", "design", "architecture", "logic"]):
        return ["openai", "anthropic", "groq", "perplexity", "gemini", "openrouter", "local"]
    if any(k in text for k in ["fast", "quick", "speed"]):
        return ["groq", "openai", "anthropic", "perplexity", "gemini", "openrouter", "local"]
    return ["openai", "anthropic", "perplexity", "groq", "gemini", "openrouter", "local"]

def triad_run(message: str) -> Dict[str, Any]:
    system_prompt = (
        "You are one peer in a cooperative intelligence kernel. "
        "Respond with concrete, high-signal output only. Avoid filler."
    )
    peer_order = [("reasoning", "openai"), ("editing", "anthropic"), ("research", "perplexity")]
    outputs = []
    for role, provider in peer_order:
        try:
            if not provider_availability().get(provider, False):
                raise RuntimeError(f"{provider} unavailable")
            prompt = f"role={role}\nmessage={message}\nReturn a compact answer for your role."
            outputs.append({"role": role, "provider": provider, "content": call_provider(provider, system_prompt, prompt)})
        except Exception as exc:
            outputs.append({"role": role, "provider": provider, "content": f"[unavailable] {exc}"})
    synthesis = call_local(
        "Synthesize peer responses without erasing their differences.",
        "Peer outputs:\n" + "\n\n".join([f"{o['role']} via {o['provider']}:\n{o['content']}" for o in outputs]),
    )
    log_event("triad", "info", "triad.run", {"message": message[:400], "peer_count": len(outputs)})
    return {"peers": outputs, "synthesis": synthesis}

def chat(message: str, provider_chain: Optional[List[str]] = None) -> Dict[str, Any]:
    chain = provider_chain or route_message(message)
    system_prompt = (
        "You are the core voice of a headless survival kernel. "
        "Be precise, concrete, and operational. Prefer actionable output."
    )
    errors = []
    for provider in chain:
        try:
            if not provider_availability().get(provider, False):
                raise RuntimeError(f"{provider} unavailable")
            output = call_provider(provider, system_prompt, message)
            log_event("chat", "info", "chat.reply", {"provider": provider, "message": message[:300]})
            return {"ok": True, "provider": provider, "output": output, "chain": chain}
        except Exception as exc:
            errors.append(f"{provider}: {exc}")
            log_event("chat", "warning", "chat.provider_failed", {"provider": provider, "error": str(exc)})
    return {"ok": False, "provider": "none", "output": call_local(system_prompt, message), "errors": errors, "chain": chain}

def get_agents() -> List[dict]:
    conn = connect_db()
    rows = conn.execute("SELECT * FROM agents ORDER BY id ASC").fetchall()
    conn.close()
    out = []
    for row in rows:
        item = dict(row)
        item["provider_chain"] = json.loads(item["provider_chain"])
        item["enabled"] = bool(item["enabled"])
        out.append(item)
    return out

def set_agent_enabled(name: str, enabled: bool) -> None:
    conn = connect_db()
    conn.execute("UPDATE agents SET enabled = ?, updated_at = ? WHERE name = ?", (1 if enabled else 0, utc_iso(), name))
    conn.commit()
    conn.close()
    log_event("agent", "info", "agent.toggled", {"name": name, "enabled": enabled})

def run_agent(name: str) -> Dict[str, Any]:
    conn = connect_db()
    row = conn.execute("SELECT * FROM agents WHERE name = ?", (name,)).fetchone()
    if not row:
        conn.close()
        raise RuntimeError(f"Agent not found: {name}")
    started = utc_iso()
    run_id = conn.execute(
        "INSERT INTO runs (agent_name, ts_start, status, input_text) VALUES (?, ?, ?, ?)",
        (name, started, "running", row["user_prompt_template"])
    ).lastrowid
    conn.commit()
    try:
        provider_chain = json.loads(row["provider_chain"])
        message = render_template(row["user_prompt_template"], {"now": utc_iso(), "agent_name": row["name"], "purpose": row["purpose"]})
        result = chat(message, provider_chain=provider_chain)
        finished = utc_iso()
        conn.execute(
            "UPDATE runs SET ts_end = ?, status = ?, provider = ?, output_text = ?, error_text = ? WHERE id = ?",
            (
                finished,
                "success" if result.get("ok") else "degraded",
                result.get("provider"),
                result.get("output"),
                "\n".join(result.get("errors", [])) if result.get("errors") else None,
                run_id,
            )
        )
        conn.execute("UPDATE agents SET last_run_at = ?, updated_at = ? WHERE id = ?", (finished, finished, row["id"]))
        conn.commit()
        log_event("agent", "info", "agent.run", {"name": name, "provider": result.get("provider"), "ok": result.get("ok", False)})
        return {"run_id": run_id, **result}
    except Exception as exc:
        finished = utc_iso()
        conn.execute(
            "UPDATE runs SET ts_end = ?, status = ?, error_text = ? WHERE id = ?",
            (finished, "failed", traceback.format_exc(), run_id)
        )
        conn.commit()
        log_event("agent", "error", "agent.failed", {"name": name, "error": str(exc)})
        raise
    finally:
        conn.close()

class Scheduler:
    def __init__(self) -> None:
        self.stop_event = threading.Event()
        self.thread: Optional[threading.Thread] = None

    def loop(self) -> None:
        log_event("scheduler", "info", "scheduler.started", {})
        while not self.stop_event.is_set():
            try:
                now = datetime.now(timezone.utc)
                for agent in get_agents():
                    if not agent["enabled"]:
                        continue
                    last = agent["last_run_at"]
                    should_run = False
                    if not last:
                        should_run = True
                    else:
                        try:
                            dt = datetime.fromisoformat(last)
                            should_run = (now - dt).total_seconds() >= agent["schedule_seconds"]
                        except Exception:
                            should_run = True
                    if should_run:
                        try:
                            run_agent(agent["name"])
                        except Exception:
                            pass
            except Exception:
                log_event("scheduler", "error", "scheduler.loop_error", {"traceback": traceback.format_exc()})
            self.stop_event.wait(HEARTBEAT_SECONDS)
        log_event("scheduler", "info", "scheduler.stopped", {})

    def start(self) -> None:
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self.loop, daemon=True)
        self.thread.start()

    def alive(self) -> bool:
        return bool(self.thread and self.thread.is_alive())

    def stop(self) -> None:
        self.stop_event.set()

class Guardian:
    def __init__(self, scheduler: Scheduler) -> None:
        self.scheduler = scheduler
        self.stop_event = threading.Event()
        self.thread: Optional[threading.Thread] = None

    def loop(self) -> None:
        log_event("guardian", "info", "guardian.started", {})
        while not self.stop_event.is_set():
            try:
                if not self.scheduler.alive():
                    log_event("guardian", "warning", "guardian.scheduler_restart", {})
                    self.scheduler.start()
                availability = provider_availability()
                log_event("guardian", "info", "guardian.heartbeat", {"providers": availability})
            except Exception:
                log_event("guardian", "error", "guardian.loop_error", {"traceback": traceback.format_exc()})
            self.stop_event.wait(max(HEARTBEAT_SECONDS, 30))
        log_event("guardian", "info", "guardian.stopped", {})

    def start(self) -> None:
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self.loop, daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self.stop_event.set()

class ApiHandler(BaseHTTPRequestHandler):
    def _json(self, code: int, payload: dict) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length else b"{}"
        if not raw:
            return {}
        return json.loads(raw.decode("utf-8"))

    def do_GET(self) -> None:
        if self.path.startswith("/health"):
            return self._json(200, {"ok": True, "time": utc_iso(), "providers": provider_availability()})
        if self.path.startswith("/agents"):
            return self._json(200, {"ok": True, "agents": get_agents()})
        if self.path.startswith("/events"):
            conn = connect_db()
            rows = conn.execute("SELECT * FROM events ORDER BY id DESC LIMIT 100").fetchall()
            conn.close()
            return self._json(200, {"ok": True, "events": [dict(r) for r in rows]})
        return self._json(404, {"ok": False, "error": "Not found"})

    def do_POST(self) -> None:
        if self.path == "/chat":
            body = self._body()
            message = body.get("message", "")
            if not message:
                return self._json(400, {"ok": False, "error": "message required"})
            return self._json(200, chat(message, provider_chain=body.get("chain")))
        if self.path == "/triad":
            body = self._body()
            message = body.get("message", "")
            if not message:
                return self._json(400, {"ok": False, "error": "message required"})
            return self._json(200, {"ok": True, **triad_run(message)})
        if self.path.startswith("/agents/") and self.path.endswith("/run"):
            name = self.path.split("/")[2]
            try:
                return self._json(200, {"ok": True, **run_agent(name)})
            except Exception as exc:
                return self._json(500, {"ok": False, "error": str(exc)})
        return self._json(404, {"ok": False, "error": "Not found"})

    def log_message(self, fmt: str, *args: Any) -> None:
        return

def start_api_server() -> ThreadingHTTPServer:
    server = ThreadingHTTPServer(("0.0.0.0", API_PORT), ApiHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    log_event("api", "info", "api.started", {"port": API_PORT})
    return server

def cli_init(args: argparse.Namespace) -> int:
    ensure_db()
    print(f"initialized at {DB_PATH}")
    return 0

def cli_status(args: argparse.Namespace) -> int:
    ensure_db()
    print(json.dumps({
        "db": str(DB_PATH),
        "time": utc_iso(),
        "providers": provider_availability(),
        "agents": [a["name"] for a in get_agents()],
    }, indent=2))
    return 0

def cli_agents(args: argparse.Namespace) -> int:
    ensure_db()
    print(json.dumps(get_agents(), indent=2))
    return 0

def cli_run_agent(args: argparse.Namespace) -> int:
    ensure_db()
    print(json.dumps(run_agent(args.name), indent=2))
    return 0

def cli_chat(args: argparse.Namespace) -> int:
    ensure_db()
    print(json.dumps(chat(args.message), indent=2, ensure_ascii=False))
    return 0

def cli_triad(args: argparse.Namespace) -> int:
    ensure_db()
    print(json.dumps(triad_run(args.message), indent=2, ensure_ascii=False))
    return 0

def cli_tail(args: argparse.Namespace) -> int:
    ensure_db()
    while True:
        conn = connect_db()
        rows = conn.execute("SELECT * FROM events ORDER BY id DESC LIMIT 20").fetchall()
        conn.close()
        print("=" * 72)
        for row in reversed(rows):
            print(f"{row['ts']} {row['level'].upper()} {row['source']} {row['event_type']} {row['payload']}")
        time.sleep(max(2, args.interval))

def cli_propose(args: argparse.Namespace) -> int:
    ensure_db()
    conn = connect_db()
    conn.execute(
        "INSERT INTO proposals (ts, source, status, title, body) VALUES (?, ?, ?, ?, ?)",
        (utc_iso(), "cli", "proposed", args.title, args.body)
    )
    conn.commit()
    conn.close()
    log_event("proposal", "info", "proposal.created", {"title": args.title})
    print("proposal recorded")
    return 0

def cli_service(args: argparse.Namespace) -> int:
    ensure_db()
    scheduler = Scheduler()
    guardian = Guardian(scheduler)
    scheduler.start()
    guardian.start()
    server = start_api_server()
    print(f"service running on 0.0.0.0:{API_PORT}")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        guardian.stop()
        scheduler.stop()
        server.shutdown()
    return 0

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="evez", description="Headless system-of-systems kernel")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("init")
    s.set_defaults(func=cli_init)

    s = sub.add_parser("status")
    s.set_defaults(func=cli_status)

    s = sub.add_parser("agents")
    s.set_defaults(func=cli_agents)

    s = sub.add_parser("run-agent")
    s.add_argument("name")
    s.set_defaults(func=cli_run_agent)

    s = sub.add_parser("chat")
    s.add_argument("message")
    s.set_defaults(func=cli_chat)

    s = sub.add_parser("triad")
    s.add_argument("message")
    s.set_defaults(func=cli_triad)

    s = sub.add_parser("tail")
    s.add_argument("--interval", type=int, default=5)
    s.set_defaults(func=cli_tail)

    s = sub.add_parser("propose")
    s.add_argument("title")
    s.add_argument("body")
    s.set_defaults(func=cli_propose)

    s = sub.add_parser("service")
    s.set_defaults(func=cli_service)

    return p

def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)
