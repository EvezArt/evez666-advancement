@echo off
python __main__.py init
python __main__.py service
