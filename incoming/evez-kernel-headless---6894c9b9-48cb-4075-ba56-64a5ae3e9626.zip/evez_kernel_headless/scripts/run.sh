#!/usr/bin/env bash
set -euo pipefail
python __main__.py init
exec python __main__.py service
