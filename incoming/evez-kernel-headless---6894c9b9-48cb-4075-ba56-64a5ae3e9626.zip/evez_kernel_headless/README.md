# EVEZ Kernel Headless

A headless, portable runtime for scheduled agents and multi-provider chat routing.

No dashboard.
No client secrets.
One kernel, one event spine, one chat/API surface.

## What it is

- Standard-library Python only
- SQLite event spine and run history
- Scheduled agents with watchdog restart
- Headless HTTP API
- CLI / terminal chat
- Provider-preserving routing:
  - OpenAI for reasoning
  - Anthropic for editing
  - Perplexity for research
  - Groq for speed
  - Gemini / OpenRouter as fallbacks
  - Local survival mode when everything else is down

## What it is not

It is not immortal.
It cannot guarantee "never fail".
It is built to degrade safely, keep operating, preserve state, and choose the next viable action when providers or keys fail.

## Quick start

### Python
```bash
cp .env.example .env
python __main__.py init
python __main__.py service
```

### Chat / CLI
```bash
python __main__.py chat "Design the next reliable move."
python __main__.py triad "Research and synthesize the safest market entry plan."
python __main__.py run-agent steward
```

### API
```bash
curl http://localhost:8787/health
curl -X POST http://localhost:8787/chat -H "Content-Type: application/json" -d '{"message":"Give me the next operational move."}'
curl -X POST http://localhost:8787/triad -H "Content-Type: application/json" -d '{"message":"Compare risks, evidence, and strategy."}'
```

## Files

- `__main__.py` — entry point
- `kernel/core.py` — runtime, scheduler, API, providers
- `agents/default_agents.json` — seeded agents
- `.env.example` — provider placeholders
- `system_manifest.json` — kernel contracts and lineage
- `scripts/run.sh` / `scripts/run.bat` — simple launchers
- `Dockerfile` — optional container
- `docker-compose.yml` — optional background runtime

## Run everywhere

- Linux / macOS / Windows with Python 3.11+
- Docker / VPS / Oracle / any small Linux box
- Termux if Python is available
- Headless server with no browser required

## Seed agents

- `sentinel` — checks provider posture and records degraded mode
- `steward` — generates operational summaries
- `archivist` — compacts state into a survivable next-step record

## Security

Do not place secrets in the client.
Only put fresh rotated keys in `.env` on the machine that runs the kernel.

## Default port

`8787`
