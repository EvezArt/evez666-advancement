import subprocess
import os
import json
import time

def run_script(script_name: str):
    print(f"\n{'='*20} Running {script_name} {'='*20}")
    result = subprocess.run(["python3", f"/home/ubuntu/{script_name}"], capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print(f"ERROR in {script_name}: {result.stderr}")
    return result.returncode == 0

def verify_pipeline():
    print(f"\n{'='*20} Verifying Pipeline Outputs {'='*20}")
    
    # Check AGI Engine Output
    if os.path.exists("/home/ubuntu/pipeline_output.json"):
        with open("/home/ubuntu/pipeline_output.json", "r") as f:
            data = json.load(f)
            print(f"[+] AGI Engine Output Found: CE ID {data['ce']['id']}, Final State: {data['final_state']}")
    else:
        print("[!] AGI Engine Output Missing.")

    # Check Execution Log
    if os.path.exists("/home/ubuntu/execution_log.json"):
        print("[+] Execution Log Found.")
    else:
        print("[!] Execution Log Missing.")

    # Check Integration Logs
    logs = ["sentry_log.json", "slack_log.json", "postman_log.json", "vercel_log.json"]
    for log in logs:
        if os.path.exists(f"/home/ubuntu/{log}"):
            print(f"[+] Integration Log Found: {log}")
        else:
            print(f"[!] Integration Log Missing: {log}")

if __name__ == "__main__":
    print(f"Starting EVEZ AGI Pipeline E2E Test at {time.ctime()}")
    
    # Step 1: Run AGI Engine
    if run_script("evez_agi_engine.py"):
        # Step 2: Run n8n Flow Simulator
        if run_script("n8n_flow_simulator.py"):
            # Step 3: Run Integration Simulator
            run_script("evez_integration_simulator.py")
    
    # Step 4: Verify Results
    verify_pipeline()
    print(f"\nEVEZ AGI Pipeline E2E Test Completed at {time.ctime()}")
