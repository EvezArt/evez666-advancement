# EVEZ AGI Deployment Guide

## 1. Prerequisites

Before deploying the EVEZ AGI Pipeline, ensure you have the following:

- **API Keys**:
  - `GROQ_API_KEY`: For high-velocity LLM processing.
  - `GEMINI_API_KEY`: For multi-modal and fallback processing.
  - `OPENROUTER_API_KEY`: For access to a wide range of AI models.
- **Infrastructure**:
  - **n8n**: For workflow orchestration and webhook triggers.
  - **Sentry.io**: For error tracking and observability.
  - **Slack**: For real-time alerts and notifications.
  - **GitHub/Vercel**: For CI/CD and automated deployments.
  - **Base44**: For execution of DeFi and on-chain actions.

## 2. Installation

1. **Clone the Repository**:
   ```bash
   gh repo clone evez666/agi-engine
   cd agi-engine
   ```

2. **Set Environment Variables**:
   Create a `.env` file and add your API keys:
   ```bash
   GROQ_API_KEY=your_groq_key
   GEMINI_API_KEY=your_gemini_key
   OPENROUTER_API_KEY=your_openrouter_key
   ```

3. **Install Dependencies**:
   ```bash
   pip install requests
   ```

## 3. Running the AGI Engine

The core engine can be run as a standalone script or integrated into a larger system:

```bash
python3 evez_agi_engine.py
```

This will generate a Cognitive Event, run it through the Invariance Battery, and trigger the n8n webhook.

## 4. Configuring the n8n Flow

1. **Create a New Workflow**: In n8n, create a new workflow and add a **Webhook Trigger** node.
2. **Add a Condition Block**: After the webhook, add an **IF Node** to evaluate the `consistent` flag from the engine's output.
3. **Branching**:
   - **True Path**: Connect to nodes for Vercel deployment or Base44 transactions.
   - **False Path**: Connect to nodes for Slack alerts and Sentry logging.
4. **Deploy**: Activate the workflow and copy the webhook URL into the `evez_agi_engine.py` script.

## 5. Monitoring and Observability

- **Sentry**: Monitor the `steven-crawford-maggard.sentry.io` dashboard for any runtime errors or Invariance Battery failures.
- **Slack**: Join the `evez666` and `evez.slack` channels for real-time notifications of cognitive events and system status.
- **Postman**: Use the provided Postman collection to manually test the pipeline endpoints and validate the Invariance Battery logic.

## 6. Conclusion

The EVEZ AGI Pipeline is now ready for 24/7 operation. By following this guide, you ensure that your infrastructure is unified, self-consistent, and capable of achieving negative latency across all cognitive surfaces.
