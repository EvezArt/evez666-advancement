
const state = { token: localStorage.getItem('evez_token') || '', data: null };
const qs = (s) => document.querySelector(s);

async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (state.token) headers['X-Session-Token'] = state.token;
  const res = await fetch(path, { headers, ...options });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || JSON.stringify(data));
  return data;
}
function chip(text, live) {
  const span = document.createElement('span');
  span.className = `chip ${live ? 'live' : 'dead'}`;
  span.textContent = text;
  return span;
}
function short(text, max=180) {
  text = text || '';
  return text.length > max ? text.slice(0, max-1) + '…' : text;
}
function renderProviders(providers) {
  const host = qs('#providers'), tpl = qs('#providerTemplate');
  host.innerHTML = '';
  Object.entries(providers).forEach(([key, info]) => {
    const node = tpl.content.cloneNode(true);
    node.querySelector('.provider-name').textContent = `${info.label} (${key})`;
    const liveEl = node.querySelector('.provider-live');
    liveEl.textContent = info.live ? 'live' : 'offline';
    liveEl.classList.add(info.live ? 'live' : 'dead');
    node.querySelector('.provider-model').textContent = `model: ${info.model}`;
    const strengths = node.querySelector('.provider-strengths');
    (info.strengths || []).forEach((s) => strengths.appendChild(chip(s, true)));
    node.querySelector('.provider-contract').textContent = `contract: citations=${!!info.contract.citations}, json=${!!info.contract.json}, web=${!!info.contract.web}`;
    host.appendChild(node);
  });
}
function renderRuns(host, runs) {
  host.innerHTML = '';
  if (!runs.length) {
    const empty = document.createElement('div'); empty.className='muted'; empty.textContent='No runs yet.'; host.appendChild(empty); return;
  }
  runs.forEach((run) => {
    const div = document.createElement('div'); div.className = 'run';
    const out = run.output || {};
    div.innerHTML = `<div><span class="chip ${run.status === 'success' ? 'live' : 'dead'}">${run.status}</span> <span class="chip">${run.provider || 'n/a'}</span></div><div class="muted">${run.started_at || ''}</div><div>${short(out.text || run.error || '', 220)}</div>`;
    host.appendChild(div);
  });
}
function fillAgentForm(agent) {
  const form = qs('#agentForm');
  form.name.value = agent.name; form.intent.value = agent.intent; form.budget_calls_per_day.value = agent.budget_calls_per_day;
  form.objective.value = agent.objective; form.system_prompt.value = agent.system_prompt; form.user_prompt.value = agent.user_prompt;
  form.schedule_minutes.value = agent.schedule_minutes; form.provider_order.value = (agent.provider_order || []).join(', ');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function renderAgents(agents) {
  const host = qs('#agents'), tpl = qs('#agentTemplate'); host.innerHTML = '';
  agents.forEach((agent) => {
    const node = tpl.content.cloneNode(true);
    node.querySelector('.agent-name').textContent = agent.name;
    node.querySelector('.agent-meta').textContent = `${agent.intent} · every ${agent.schedule_minutes} min · budget ${agent.budget_calls_per_day}/day · ${agent.enabled ? 'enabled' : 'disabled'}`;
    node.querySelector('.objective').textContent = agent.objective;
    node.querySelector('.route').textContent = `route: ${(agent.provider_order || []).join(' → ')}`;
    renderRuns(node.querySelector('.runs'), agent.recent_runs || []);
    node.querySelector('.agent-name').onclick = () => fillAgentForm(agent);
    node.querySelector('.run-btn').onclick = async () => { try { await api(`/api/agents/${agent.id}/run`, { method: 'POST' }); await loadWorkspace(); } catch (e) { alert(e.message); } };
    node.querySelector('.toggle-btn').onclick = async () => { try { await api(`/api/agents/${agent.id}/toggle`, { method: 'POST' }); await loadWorkspace(); } catch (e) { alert(e.message); } };
    host.appendChild(node);
  });
}
function renderProposals(proposals) {
  const host = qs('#proposals'), tpl = qs('#proposalTemplate'); host.innerHTML = '';
  proposals.forEach((p) => {
    const node = tpl.content.cloneNode(true);
    node.querySelector('.proposal-title').textContent = p.title;
    node.querySelector('.proposal-meta').textContent = `${p.status} · ${p.created_at}`;
    node.querySelector('.proposal-summary').textContent = p.summary;
    node.querySelector('.proposal-patch').textContent = JSON.stringify(p.patch_json || {}, null, 2);
    node.querySelector('.proposal-notes').textContent = p.validator_notes || '';
    node.querySelector('.apply-btn').onclick = async () => { try { await api(`/api/proposals/${p.id}/apply`, { method: 'POST' }); await loadWorkspace(); } catch (e) { alert(e.message); } };
    if (p.status !== 'pending') node.querySelector('.apply-btn').disabled = true;
    host.appendChild(node);
  });
}
function renderEvents(events) {
  const host = qs('#events'), tpl = qs('#eventTemplate'); host.innerHTML = '';
  events.forEach((ev) => {
    const node = tpl.content.cloneNode(true);
    node.querySelector('.event-type').textContent = ev.event_type;
    node.querySelector('.event-time').textContent = ev.created_at;
    node.querySelector('.event-actor').textContent = `${ev.actor} · ${ev.entity_type} ${ev.entity_id}`;
    node.querySelector('.event-payload').textContent = short(ev.payload_json, 320);
    host.appendChild(node);
  });
}
function renderLineage(items) {
  const host = qs('#lineage'), tpl = qs('#lineageTemplate'); host.innerHTML = '';
  (items || []).forEach((it) => {
    const node = tpl.content.cloneNode(true);
    node.querySelector('.lineage-label').textContent = it.label;
    node.querySelector('.lineage-purpose').textContent = it.purpose;
    host.appendChild(node);
  });
}
function renderGraph(graph) {
  qs('#graphStats').textContent = `${graph.stats.node_count} nodes / ${graph.stats.edge_count} edges`;
  const host = qs('#graphEdges'), tpl = qs('#edgeTemplate');
  host.innerHTML = '';
  (graph.edges || []).slice(0, 18).forEach((edge) => {
    const node = tpl.content.cloneNode(true);
    node.querySelector('.edge-rel').textContent = edge.rel;
    node.querySelector('.edge-ends').textContent = `${edge.source} → ${edge.target}`;
    host.appendChild(node);
  });
}
function renderForgeResult(result) {
  const host = qs('#forgeResult'); host.innerHTML = '';
  const triad = document.createElement('article'); triad.className = 'card';
  const final = result.triad && result.triad.final ? result.triad.final : {provider:'n/a', text:''};
  triad.innerHTML = `<div class="card-head"><h3>Triad Synthesis</h3></div><div class="muted">final via ${final.provider}</div><div>${short(final.text || '', 700)}</div>`;
  host.appendChild(triad);
  const prop = document.createElement('article'); prop.className = 'card';
  prop.innerHTML = `<div class="card-head"><h3>Forge Proposal</h3></div><div class="muted">${result.proposal.status}</div><div>${result.proposal.summary || ''}</div><pre class="code">${JSON.stringify(result.proposal.patch || {}, null, 2)}</pre>${(result.proposal.issues || []).length ? `<div class="muted">${result.proposal.issues.join(' | ')}</div>` : ''}`;
  host.appendChild(prop);
}
async function bootstrap() {
  const data = await api('/api/bootstrap');
  qs('#bootstrapInfo').textContent = `workspaces: ${data.workspaces.map(w => w.slug).join(', ')}`;
}
async function loadWorkspace() {
  const data = await api('/api/workspace');
  state.data = data;
  qs('#authPanel').classList.add('hidden');
  qs('#shell').classList.remove('hidden');
  qs('#logoutBtn').classList.remove('hidden');
  qs('#workspaceName').textContent = data.workspace.name;
  qs('#manifestVersion').textContent = String(data.manifest.version || 1);
  qs('#serverTime').textContent = data.server_time;
  renderProviders(data.providers || {});
  renderAgents(data.agents || []);
  renderProposals(data.proposals || []);
  renderEvents(data.events || []);
  renderLineage((data.manifest || {}).lineage || []);
  renderGraph(data.graph || {stats:{node_count:0,edge_count:0},edges:[]});
}
qs('#loginBtn').onclick = async () => {
  try {
    const data = await api('/api/login', { method: 'POST', body: JSON.stringify({ slug: qs('#slugInput').value.trim(), passcode: qs('#passInput').value }) });
    state.token = data.session_token; localStorage.setItem('evez_token', state.token); await loadWorkspace();
  } catch (e) { alert(e.message); }
};
qs('#logoutBtn').onclick = () => {
  state.token = ''; localStorage.removeItem('evez_token');
  qs('#shell').classList.add('hidden'); qs('#authPanel').classList.remove('hidden'); qs('#logoutBtn').classList.add('hidden');
};
qs('#refreshBtn').onclick = async () => { if (state.token) await loadWorkspace(); else await bootstrap(); };
qs('#agentForm').onsubmit = async (e) => {
  e.preventDefault(); const f = e.currentTarget;
  const payload = {
    name: f.name.value.trim(), intent: f.intent.value, budget_calls_per_day: Number(f.budget_calls_per_day.value || 24),
    objective: f.objective.value.trim(), system_prompt: f.system_prompt.value.trim(), user_prompt: f.user_prompt.value.trim(),
    schedule_minutes: Number(f.schedule_minutes.value || 240), provider_order: f.provider_order.value
  };
  try { await api('/api/agents', { method: 'POST', body: JSON.stringify(payload) }); await loadWorkspace(); } catch (e) { alert(e.message); }
};
qs('#proposalForm').onsubmit = async (e) => {
  e.preventDefault(); const f = e.currentTarget;
  let patch = {};
  try { patch = JSON.parse(f.patch.value); } catch (err) { return alert('Patch must be valid JSON'); }
  try { await api('/api/proposals', { method: 'POST', body: JSON.stringify({ title: f.title.value.trim(), summary: f.summary.value.trim(), patch }) }); await loadWorkspace(); } catch (e) { alert(e.message); }
};
qs('#forgeForm').onsubmit = async (e) => {
  e.preventDefault();
  const prompt = e.currentTarget.prompt.value.trim();
  try { const result = await api('/api/forge', { method: 'POST', body: JSON.stringify({ prompt }) }); renderForgeResult(result); await loadWorkspace(); } catch (e) { alert(e.message); }
};
if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/service-worker.js').catch(() => {}));
if (state.token) loadWorkspace().catch(() => bootstrap().catch((e) => alert(e.message)));
else bootstrap().catch((e) => alert(e.message));
