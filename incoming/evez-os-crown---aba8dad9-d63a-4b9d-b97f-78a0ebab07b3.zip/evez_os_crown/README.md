# EVEZ-OS Crown

This build consolidates the earlier lines into one kernel:

- EVEZ Zero -> local-first agent runtime
- EVEZ-OS Peers -> provider-preserving routing
- EVEZ-OS Seed -> triad synthesis
- EVEZ-OS Crown -> system-of-systems kernel

## What it adds

- Forge endpoint that turns an operator prompt into:
  - triad peer synthesis
  - a proposal patch
  - a refreshed synapse graph
- Graph endpoint showing connected systems, providers, agents, and proposals
- Richer manifest with systems, lineage, invariants, and peer-specific contracts

## Run

```bash
cp .env.example .env
docker compose up --build -d
```

Open `http://localhost:8080`

Default workspace slug: `crown`
Passcode: value of `ADMIN_PASSWORD` in `.env`

## Local-first

The runtime boots and works without external provider keys.
To enable live peers, add fresh rotated values to `.env`:

- OPENAI_API_KEY
- ANTHROPIC_API_KEY
- PERPLEXITY_API_KEY
- GROQ_API_KEY
- GEMINI_API_KEY
- OPENROUTER_API_KEY
