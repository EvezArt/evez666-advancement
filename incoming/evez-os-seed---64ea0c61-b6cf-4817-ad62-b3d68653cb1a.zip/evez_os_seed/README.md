
# EVEZ-OS Peers

A runnable phone-first substrate that preserves what ChatGPT, Claude, and Perplexity are each good at instead of flattening them into one generic API slot.

What it does:
- Runs scheduled agents 24/7 in one container
- Stores state locally in SQLite
- Gives you an installable PWA for phone use
- Routes by intent first, then falls back by provider availability
- Preserves provider-specific benefits:
  - ChatGPT/OpenAI for reasoning and structured output
  - Claude/Anthropic for editing and long-form drafting
  - Perplexity for research and citations
  - Groq for speed
  - Gemini for general fallback
  - OpenRouter for mesh/fallback
  - Local mode when everything else is offline

## Run

```bash
cp .env.example .env
docker compose up --build -d
```

Open `http://localhost:8080`

Default workspace slug: `demo`
Passcode: whatever you set in `.env` as `ADMIN_PASSWORD`

## Verify with zero external keys

Leave all provider keys blank and start it anyway.

You can:
- log in
- view provider registry
- create agents
- run scheduled jobs
- see event spine and proposal/apply loop
- prove the runtime works in local fallback mode

## Add provider keys later

Only in `.env` on your machine/server.
Nothing in the client bundle contains provider secrets.

## Agent intents

- `reasoning` → ChatGPT first
- `editing` → Claude first
- `research` → Perplexity first
- `speed` → Groq first
- `general` → mixed route

You can override the provider order per agent.

## API

- `GET /api/bootstrap`
- `POST /api/login`
- `GET /api/workspace`
- `POST /api/agents`
- `POST /api/agents/{id}/run`
- `POST /api/agents/{id}/toggle`
- `POST /api/proposals`
- `POST /api/proposals/{id}/apply`


## New in Seed runtime

- **Triad Run**: query ChatGPT, Claude, and Perplexity as peers, then synthesize them into one answer
- **Peer-preserving synthesis**: reasoning/editing/research remain distinct instead of being flattened
- **Offline-safe**: triad still runs in local synthesis mode when no external keys are present
