
#!/usr/bin/env python3
import hashlib
import json
import os
import secrets
import sqlite3
import threading
import time
import traceback
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
DB_PATH = os.environ.get("APP_DB", str(APP_DIR / "data" / "evez_os_peers.db"))
STATIC_DIR = APP_DIR / "static"
PORT = int(os.environ.get("PORT", "8080"))
CHECK_INTERVAL_SECONDS = int(os.environ.get("CHECK_INTERVAL_SECONDS", "20"))
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "change-me-now")
DEFAULT_WORKSPACE_SLUG = os.environ.get("DEFAULT_WORKSPACE_SLUG", "demo")
DEFAULT_WORKSPACE_NAME = os.environ.get("DEFAULT_WORKSPACE_NAME", "EVEZ Peers Demo")

RUNNING_LOCK = threading.Lock()
RUNNING_AGENTS = set()

PROVIDERS = {
    "chatgpt": {
        "family": "openai",
        "label": "ChatGPT/OpenAI",
        "env_key": "OPENAI_API_KEY",
        "model_env": "OPENAI_MODEL",
        "default_model": "gpt-4o-mini",
        "strengths": ["reasoning", "tools", "structured-json"],
        "contract": {"citations": False, "json": True, "web": False},
    },
    "claude": {
        "family": "anthropic",
        "label": "Claude/Anthropic",
        "env_key": "ANTHROPIC_API_KEY",
        "model_env": "ANTHROPIC_MODEL",
        "default_model": "claude-3-5-haiku-latest",
        "strengths": ["editing", "longform", "policy-aware"],
        "contract": {"citations": False, "json": True, "web": False},
    },
    "perplexity": {
        "family": "openai_compatible",
        "label": "Perplexity",
        "env_key": "PERPLEXITY_API_KEY",
        "base_url_env": "PERPLEXITY_BASE_URL",
        "default_base_url": "https://api.perplexity.ai",
        "model_env": "PERPLEXITY_MODEL",
        "default_model": "sonar",
        "strengths": ["research", "freshness", "citations"],
        "contract": {"citations": True, "json": True, "web": True},
    },
    "groq": {
        "family": "openai_compatible",
        "label": "Groq",
        "env_key": "GROQ_API_KEY",
        "base_url_env": "GROQ_BASE_URL",
        "default_base_url": "https://api.groq.com/openai/v1",
        "model_env": "GROQ_MODEL",
        "default_model": "llama-3.1-8b-instant",
        "strengths": ["speed", "cheap"],
        "contract": {"citations": False, "json": True, "web": False},
    },
    "gemini": {
        "family": "gemini",
        "label": "Gemini",
        "env_key": "GEMINI_API_KEY",
        "model_env": "GEMINI_MODEL",
        "default_model": "gemini-2.0-flash",
        "strengths": ["general", "multimodal-ready"],
        "contract": {"citations": False, "json": True, "web": False},
    },
    "openrouter": {
        "family": "openai_compatible",
        "label": "OpenRouter",
        "env_key": "OPENROUTER_API_KEY",
        "base_url_env": "OPENROUTER_BASE_URL",
        "default_base_url": "https://openrouter.ai/api/v1",
        "model_env": "OPENROUTER_MODEL",
        "default_model": "openrouter/auto",
        "strengths": ["model-mesh", "fallbacks"],
        "contract": {"citations": False, "json": True, "web": False},
    },
    "local": {
        "family": "local",
        "label": "Local",
        "env_key": None,
        "model_env": None,
        "default_model": "local-fallback",
        "strengths": ["offline", "always-on"],
        "contract": {"citations": False, "json": True, "web": False},
    },
}

INTENT_DEFAULTS = {
    "reasoning": ["chatgpt", "claude", "groq", "gemini", "openrouter", "local"],
    "editing": ["claude", "chatgpt", "gemini", "openrouter", "local"],
    "research": ["perplexity", "chatgpt", "claude", "openrouter", "local"],
    "speed": ["groq", "gemini", "openrouter", "local"],
    "synthesis": ["chatgpt", "claude", "perplexity", "groq", "gemini", "openrouter", "local"],
    "general": ["chatgpt", "claude", "perplexity", "groq", "gemini", "openrouter", "local"],
}

def utc_now():
    return datetime.now(timezone.utc)

def utc_now_iso():
    return utc_now().replace(microsecond=0).isoformat()

def sha256(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def parse_json(s, fallback):
    try:
        return json.loads(s) if s else fallback
    except Exception:
        return fallback

def db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def ensure_db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    conn = db()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS workspaces (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            slug TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            passcode_hash TEXT NOT NULL,
            manifest_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            token TEXT PRIMARY KEY,
            workspace_id INTEGER NOT NULL,
            role TEXT NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS agents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            workspace_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            intent TEXT NOT NULL,
            objective TEXT NOT NULL,
            system_prompt TEXT NOT NULL,
            user_prompt TEXT NOT NULL,
            schedule_minutes INTEGER NOT NULL DEFAULT 240,
            enabled INTEGER NOT NULL DEFAULT 1,
            budget_calls_per_day INTEGER NOT NULL DEFAULT 24,
            provider_order TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            last_run_at TEXT,
            UNIQUE(workspace_id, name)
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            workspace_id INTEGER NOT NULL,
            agent_id INTEGER NOT NULL,
            started_at TEXT NOT NULL,
            finished_at TEXT,
            status TEXT NOT NULL,
            provider TEXT,
            output_json TEXT,
            error TEXT
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            workspace_id INTEGER NOT NULL,
            event_type TEXT NOT NULL,
            actor TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS proposals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            workspace_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            summary TEXT NOT NULL,
            patch_json TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            validator_notes TEXT,
            created_at TEXT NOT NULL,
            applied_at TEXT
        )
    """)
    conn.commit()

    count = cur.execute("SELECT COUNT(*) AS c FROM workspaces").fetchone()["c"]
    if count == 0:
        seed_demo(conn)
    conn.close()

def default_manifest(name, slug):
    return {
        "version": 1,
        "workspace": {
            "name": name,
            "slug": slug,
            "shell": ["providers", "agents", "proposals", "events"],
            "theme": {"bg": "#0f1115", "panel": "#171a21", "accent": "#d8ff33", "text": "#f3f5f7"},
        },
        "model_registry": {
            "enabled": list(PROVIDERS.keys()),
            "preserve_peer_benefits": True,
            "rules": [
                "preserve citations and freshness for perplexity research flows",
                "preserve structured output reliability for chatgpt reasoning flows",
                "preserve longform editing and rewriting for claude drafting flows",
                "use routing by intent before fallback by availability",
                "never flatten all providers into one generic text bucket"
            ],
        },
        "invariants": [
            "no_client_secrets",
            "workspace_isolation",
            "provider_contract_preserved",
            "agent_budget_required",
        ],
        "policies": {
            "allow_auto_apply_proposals": False,
            "max_agents_per_workspace": 24,
        }
    }

def append_event(conn, workspace_id, event_type, actor, entity_type, entity_id, payload):
    conn.execute(
        "INSERT INTO events (workspace_id, event_type, actor, entity_type, entity_id, payload_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (workspace_id, event_type, actor, entity_type, entity_id, json.dumps(payload), utc_now_iso()),
    )

def seed_demo(conn):
    now = utc_now_iso()
    manifest = default_manifest(DEFAULT_WORKSPACE_NAME, DEFAULT_WORKSPACE_SLUG)
    workspace_id = conn.execute(
        "INSERT INTO workspaces (slug, name, passcode_hash, manifest_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
        (DEFAULT_WORKSPACE_SLUG, DEFAULT_WORKSPACE_NAME, sha256(ADMIN_PASSWORD), json.dumps(manifest), now, now),
    ).lastrowid
    agents = [
        {
            "name": "Reasoner",
            "intent": "reasoning",
            "objective": "Resolve operator questions with structured logic.",
            "system_prompt": "You are a concise reasoning agent. Be direct and structured.",
            "user_prompt": "Generate a compact reasoning brief for {{workspace_name}} at {{now}} with one conclusion and one next step.",
            "schedule_minutes": 240,
            "budget_calls_per_day": 24,
        },
        {
            "name": "Researcher",
            "intent": "research",
            "objective": "Produce a web-grounded answer with citations when supported.",
            "system_prompt": "You are a research agent. Prefer fresh, grounded answers and include citations if available.",
            "user_prompt": "Create a short research pulse for {{workspace_name}} at {{now}}. If your provider supports citations, expose them.",
            "schedule_minutes": 720,
            "budget_calls_per_day": 8,
        },
        {
            "name": "Editor",
            "intent": "editing",
            "objective": "Rewrite and tighten text cleanly.",
            "system_prompt": "You are an editing agent. Rewrite for clarity and force.",
            "user_prompt": "Produce a short editing memo for {{workspace_name}} at {{now}} that shows stylistic compression.",
            "schedule_minutes": 720,
            "budget_calls_per_day": 8,
        },
        {
            "name": "Triad Synthesizer",
            "intent": "synthesis",
            "objective": "Run distinct peers and merge them without flattening their strengths.",
            "system_prompt": "You are a synthesis agent. Preserve peer-specific strengths and compress overlap into one actionable result.",
            "user_prompt": "Synthesize a strategic pulse for {{workspace_name}} at {{now}} by preserving the strongest distinct signal from reasoning, editing, and research.",
            "schedule_minutes": 720,
            "budget_calls_per_day": 6,
        },
    ]
    for agent in agents:
        conn.execute(
            """
            INSERT INTO agents (workspace_id, name, intent, objective, system_prompt, user_prompt, schedule_minutes, enabled, budget_calls_per_day, provider_order, created_at, updated_at, last_run_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, NULL)
            """,
            (
                workspace_id,
                agent["name"],
                agent["intent"],
                agent["objective"],
                agent["system_prompt"],
                agent["user_prompt"],
                agent["schedule_minutes"],
                agent["budget_calls_per_day"],
                json.dumps(INTENT_DEFAULTS[agent["intent"]]),
                now,
                now,
            ),
        )
    append_event(conn, workspace_id, "workspace.seeded", "system", "workspace", str(workspace_id), {"providers": list(PROVIDERS.keys())})
    conn.commit()

def create_session(conn, workspace_id, role="admin", hours=72):
    token = secrets.token_urlsafe(32)
    created = utc_now()
    expires = created + timedelta(hours=hours)
    conn.execute(
        "INSERT INTO sessions (token, workspace_id, role, created_at, expires_at) VALUES (?, ?, ?, ?, ?)",
        (token, workspace_id, role, created.replace(microsecond=0).isoformat(), expires.replace(microsecond=0).isoformat()),
    )
    return token

def get_session(conn, token):
    if not token:
        return None
    row = conn.execute("SELECT * FROM sessions WHERE token = ?", (token,)).fetchone()
    if not row:
        return None
    try:
        if datetime.fromisoformat(row["expires_at"]) < utc_now():
            conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
            conn.commit()
            return None
    except Exception:
        return None
    return row

def require_session(handler):
    conn = db()
    token = handler.headers.get("X-Session-Token")
    session = get_session(conn, token)
    if not session:
        conn.close()
        json_response(handler, 401, {"ok": False, "error": "Unauthorized"})
        return None, None
    workspace = conn.execute("SELECT * FROM workspaces WHERE id = ?", (session["workspace_id"],)).fetchone()
    return conn, (session, workspace)

def json_response(handler, status, payload):
    body = json.dumps(payload).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()
    handler.wfile.write(body)

def text_response(handler, status, body, content_type="text/plain; charset=utf-8"):
    raw = body.encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)

def parse_body(handler):
    length = int(handler.headers.get("Content-Length", "0"))
    raw = handler.rfile.read(length) if length > 0 else b"{}"
    if not raw:
        return {}
    return json.loads(raw.decode("utf-8"))

def render_prompt(template, agent, workspace):
    result = template
    replacements = {
        "{{now}}": utc_now().strftime("%Y-%m-%d %H:%M:%S UTC"),
        "{{date}}": utc_now().strftime("%Y-%m-%d"),
        "{{workspace_name}}": workspace["name"],
        "{{agent_name}}": agent["name"],
    }
    for k, v in replacements.items():
        result = result.replace(k, v)
    return result

def provider_live(provider_name):
    info = PROVIDERS[provider_name]
    if info["family"] == "local":
        return True
    env_key = info["env_key"]
    return bool(os.environ.get(env_key))

def provider_status_map():
    data = {}
    for name, info in PROVIDERS.items():
        data[name] = {
            "label": info["label"],
            "live": provider_live(name),
            "strengths": info["strengths"],
            "contract": info["contract"],
            "model": (os.environ.get(info["model_env"], info["default_model"]) if info["model_env"] else info["default_model"]),
        }
    return data

def http_json(url, method="GET", payload=None, headers=None, timeout=40):
    data = None
    final_headers = {"User-Agent": "EVEZ-OS-Peers/1.0"}
    if headers:
        final_headers.update(headers)
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        final_headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, method=method, data=data, headers=final_headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read().decode("utf-8")
        return json.loads(raw) if raw else {}

def call_openai_compatible(base_url, api_key, model, system_prompt, user_prompt, extra_headers=None):
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.7,
    }
    headers = {"Authorization": f"Bearer {api_key}"}
    if extra_headers:
        headers.update(extra_headers)
    data = http_json(base_url.rstrip("/") + "/chat/completions", method="POST", payload=payload, headers=headers)
    choice = data.get("choices", [{}])[0]
    message = choice.get("message", {})
    citations = data.get("citations") or message.get("citations") or []
    return {
        "text": (message.get("content") or "").strip(),
        "citations": citations,
        "meta": {"raw_provider": "openai_compatible", "id": data.get("id"), "usage": data.get("usage")},
    }

def call_openai(provider, system_prompt, user_prompt):
    info = PROVIDERS[provider]
    api_key = os.environ.get(info["env_key"], "")
    if not api_key:
        raise RuntimeError(f"{info['env_key']} missing")
    model = os.environ.get(info["model_env"], info["default_model"])
    return call_openai_compatible("https://api.openai.com/v1", api_key, model, system_prompt, user_prompt)

def call_anthropic(provider, system_prompt, user_prompt):
    info = PROVIDERS[provider]
    api_key = os.environ.get(info["env_key"], "")
    if not api_key:
        raise RuntimeError(f"{info['env_key']} missing")
    model = os.environ.get(info["model_env"], info["default_model"])
    payload = {
        "model": model,
        "max_tokens": 300,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_prompt}],
    }
    headers = {"x-api-key": api_key, "anthropic-version": "2023-06-01"}
    data = http_json("https://api.anthropic.com/v1/messages", method="POST", payload=payload, headers=headers)
    parts = data.get("content", [])
    text = "\n".join([p.get("text", "") for p in parts if p.get("type") == "text"]).strip()
    return {"text": text, "citations": [], "meta": {"raw_provider": "anthropic", "id": data.get("id"), "usage": data.get("usage")}}

def call_gemini(provider, system_prompt, user_prompt):
    info = PROVIDERS[provider]
    api_key = os.environ.get(info["env_key"], "")
    if not api_key:
        raise RuntimeError(f"{info['env_key']} missing")
    model = os.environ.get(info["model_env"], info["default_model"])
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{urllib.parse.quote(model)}:generateContent?key={urllib.parse.quote(api_key)}"
    payload = {
        "contents": [{"parts": [{"text": f"{system_prompt}\n\n{user_prompt}"}]}],
        "generationConfig": {"temperature": 0.7},
    }
    data = http_json(url, method="POST", payload=payload)
    candidates = data.get("candidates", [])
    if not candidates:
        raise RuntimeError("Gemini returned no candidates")
    parts = candidates[0].get("content", {}).get("parts", [])
    text = "\n".join([p.get("text", "") for p in parts if p.get("text")]).strip()
    return {"text": text, "citations": [], "meta": {"raw_provider": "gemini"}}

def call_local(provider, agent, workspace, provider_order):
    provider_meta = provider_status_map()
    if agent["intent"] == "research":
        citations = [
            {"title": "Local mode", "url": "local://offline", "note": "No external research provider live; running offline fallback."}
        ]
    else:
        citations = []
    text = (
        f"[local-fallback] {workspace['name']}::{agent['name']}\n"
        f"intent: {agent['intent']}\n"
        f"objective: {agent['objective']}\n"
        f"provider_route: {', '.join(provider_order)}\n"
        f"live_providers: {', '.join([k for k,v in provider_meta.items() if v['live']])}\n"
        f"brief: peer-preserving substrate is live; routing chooses provider by intent first, availability second.\n"
        f"note: ChatGPT keeps reasoning/tool structure, Claude keeps longform editing posture, Perplexity keeps research/citation posture when enabled."
    )
    return {"text": text, "citations": citations, "meta": {"raw_provider": "local"}}

def call_provider(provider, agent, workspace, system_prompt, user_prompt, provider_order):
    family = PROVIDERS[provider]["family"]
    if family == "openai":
        return call_openai(provider, system_prompt, user_prompt)
    if family == "anthropic":
        return call_anthropic(provider, system_prompt, user_prompt)
    if family == "gemini":
        return call_gemini(provider, system_prompt, user_prompt)
    if family == "openai_compatible":
        info = PROVIDERS[provider]
        api_key = os.environ.get(info["env_key"], "")
        if not api_key:
            raise RuntimeError(f"{info['env_key']} missing")
        base_url = os.environ.get(info["base_url_env"], info["default_base_url"])
        model = os.environ.get(info["model_env"], info["default_model"])
        extra_headers = {}
        if provider == "openrouter":
            extra_headers["HTTP-Referer"] = os.environ.get("APP_PUBLIC_URL", "http://localhost:8080")
            extra_headers["X-Title"] = "EVEZ-OS Peers"
        return call_openai_compatible(base_url, api_key, model, system_prompt, user_prompt, extra_headers)
    if family == "local":
        return call_local(provider, agent, workspace, provider_order)
    raise RuntimeError(f"Unsupported provider family: {family}")



def unique_keep_order(items):
    out = []
    seen = set()
    for x in items:
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out

def peer_candidates(intent):
    if intent == "editing":
        return unique_keep_order(["claude", "chatgpt", "perplexity", "local"])
    if intent == "research":
        return unique_keep_order(["perplexity", "chatgpt", "claude", "local"])
    if intent == "speed":
        return unique_keep_order(["groq", "gemini", "chatgpt", "local"])
    return unique_keep_order(["chatgpt", "claude", "perplexity", "local"])

def local_synthesis(prompt, intent, peer_outputs):
    lines = [f"[local-synthesis] intent={intent}", f"prompt: {prompt[:200]}"]
    best = []
    for item in peer_outputs:
        txt = (item.get("text") or "").strip().replace("\n", " ")
        lines.append(f"{item['provider']}: {txt[:240]}")
        if txt:
            best.append((item['provider'], txt))
    conclusion = "No peer output available."
    if best:
        strongest = []
        used = set()
        for prov, txt in best:
            if prov not in used:
                used.add(prov)
                strongest.append(f"{prov}: {txt[:180]}")
        conclusion = " | ".join(strongest[:3])
    citations = []
    for item in peer_outputs:
        for c in item.get("citations", []):
            if c not in citations:
                citations.append(c)
    return {"text": "\n".join(lines + [f"synthesis: {conclusion}"]), "citations": citations, "meta": {"raw_provider": "local-synthesis"}}

def synthesize_prompt(prompt, intent, peer_outputs):
    packed = []
    for item in peer_outputs:
        packed.append({
            "provider": item["provider"],
            "strengths": PROVIDERS.get(item["provider"], {}).get("strengths", []),
            "text": item.get("text", ""),
            "citations": item.get("citations", []),
        })
    provider_order = INTENT_DEFAULTS["synthesis"]
    system_prompt = (
        "You are a synthesis kernel. Merge peer outputs without flattening their distinct strengths. "
        "Preserve reasoning from ChatGPT, editing force from Claude, freshness/citations from Perplexity when present. "
        "Return one compact answer with a short strategic conclusion and a hard next move."
    )
    user_prompt = json.dumps({"intent": intent, "prompt": prompt, "peer_outputs": packed}, ensure_ascii=False)
    errors = []
    fake_agent = {"name": "Triad Synthesizer", "intent": "synthesis", "objective": "Synthesize peer outputs"}
    fake_workspace = {"name": "Seed Runtime"}
    for provider in provider_order:
        try:
            return provider, call_provider(provider, fake_agent, fake_workspace, system_prompt, user_prompt, provider_order)
        except Exception as exc:
            errors.append(f"{provider}: {exc}")
    local = local_synthesis(prompt, intent, peer_outputs)
    local["meta"]["errors"] = errors
    return "local", local

def run_peer_synthesis(workspace_id, prompt, intent="general", actor="admin"):
    conn = db()
    started = utc_now_iso()
    try:
        workspace = conn.execute("SELECT * FROM workspaces WHERE id = ?", (workspace_id,)).fetchone()
        providers = peer_candidates(intent)
        peer_outputs = []
        errors = []
        for provider in providers:
            try:
                fake_agent = {"name": f"{provider}-peer", "intent": intent, "objective": "Peer answer"}
                system_prompt = (
                    f"You are the {provider} peer for intent={intent}. "
                    "Answer directly and preserve your native strength. Be compact and useful."
                )
                user_prompt = prompt
                result = call_provider(provider, fake_agent, workspace, system_prompt, user_prompt, providers)
                peer_outputs.append({
                    "provider": provider,
                    "text": result.get("text", ""),
                    "citations": result.get("citations", []),
                    "meta": result.get("meta", {})
                })
            except Exception as exc:
                errors.append(f"{provider}: {exc}")
        synth_provider, final_result = synthesize_prompt(prompt, intent, peer_outputs)
        payload = {
            "intent": intent,
            "prompt": prompt,
            "peers": peer_outputs,
            "errors": errors,
            "final": {
                "provider": synth_provider,
                "text": final_result.get("text", ""),
                "citations": final_result.get("citations", []),
                "meta": final_result.get("meta", {})
            },
            "started_at": started,
            "finished_at": utc_now_iso(),
        }
        append_event(conn, workspace_id, "triad.run.completed", actor, "triad", "triad", {
            "intent": intent,
            "peer_count": len(peer_outputs),
            "final_provider": synth_provider
        })
        conn.commit()
        return {"ok": True, **payload}
    finally:
        conn.close()
def resolve_provider_order(agent):
    explicit = parse_json(agent["provider_order"], [])
    if explicit:
        return explicit
    return INTENT_DEFAULTS.get(agent["intent"], INTENT_DEFAULTS["general"])

def calls_today(conn, agent_id):
    since = utc_now().date().isoformat()
    row = conn.execute("SELECT COUNT(*) AS c FROM runs WHERE agent_id = ? AND started_at >= ?", (agent_id, since)).fetchone()
    return row["c"]

def run_agent(agent_id, actor="system"):
    with RUNNING_LOCK:
        if agent_id in RUNNING_AGENTS:
            return {"ok": False, "error": "Agent already running"}
        RUNNING_AGENTS.add(agent_id)

    conn = db()
    started_at = utc_now_iso()
    try:
        agent = conn.execute("SELECT * FROM agents WHERE id = ?", (agent_id,)).fetchone()
        if not agent:
            return {"ok": False, "error": "Agent not found"}
        workspace = conn.execute("SELECT * FROM workspaces WHERE id = ?", (agent["workspace_id"],)).fetchone()
        if calls_today(conn, agent_id) >= agent["budget_calls_per_day"]:
            return {"ok": False, "error": "Daily budget exhausted"}

        run_id = conn.execute("INSERT INTO runs (workspace_id, agent_id, started_at, status) VALUES (?, ?, ?, ?)", (agent["workspace_id"], agent_id, started_at, "running")).lastrowid
        conn.commit()

        system_prompt = render_prompt(agent["system_prompt"], agent, workspace)
        user_prompt = render_prompt(agent["user_prompt"], agent, workspace)
        provider_order = resolve_provider_order(agent)
        errors = []

        for provider in provider_order:
            try:
                result = call_provider(provider, agent, workspace, system_prompt, user_prompt, provider_order)
                normalized = {
                    "provider": provider,
                    "intent": agent["intent"],
                    "text": result.get("text", ""),
                    "citations": result.get("citations", []),
                    "meta": result.get("meta", {}),
                }
                finished = utc_now_iso()
                conn.execute("UPDATE runs SET finished_at = ?, status = ?, provider = ?, output_json = ?, error = NULL WHERE id = ?",
                             (finished, "success", provider, json.dumps(normalized), run_id))
                conn.execute("UPDATE agents SET last_run_at = ?, updated_at = ? WHERE id = ?", (finished, finished, agent_id))
                append_event(conn, agent["workspace_id"], "agent.run.succeeded", actor, "agent", str(agent_id),
                             {"run_id": run_id, "provider": provider, "intent": agent["intent"]})
                conn.commit()
                return {"ok": True, "run_id": run_id, "provider": provider, "output": normalized}
            except Exception as exc:
                errors.append(f"{provider}: {exc}")

        finished = utc_now_iso()
        conn.execute("UPDATE runs SET finished_at = ?, status = ?, provider = ?, error = ? WHERE id = ?", (finished, "failed", "none", "\n".join(errors), run_id))
        conn.execute("UPDATE agents SET last_run_at = ?, updated_at = ? WHERE id = ?", (finished, finished, agent_id))
        append_event(conn, agent["workspace_id"], "agent.run.failed", actor, "agent", str(agent_id), {"run_id": run_id, "errors": errors})
        conn.commit()
        return {"ok": False, "run_id": run_id, "error": "\n".join(errors)}
    except Exception:
        return {"ok": False, "error": traceback.format_exc()}
    finally:
        conn.close()
        with RUNNING_LOCK:
            RUNNING_AGENTS.discard(agent_id)

def due_agents():
    conn = db()
    rows = conn.execute("SELECT * FROM agents WHERE enabled = 1").fetchall()
    conn.close()
    current = utc_now()
    due = []
    for row in rows:
        last_run_at = row["last_run_at"]
        if not last_run_at:
            due.append(row)
            continue
        try:
            last = datetime.fromisoformat(last_run_at)
        except Exception:
            due.append(row)
            continue
        if current >= last + timedelta(minutes=row["schedule_minutes"]):
            due.append(row)
    return due

def scheduler_loop():
    while True:
        try:
            for agent in due_agents():
                threading.Thread(target=run_agent, args=(agent["id"], "scheduler"), daemon=True).start()
        except Exception:
            traceback.print_exc()
        time.sleep(CHECK_INTERVAL_SECONDS)

def validate_patch(current_manifest, patch):
    issues = []
    if not isinstance(patch, dict):
        return ["Patch must be a JSON object."]
    raw = json.dumps(patch).lower()
    for token in ["api_key", "secret", "token", "sk-", "gsk_", "hf_", "aiza", "cfat_", "cfut_"]:
        if token in raw:
            issues.append("Patch appears to contain secret material.")
            break
    if patch.get("model_registry", {}).get("preserve_peer_benefits") is False:
        issues.append("Peer benefit preservation cannot be disabled.")
    return issues

def apply_patch_to_manifest(manifest, patch):
    new = json.loads(json.dumps(manifest))
    for key in ["workspace", "model_registry", "policies"]:
        if key in patch and isinstance(patch[key], dict):
            new.setdefault(key, {}).update(patch[key])
    new["version"] = int(new.get("version", 1)) + 1
    return new

def workspace_payload(conn, workspace_id):
    workspace = conn.execute("SELECT * FROM workspaces WHERE id = ?", (workspace_id,)).fetchone()
    manifest = parse_json(workspace["manifest_json"], {})
    agents = []
    for row in conn.execute("SELECT * FROM agents WHERE workspace_id = ? ORDER BY id ASC", (workspace_id,)).fetchall():
        recent_runs = conn.execute("SELECT id, started_at, finished_at, status, provider, output_json, error FROM runs WHERE agent_id = ? ORDER BY id DESC LIMIT 5", (row["id"],)).fetchall()
        agent = dict(row)
        agent["provider_order"] = parse_json(agent["provider_order"], [])
        parsed_runs = []
        for rr in recent_runs:
            item = dict(rr)
            item["output"] = parse_json(item.pop("output_json"), {})
            parsed_runs.append(item)
        agent["recent_runs"] = parsed_runs
        agents.append(agent)
    proposals = []
    for row in conn.execute("SELECT * FROM proposals WHERE workspace_id = ? ORDER BY id DESC LIMIT 20", (workspace_id,)).fetchall():
        item = dict(row)
        item["patch_json"] = parse_json(item["patch_json"], {})
        proposals.append(item)
    events = [dict(r) for r in conn.execute("SELECT * FROM events WHERE workspace_id = ? ORDER BY id DESC LIMIT 30", (workspace_id,)).fetchall()]
    return {
        "workspace": {"id": workspace["id"], "slug": workspace["slug"], "name": workspace["name"], "updated_at": workspace["updated_at"]},
        "manifest": manifest,
        "providers": provider_status_map(),
        "agents": agents,
        "proposals": proposals,
        "events": events,
        "running_agents": list(RUNNING_AGENTS),
        "server_time": utc_now_iso(),
    }

class AppHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/api/health":
            return json_response(self, 200, {"ok": True, "time": utc_now_iso()})
        if self.path == "/api/bootstrap":
            conn = db()
            workspaces = [dict(r) for r in conn.execute("SELECT id, slug, name, updated_at FROM workspaces ORDER BY id ASC").fetchall()]
            conn.close()
            return json_response(self, 200, {"ok": True, "workspaces": workspaces, "providers": provider_status_map(), "server_time": utc_now_iso()})
        if self.path == "/api/workspace":
            conn, session_bundle = require_session(self)
            if not conn:
                return
            session, workspace = session_bundle
            payload = workspace_payload(conn, workspace["id"])
            conn.close()
            return json_response(self, 200, {"ok": True, **payload})
        return self.serve_static()

    def do_POST(self):
        if self.path == "/api/login":
            body = parse_body(self)
            slug = (body.get("slug") or "").strip()
            passcode = body.get("passcode") or ""
            conn = db()
            workspace = conn.execute("SELECT * FROM workspaces WHERE slug = ?", (slug,)).fetchone()
            if not workspace or workspace["passcode_hash"] != sha256(passcode):
                conn.close()
                return json_response(self, 401, {"ok": False, "error": "Invalid workspace or passcode"})
            token = create_session(conn, workspace["id"])
            append_event(conn, workspace["id"], "session.created", "login", "workspace", str(workspace["id"]), {"role": "admin"})
            conn.commit()
            conn.close()
            return json_response(self, 200, {"ok": True, "session_token": token})

        if self.path == "/api/agents":
            conn, session_bundle = require_session(self)
            if not conn:
                return
            session, workspace = session_bundle
            body = parse_body(self)
            now = utc_now_iso()
            provider_order = body.get("provider_order")
            if isinstance(provider_order, str):
                provider_order = [x.strip() for x in provider_order.split(",") if x.strip()]
            if not provider_order:
                provider_order = INTENT_DEFAULTS.get(body.get("intent", "general"), INTENT_DEFAULTS["general"])
            existing = conn.execute("SELECT id FROM agents WHERE workspace_id = ? AND name = ?", (workspace["id"], body["name"].strip())).fetchone()
            params = (
                body.get("intent", "general").strip(),
                body["objective"].strip(),
                body["system_prompt"].strip(),
                body["user_prompt"].strip(),
                int(body.get("schedule_minutes", 240)),
                1 if body.get("enabled", True) else 0,
                int(body.get("budget_calls_per_day", 24)),
                json.dumps(provider_order),
                now,
            )
            if existing:
                conn.execute("""
                    UPDATE agents SET intent=?, objective=?, system_prompt=?, user_prompt=?, schedule_minutes=?, enabled=?, budget_calls_per_day=?, provider_order=?, updated_at=? WHERE id = ?
                """, params + (existing["id"],))
                agent_id = existing["id"]
            else:
                agent_id = conn.execute("""
                    INSERT INTO agents (workspace_id, name, intent, objective, system_prompt, user_prompt, schedule_minutes, enabled, budget_calls_per_day, provider_order, created_at, updated_at, last_run_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)
                """, (workspace["id"], body["name"].strip()) + params).lastrowid
            append_event(conn, workspace["id"], "agent.saved", "admin", "agent", str(agent_id), {"name": body["name"].strip()})
            conn.commit()
            conn.close()
            return json_response(self, 200, {"ok": True, "agent_id": agent_id})

        if self.path.startswith("/api/agents/") and self.path.endswith("/run"):
            conn, session_bundle = require_session(self)
            if not conn:
                return
            session, workspace = session_bundle
            agent_id = int(self.path.strip("/").split("/")[2])
            conn.close()
            result = run_agent(agent_id, actor="admin")
            return json_response(self, 200 if result.get("ok") else 500, result)

        if self.path.startswith("/api/agents/") and self.path.endswith("/toggle"):
            conn, session_bundle = require_session(self)
            if not conn:
                return
            session, workspace = session_bundle
            agent_id = int(self.path.strip("/").split("/")[2])
            row = conn.execute("SELECT enabled FROM agents WHERE id = ? AND workspace_id = ?", (agent_id, workspace["id"])).fetchone()
            if not row:
                conn.close()
                return json_response(self, 404, {"ok": False, "error": "Agent not found"})
            new_enabled = 0 if row["enabled"] else 1
            conn.execute("UPDATE agents SET enabled = ?, updated_at = ? WHERE id = ?", (new_enabled, utc_now_iso(), agent_id))
            append_event(conn, workspace["id"], "agent.toggled", "admin", "agent", str(agent_id), {"enabled": bool(new_enabled)})
            conn.commit()
            conn.close()
            return json_response(self, 200, {"ok": True, "enabled": bool(new_enabled)})

        if self.path == "/api/triad":
            conn, session_bundle = require_session(self)
            if not conn:
                return
            session, workspace = session_bundle
            body = parse_body(self)
            prompt = (body.get("prompt") or "").strip()
            intent = (body.get("intent") or "general").strip()
            conn.close()
            if not prompt:
                return json_response(self, 400, {"ok": False, "error": "Prompt required"})
            result = run_peer_synthesis(workspace["id"], prompt, intent=intent, actor="admin")
            return json_response(self, 200 if result.get("ok") else 500, result)

        if self.path == "/api/proposals":
            conn, session_bundle = require_session(self)
            if not conn:
                return
            session, workspace = session_bundle
            body = parse_body(self)
            patch = body.get("patch", {})
            manifest = parse_json(workspace["manifest_json"], {})
            issues = validate_patch(manifest, patch)
            status = "rejected" if issues else "pending"
            proposal_id = conn.execute(
                "INSERT INTO proposals (workspace_id, title, summary, patch_json, status, validator_notes, created_at, applied_at) VALUES (?, ?, ?, ?, ?, ?, ?, NULL)",
                (workspace["id"], body.get("title", "Proposal").strip(), body.get("summary", "").strip(), json.dumps(patch), status, "\n".join(issues) if issues else "Validated and ready.", utc_now_iso())
            ).lastrowid
            append_event(conn, workspace["id"], "proposal.created", "admin", "proposal", str(proposal_id), {"status": status})
            conn.commit()
            conn.close()
            return json_response(self, 200, {"ok": True, "proposal_id": proposal_id, "status": status, "issues": issues})

        if self.path.startswith("/api/proposals/") and self.path.endswith("/apply"):
            conn, session_bundle = require_session(self)
            if not conn:
                return
            session, workspace = session_bundle
            proposal_id = int(self.path.strip("/").split("/")[2])
            proposal = conn.execute("SELECT * FROM proposals WHERE id = ? AND workspace_id = ?", (proposal_id, workspace["id"])).fetchone()
            if not proposal:
                conn.close()
                return json_response(self, 404, {"ok": False, "error": "Proposal not found"})
            manifest = parse_json(workspace["manifest_json"], {})
            patch = parse_json(proposal["patch_json"], {})
            issues = validate_patch(manifest, patch)
            if issues:
                conn.execute("UPDATE proposals SET status = ?, validator_notes = ? WHERE id = ?", ("rejected", "\n".join(issues), proposal_id))
                conn.commit()
                conn.close()
                return json_response(self, 400, {"ok": False, "issues": issues})
            new_manifest = apply_patch_to_manifest(manifest, patch)
            now = utc_now_iso()
            conn.execute("UPDATE workspaces SET manifest_json = ?, updated_at = ? WHERE id = ?", (json.dumps(new_manifest), now, workspace["id"]))
            conn.execute("UPDATE proposals SET status = ?, validator_notes = ?, applied_at = ? WHERE id = ?", ("applied", "Applied successfully.", now, proposal_id))
            append_event(conn, workspace["id"], "proposal.applied", "admin", "proposal", str(proposal_id), {"manifest_version": new_manifest["version"]})
            conn.commit()
            conn.close()
            return json_response(self, 200, {"ok": True, "manifest_version": new_manifest["version"]})

        return json_response(self, 404, {"ok": False, "error": "Not found"})

    def serve_static(self):
        path = self.path.split("?", 1)[0]
        if path == "/":
            path = "/index.html"
        target = (STATIC_DIR / path.lstrip("/")).resolve()
        try:
            if not str(target).startswith(str(STATIC_DIR.resolve())):
                return text_response(self, 403, "Forbidden")
            if not target.exists() or not target.is_file():
                target = STATIC_DIR / "index.html"
            mime = "text/plain; charset=utf-8"
            if target.suffix == ".html":
                mime = "text/html; charset=utf-8"
            elif target.suffix == ".css":
                mime = "text/css; charset=utf-8"
            elif target.suffix == ".js":
                mime = "application/javascript; charset=utf-8"
            elif target.suffix == ".json":
                mime = "application/json; charset=utf-8"
            content = target.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(content)))
            if target.name in ("service-worker.js", "manifest.json"):
                self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(content)
        except Exception as exc:
            text_response(self, 500, f"Static error: {exc}")

    def log_message(self, format, *args):
        return

def main():
    ensure_db()
    scheduler = threading.Thread(target=scheduler_loop, daemon=True)
    scheduler.start()
    httpd = ThreadingHTTPServer(("0.0.0.0", PORT), AppHandler)
    print(f"EVEZ-OS Peers running on 0.0.0.0:{PORT} with DB at {DB_PATH}")
    httpd.serve_forever()

if __name__ == "__main__":
    main()
