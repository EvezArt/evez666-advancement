
const state = { token: localStorage.getItem('evez_token') || '', data: null };

const qs = (s) => document.querySelector(s);

async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (state.token) headers['X-Session-Token'] = state.token;
  const res = await fetch(path, { headers, ...options });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || JSON.stringify(data));
  return data;
}

function chip(text, live) {
  const span = document.createElement('span');
  span.className = `chip ${live ? 'live' : 'dead'}`;
  span.textContent = text;
  return span;
}

function short(text, max=180) {
  text = text || '';
  return text.length > max ? text.slice(0, max-1) + '…' : text;
}



function renderTriad(data) {
  const host = qs('#triadResult');
  if (!host) return;
  host.innerHTML = '';
  const final = document.createElement('div');
  final.className = 'panel';
  final.innerHTML = `<div><strong>final via ${data.final.provider}</strong></div><div>${short(data.final.text || '', 800)}</div>${(data.final.citations || []).length ? `<div class="muted">citations: ${(data.final.citations || []).length}</div>` : ''}`;
  host.appendChild(final);

  const peers = document.createElement('div');
  peers.className = 'cards';
  (data.peers || []).forEach((peer) => {
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `<div class="card-head"><h3>${peer.provider}</h3></div><div>${short(peer.text || '', 280)}</div>${(peer.citations || []).length ? `<div class="muted">citations: ${(peer.citations || []).length}</div>` : ''}`;
    peers.appendChild(card);
  });
  host.appendChild(peers);

  if ((data.errors || []).length) {
    const err = document.createElement('div');
    err.className = 'muted';
    err.textContent = data.errors.join(' | ');
    host.appendChild(err);
  }
}

function renderProviders(providers) {
  const host = qs('#providers');
  const tpl = qs('#providerTemplate');
  host.innerHTML = '';
  Object.entries(providers).forEach(([key, info]) => {
    const node = tpl.content.cloneNode(true);
    node.querySelector('.provider-name').textContent = `${info.label} (${key})`;
    const liveEl = node.querySelector('.provider-live');
    liveEl.textContent = info.live ? 'live' : 'offline';
    liveEl.classList.add(info.live ? 'live' : 'dead');
    node.querySelector('.provider-model').textContent = `model: ${info.model}`;
    const strengths = node.querySelector('.provider-strengths');
    (info.strengths || []).forEach((s) => strengths.appendChild(chip(s, true)));
    node.querySelector('.provider-contract').textContent = `contract: citations=${!!info.contract.citations}, json=${!!info.contract.json}, web=${!!info.contract.web}`;
    host.appendChild(node);
  });
}

function renderRuns(host, runs) {
  host.innerHTML = '';
  if (!runs.length) {
    const empty = document.createElement('div');
    empty.className = 'muted';
    empty.textContent = 'No runs yet.';
    host.appendChild(empty);
    return;
  }
  runs.forEach((run) => {
    const div = document.createElement('div');
    div.className = 'run';
    const out = run.output || {};
    const cites = (out.citations || []).length;
    div.innerHTML = `
      <div><span class="chip ${run.status === 'success' ? 'live' : 'dead'}">${run.status}</span> <span class="chip">${run.provider || 'n/a'}</span></div>
      <div class="muted">${run.started_at || ''}</div>
      <div>${short(out.text || run.error || '', 220)}</div>
      ${cites ? `<div class="muted">citations: ${cites}</div>` : ''}
    `;
    host.appendChild(div);
  });
}

function fillAgentForm(agent) {
  const form = qs('#agentForm');
  form.name.value = agent.name;
  form.intent.value = agent.intent;
  form.budget_calls_per_day.value = agent.budget_calls_per_day;
  form.objective.value = agent.objective;
  form.system_prompt.value = agent.system_prompt;
  form.user_prompt.value = agent.user_prompt;
  form.schedule_minutes.value = agent.schedule_minutes;
  form.provider_order.value = (agent.provider_order || []).join(', ');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function renderAgents(agents) {
  const host = qs('#agents');
  const tpl = qs('#agentTemplate');
  host.innerHTML = '';
  agents.forEach((agent) => {
    const node = tpl.content.cloneNode(true);
    node.querySelector('.agent-name').textContent = agent.name;
    node.querySelector('.agent-meta').textContent = `${agent.intent} · every ${agent.schedule_minutes} min · budget ${agent.budget_calls_per_day}/day · ${agent.enabled ? 'enabled' : 'disabled'}`;
    node.querySelector('.objective').textContent = agent.objective;
    node.querySelector('.route').textContent = `route: ${(agent.provider_order || []).join(' → ')}`;
    renderRuns(node.querySelector('.runs'), agent.recent_runs || []);
    node.querySelector('.agent-name').onclick = () => fillAgentForm(agent);
    node.querySelector('.run-btn').onclick = async () => {
      try { await api(`/api/agents/${agent.id}/run`, { method: 'POST' }); await loadWorkspace(); } catch (e) { alert(e.message); }
    };
    node.querySelector('.toggle-btn').onclick = async () => {
      try { await api(`/api/agents/${agent.id}/toggle`, { method: 'POST' }); await loadWorkspace(); } catch (e) { alert(e.message); }
    };
    host.appendChild(node);
  });
}

function renderProposals(proposals) {
  const host = qs('#proposals');
  const tpl = qs('#proposalTemplate');
  host.innerHTML = '';
  proposals.forEach((p) => {
    const node = tpl.content.cloneNode(true);
    node.querySelector('.proposal-title').textContent = p.title;
    node.querySelector('.proposal-meta').textContent = `${p.status} · ${p.created_at}`;
    node.querySelector('.proposal-summary').textContent = p.summary;
    node.querySelector('.proposal-patch').textContent = JSON.stringify(p.patch_json || {}, null, 2);
    node.querySelector('.proposal-notes').textContent = p.validator_notes || '';
    node.querySelector('.apply-btn').onclick = async () => {
      try { await api(`/api/proposals/${p.id}/apply`, { method: 'POST' }); await loadWorkspace(); } catch (e) { alert(e.message); }
    };
    if (p.status !== 'pending') node.querySelector('.apply-btn').disabled = true;
    host.appendChild(node);
  });
}

function renderEvents(events) {
  const host = qs('#events');
  const tpl = qs('#eventTemplate');
  host.innerHTML = '';
  events.forEach((ev) => {
    const node = tpl.content.cloneNode(true);
    node.querySelector('.event-type').textContent = ev.event_type;
    node.querySelector('.event-time').textContent = ev.created_at;
    node.querySelector('.event-actor').textContent = `${ev.actor} · ${ev.entity_type} ${ev.entity_id}`;
    node.querySelector('.event-payload').textContent = short(ev.payload_json, 320);
    host.appendChild(node);
  });
}

async function bootstrap() {
  const data = await api('/api/bootstrap');
  qs('#bootstrapInfo').textContent = `workspaces: ${data.workspaces.map(w => w.slug).join(', ')}`;
}

async function loadWorkspace() {
  const data = await api('/api/workspace');
  state.data = data;
  qs('#authPanel').classList.add('hidden');
  qs('#shell').classList.remove('hidden');
  qs('#logoutBtn').classList.remove('hidden');
  qs('#workspaceName').textContent = data.workspace.name;
  qs('#manifestVersion').textContent = String(data.manifest.version || 1);
  qs('#serverTime').textContent = data.server_time;
  renderProviders(data.providers || {});
  renderAgents(data.agents || []);
  renderProposals(data.proposals || []);
  renderEvents(data.events || []);
}

qs('#loginBtn').onclick = async () => {
  try {
    const data = await api('/api/login', {
      method: 'POST',
      body: JSON.stringify({ slug: qs('#slugInput').value.trim(), passcode: qs('#passInput').value }),
    });
    state.token = data.session_token;
    localStorage.setItem('evez_token', state.token);
    await loadWorkspace();
  } catch (e) {
    alert(e.message);
  }
};

qs('#logoutBtn').onclick = () => {
  state.token = '';
  localStorage.removeItem('evez_token');
  qs('#shell').classList.add('hidden');
  qs('#authPanel').classList.remove('hidden');
  qs('#logoutBtn').classList.add('hidden');
};

qs('#refreshBtn').onclick = async () => {
  if (state.token) await loadWorkspace();
  else await bootstrap();
};

qs('#agentForm').onsubmit = async (e) => {
  e.preventDefault();
  const f = e.currentTarget;
  const payload = {
    name: f.name.value.trim(),
    intent: f.intent.value,
    budget_calls_per_day: Number(f.budget_calls_per_day.value || 24),
    objective: f.objective.value.trim(),
    system_prompt: f.system_prompt.value.trim(),
    user_prompt: f.user_prompt.value.trim(),
    schedule_minutes: Number(f.schedule_minutes.value || 240),
    provider_order: f.provider_order.value.trim(),
  };
  try {
    await api('/api/agents', { method: 'POST', body: JSON.stringify(payload) });
    f.reset();
    f.intent.value = 'reasoning';
    f.budget_calls_per_day.value = 24;
    f.schedule_minutes.value = 240;
    await loadWorkspace();
  } catch (e) { alert(e.message); }
};

qs('#proposalForm').onsubmit = async (e) => {
  e.preventDefault();
  const f = e.currentTarget;
  try {
    const patch = JSON.parse(f.patch.value);
    await api('/api/proposals', {
      method: 'POST',
      body: JSON.stringify({ title: f.title.value.trim(), summary: f.summary.value.trim(), patch }),
    });
    await loadWorkspace();
  } catch (e2) {
    alert(e2.message);
  }
};


const triadForm = qs('#triadForm');
if (triadForm) {
  triadForm.onsubmit = async (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    try {
      const result = await api('/api/triad', {
        method: 'POST',
        body: JSON.stringify({ intent: form.intent.value, prompt: form.prompt.value.trim() }),
      });
      renderTriad(result);
      await load();
    } catch (err) {
      alert(err.message);
    }
  };
}

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/service-worker.js').catch(() => {}));
}

(async () => {
  try {
    await bootstrap();
    if (state.token) await loadWorkspace();
  } catch (e) { console.error(e); }
})();
