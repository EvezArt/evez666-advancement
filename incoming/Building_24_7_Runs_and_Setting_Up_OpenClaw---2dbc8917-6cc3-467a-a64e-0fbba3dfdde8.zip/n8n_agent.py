import requests
from typing import Any, Dict, Optional
from .base_agent import BaseAgent

class N8nAgent(BaseAgent):
    def __init__(self, bus, config: Optional[Dict[str, Any]] = None):
        super().__init__(bus, config)
        self.webhook_url = self.config.get("N8N_WEBHOOK_URL", "https://evez666.n8n.cloud/webhook/evez-os-sync")

    def _think(self):
        # Fetch latest state from spine
        latest_event = self.bus.get_latest_state(event_type="OODA_CYCLE")
        if latest_event:
            self._sync_to_n8n(latest_event)

    def _sync_to_n8n(self, event: Dict[str, Any]):
        try:
            # In a real scenario, we would use the user's n8n credentials
            # For now, we simulate the sync
            payload = {
                "agent_id": self.agent_id,
                "event": event
            }
            # response = requests.post(self.webhook_url, json=payload, timeout=5)
            # self.bus.publish("LOG", "N8N_SYNC_SUCCESS", self.agent_id, {"status_code": response.status_code})
            self.bus.publish("LOG", "N8N_SYNC_SIMULATED", self.agent_id, {"payload": payload})
        except Exception as e:
            self.bus.publish("LOG", "N8N_SYNC_ERROR", self.agent_id, {"error": str(e)})
