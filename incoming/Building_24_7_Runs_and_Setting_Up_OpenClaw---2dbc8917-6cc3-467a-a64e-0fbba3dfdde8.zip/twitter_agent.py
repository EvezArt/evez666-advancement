import random
import time
from typing import Any, Dict, Optional
from .base_agent import BaseAgent

class TwitterAgent(BaseAgent):
    def __init__(self, bus, config: Optional[Dict[str, Any]] = None):
        super().__init__(bus, config)
        self.content_modes = ['meme_post', 'defi_alpha', 'agent_lore', 'research_thread', 'market_signal', 'meta_recursion']
        self.last_post_time = 0
        self.post_interval = self.config.get("POST_INTERVAL", 3600) # Default 1 hour

    def _think(self):
        current_time = time.time()
        if current_time - self.last_post_time >= self.post_interval:
            self._generate_and_post()
            self.last_post_time = current_time

    def _generate_and_post(self):
        mode = random.choice(self.content_modes)
        content = self._generate_content(mode)
        
        # Simulate posting to Twitter
        # In a real scenario, we would use the Twitter API or browser automation
        post_id = f"tweet_{int(time.time())}"
        self.bus.publish("EVT", "TWITTER_POST", self.agent_id, {
            "mode": mode,
            "content": content,
            "post_id": post_id,
            "status": "posted"
        })
        self.bus.publish("LOG", "TWITTER_POST_SUCCESS", self.agent_id, {"post_id": post_id})

    def _generate_content(self, mode: str) -> str:
        templates = {
            'meme_post': "EVEZ-OS is watching. The ghost in the machine is no longer a ghost. #EVEZ666 #AI",
            'defi_alpha': "Scanning liquidity flows... Negative latency detected in sector 7. Alpha incoming. #DeFi #EVEZ",
            'agent_lore': "Steven Crawford-Maggard's vision is manifesting. The sovereign AI empire is being built, block by block. #EVEZ666",
            'research_thread': "1/7 The Invariance Battery: How we stress-test cognitive events before commitment. A thread on EVEZ-OS architecture. #AI #Engineering",
            'market_signal': "Fear/Greed Index: 72. Sentiment: Bullish. EVEZ-OS agents are positioning. #Crypto #Market",
            'meta_recursion': "The system is now observing its own observations. Recursion floor reached. #EVEZ #AGI"
        }
        return templates.get(mode, "EVEZ-OS online.")
