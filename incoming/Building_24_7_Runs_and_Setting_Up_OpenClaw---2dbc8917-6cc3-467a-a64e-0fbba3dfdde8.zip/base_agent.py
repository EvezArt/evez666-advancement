import threading
import time
import uuid
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

class BaseAgent(ABC, threading.Thread):
    def __init__(self, bus, config: Optional[Dict[str, Any]] = None):
        super().__init__(daemon=True)
        self.bus = bus
        self.config = config or {}
        self.agent_id = f"{self.__class__.__name__}_{uuid.uuid4().hex[:8]}"
        self.running = True
        self.cycle_sleep = self.config.get("CYCLE_SLEEP", 5)

    def run(self):
        self.bus.publish("LOG", "AGENT_START", self.agent_id, {"config": self.config})
        while self.running:
            try:
                self._think()
                self.bus.publish("LOG", "AGENT_HEARTBEAT", self.agent_id, {})
            except Exception as e:
                self.bus.publish("LOG", "AGENT_ERROR", self.agent_id, {"error": str(e)})
            time.sleep(self.cycle_sleep)

    @abstractmethod
    def _think(self):
        pass

    def _stop(self):
        self.running = False
        self.bus.publish("LOG", "AGENT_STOP", self.agent_id, {})
