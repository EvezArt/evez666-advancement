import time
import signal
import sys
from pathlib import Path
from daemon.lord_daemon import DaemonBus
from daemon.agents.ooda_agent import OODAAgent
from daemon.agents.n8n_agent import N8nAgent
from daemon.agents.twitter_agent import TwitterAgent

def main():
    spine_path = Path("/home/ubuntu/evez_os/spine/lord_spine.jsonl")
    bus = DaemonBus(spine_path=spine_path)
    
    # Initialize agents
    agents = [
        OODAAgent(bus=bus, config={"CYCLE_SLEEP": 5}),
        N8nAgent(bus=bus, config={"CYCLE_SLEEP": 10}),
        TwitterAgent(bus=bus, config={"CYCLE_SLEEP": 15, "POST_INTERVAL": 60}) # 1 minute for demo
    ]
    
    # Start agents
    for agent in agents:
        agent.start()
        print(f"[LORD Daemon] Started agent: {agent.agent_id}")
        
    print("[LORD Daemon] All agents started. Press Ctrl-C to stop.")
    
    def signal_handler(sig, frame):
        print("\n[LORD Daemon] Stopping agents...")
        for agent in agents:
            agent._stop()
        sys.exit(0)
        
    signal.signal(signal.SIGINT, signal_handler)
    
    # Keep main thread alive
    while True:
        time.sleep(1)

if __name__ == "__main__":
    main()
