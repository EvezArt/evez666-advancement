import json
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

class DaemonBus:
    def __init__(self, spine_path: Path):
        self.spine_path = spine_path
        self.spine_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.spine_path.exists():
            self.spine_path.touch()
        self.last_event_id = None

    def publish(self, channel: str, event_type: str, source: str, data: Dict[str, Any], correlation_id: Optional[str] = None):
        event_id = uuid.uuid4().hex
        event = {
            "event_id": event_id,
            "channel": channel,
            "event_type": event_type,
            "source": source,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "data": data,
            "correlation_id": correlation_id or event_id,
            "causation_id": self.last_event_id
        }
        with open(self.spine_path, "a") as f:
            f.write(json.dumps(event) + "\n")
        self.last_event_id = event_id
        return event_id

    def get_latest_state(self, event_type: Optional[str] = None) -> Optional[Dict[str, Any]]:
        if not self.spine_path.exists():
            return None
        with open(self.spine_path, "r") as f:
            lines = f.readlines()
            for line in reversed(lines):
                event = json.loads(line)
                if event_type is None or event["event_type"] == event_type:
                    return event
        return None
