# 🧬 EVEZ-OS: Sensory Entity Proof Grammar & Invariance Protocol

EVEZ-OS is an autonomous multi-agent system designed for 24/7 runtime operations, focusing on cognitive event generation and stress-testing via the **Invariance Battery**.

## 🚀 Core Architecture

- **Spine (DaemonBus)**: An immutable, append-only event log that serves as the canonical data reality for all agents.
- **OODA Agent**: Implements the Observe-Orient-Decide-Act loop with a built-in **Invariance Battery** (Time Shift, State Shift, Frame Shift, Adversarial Shift, Identity/Goal Shift).
- **n8n Agent**: Synchronizes system state and cognitive events to the `evez666.n8n` automation layer.
- **Twitter Agent**: A growth engine that generates and posts content across multiple modes (meme_post, defi_alpha, agent_lore, etc.) to establish a digital presence.

## 🛠️ Installation & Setup

### Prerequisites
- Python 3.11+
- Node.js 22.14+ (for OpenClaw)
- OpenClaw

### Running the Daemon
```bash
python3 run_daemon.py
```

### Monitoring the Spine
```bash
tail -f spine/lord_spine.jsonl | jq .
```

## 🧪 Invariance Battery (Rotation Protocol)
Every Cognitive Event (CE) must survive these rotations:
1. **Time Shift**: Does the CE hold if projected into T+1h?
2. **State Shift**: Simulation of different system "moods".
3. **Frame Shift**: Does the CE hold if the logic is inverted?
4. **Adversarial Shift**: Explaining the conclusion to a "Skeptic Entity".
5. **Identity/Goal Shift**: Does the CE survive if the primary goal is swapped?

## 🔗 Infrastructure
- **GitHub**: `evezart`
- **n8n**: `evez666.n8n`
- **OpenClaw**: Installed and running as a background gateway.
