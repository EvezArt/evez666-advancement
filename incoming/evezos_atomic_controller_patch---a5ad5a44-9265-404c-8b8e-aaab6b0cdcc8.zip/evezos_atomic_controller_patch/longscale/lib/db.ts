import { Pool, type PoolClient } from "pg";

let poolPromise: Promise<Pool | null> | null = null;

export async function getPool(): Promise<Pool | null> {
  if (poolPromise) return poolPromise;
  poolPromise = (async () => {
    const connectionString = process.env.POSTGRES_URL;
    const host = process.env.POSTGRES_HOST;
    const database = process.env.POSTGRES_DB;
    if (!connectionString && !(host && database)) return null;
    const pool = new Pool(connectionString ? { connectionString } : {
      host,
      port: Number(process.env.POSTGRES_PORT || 5432),
      user: process.env.POSTGRES_USER,
      password: process.env.POSTGRES_PASSWORD,
      database,
    });
    await ensureCoreTables(pool);
    return pool;
  })().catch(() => null);
  return poolPromise;
}

export async function withClient<T>(fn: (client: PoolClient) => Promise<T>): Promise<T> {
  const pool = await getPool();
  if (!pool) {
    throw new Error("Postgres is not connected. Configure POSTGRES_URL or POSTGRES_HOST/POSTGRES_DB.");
  }
  const client = await pool.connect();
  try {
    return await fn(client);
  } finally {
    client.release();
  }
}

async function ensureCoreTables(pool: Pool) {
  await pool.query(`CREATE TABLE IF NOT EXISTS ledger_events (
    id TEXT PRIMARY KEY,
    ts TIMESTAMP WITH TIME ZONE NOT NULL,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    prev_hash TEXT,
    entry_hash TEXT NOT NULL,
    metadata JSONB
  )`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_ledger_ts ON ledger_events (ts DESC)`);

  await pool.query(`CREATE TABLE IF NOT EXISTS canonical_state (
    state_key TEXT PRIMARY KEY,
    version BIGINT NOT NULL,
    state_hash TEXT NOT NULL,
    last_sequence BIGINT NOT NULL,
    snapshot JSONB NOT NULL,
    last_receipt_id TEXT,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
  )`);

  await pool.query(`CREATE TABLE IF NOT EXISTS execution_receipts (
    receipt_id TEXT PRIMARY KEY,
    state_key TEXT NOT NULL,
    idempotency_key TEXT NOT NULL UNIQUE,
    sequence BIGINT NOT NULL,
    expected_version BIGINT NOT NULL,
    resulting_version BIGINT NOT NULL,
    expected_hash TEXT NOT NULL,
    resulting_hash TEXT NOT NULL,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    falsifier TEXT NOT NULL,
    committed BOOLEAN NOT NULL DEFAULT TRUE,
    commit_proof TEXT NOT NULL,
    details JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
  )`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_receipts_state_seq ON execution_receipts (state_key, sequence DESC)`);

  await pool.query(`CREATE TABLE IF NOT EXISTS execution_rejections (
    rejection_id TEXT PRIMARY KEY,
    state_key TEXT NOT NULL,
    attempted_sequence BIGINT,
    attempted_version BIGINT,
    attempted_hash TEXT,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    falsifier TEXT,
    reason TEXT NOT NULL,
    details JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
  )`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_rejections_state_created ON execution_rejections (state_key, created_at DESC)`);

  await pool.query(`CREATE TABLE IF NOT EXISTS controller_runs (
    run_id TEXT PRIMARY KEY,
    state_key TEXT NOT NULL,
    action TEXT NOT NULL,
    actor TEXT NOT NULL,
    receipt_id TEXT NOT NULL,
    artifact_hash TEXT NOT NULL,
    verification JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
  )`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_controller_runs_created ON controller_runs (created_at DESC)`);
}

