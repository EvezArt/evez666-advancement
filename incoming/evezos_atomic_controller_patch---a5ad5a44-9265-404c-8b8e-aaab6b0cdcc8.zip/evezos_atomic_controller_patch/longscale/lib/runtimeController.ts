import crypto from "crypto";
import { ExecutionRejection, executeMutation, getCanonicalState, hashObject, type CanonicalState, type ExecuteMutationInput, type ExecutionReceipt } from "./execution";

export type ExecutionArtifact = {
  artifactId: string;
  action: string;
  actor: string;
  inputHash: string;
  codeHash: string;
  environmentHash: string;
  deterministic: boolean;
  seed: string | null;
  startedAt: string;
  completedAt: string;
  durationMs: number;
  resultHash: string;
  result: unknown;
  metadata: Record<string, unknown>;
};

export type ArtifactVerification = {
  verified: true;
  artifactHash: string;
  recomputedResultHash: string;
  checks: {
    hasInputHash: true;
    hasCodeHash: true;
    hasEnvironmentHash: true;
    hasResultHash: true;
    resultHashMatches: true;
    durationNonNegative: true;
  };
};

export type AtomicControllerResult = {
  receipt: ExecutionReceipt;
  canonicalState: CanonicalState;
  artifact: ExecutionArtifact;
  verification: ArtifactVerification;
};

export type AtomicControllerInput = {
  stateKey?: string;
  action: string;
  actor: string;
  falsifier: string;
  idempotencyKey: string;
  details?: Record<string, unknown>;
  deterministic?: boolean;
  seed?: string | null;
  codeIdentity: string;
  trigger: () => Promise<unknown>;
};

function sha(input: string) {
  return crypto.createHash("sha256").update(input).digest("hex");
}

function makeId(prefix: string) {
  return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2, 10)}`;
}

function getEnvironmentFingerprint() {
  return {
    nodeEnv: process.env.NODE_ENV || "unknown",
    app: "evezos-longscale-grounded",
    postgres: Boolean(process.env.POSTGRES_URL || process.env.POSTGRES_HOST),
    redis: Boolean(process.env.REDIS_URL || process.env.REDIS_HOST),
    runtimeMode: process.env.EVEZ_RUNTIME_MODE || "atomic-controller",
  };
}

function buildArtifact(params: {
  action: string;
  actor: string;
  details: Record<string, unknown>;
  result: unknown;
  deterministic: boolean;
  seed: string | null;
  codeIdentity: string;
  startedAt: string;
  completedAt: string;
}): ExecutionArtifact {
  const inputHash = hashObject(params.details);
  const codeHash = sha(params.codeIdentity);
  const environmentHash = hashObject(getEnvironmentFingerprint());
  const resultHash = hashObject(params.result);
  const durationMs = Math.max(0, new Date(params.completedAt).getTime() - new Date(params.startedAt).getTime());
  return {
    artifactId: makeId("artifact"),
    action: params.action,
    actor: params.actor,
    inputHash,
    codeHash,
    environmentHash,
    deterministic: params.deterministic,
    seed: params.seed,
    startedAt: params.startedAt,
    completedAt: params.completedAt,
    durationMs,
    resultHash,
    result: params.result,
    metadata: {
      codeIdentity: params.codeIdentity,
      environment: getEnvironmentFingerprint(),
    },
  };
}

function verifyArtifact(artifact: ExecutionArtifact): ArtifactVerification {
  const recomputedResultHash = hashObject(artifact.result);
  if (!artifact.inputHash) throw new ExecutionRejection("artifact_input_hash_missing", 422);
  if (!artifact.codeHash) throw new ExecutionRejection("artifact_code_hash_missing", 422);
  if (!artifact.environmentHash) throw new ExecutionRejection("artifact_environment_hash_missing", 422);
  if (!artifact.resultHash) throw new ExecutionRejection("artifact_result_hash_missing", 422);
  if (recomputedResultHash !== artifact.resultHash) {
    throw new ExecutionRejection("artifact_result_hash_mismatch", 422, {
      expected: artifact.resultHash,
      recomputed: recomputedResultHash,
    });
  }
  if (artifact.durationMs < 0) throw new ExecutionRejection("artifact_negative_duration", 422);
  return {
    verified: true,
    artifactHash: hashObject({ ...artifact, result: undefined }),
    recomputedResultHash,
    checks: {
      hasInputHash: true,
      hasCodeHash: true,
      hasEnvironmentHash: true,
      hasResultHash: true,
      resultHashMatches: true,
      durationNonNegative: true,
    },
  };
}

export async function runAtomicControllerAction(input: AtomicControllerInput): Promise<AtomicControllerResult> {
  const current = await getCanonicalState(input.stateKey ?? "runtime");
  const startedAt = new Date().toISOString();

  let result: unknown;
  try {
    result = await input.trigger();
  } catch (error) {
    throw new ExecutionRejection("controller_trigger_failed", 502, {
      message: error instanceof Error ? error.message : String(error),
      action: input.action,
    });
  }

  const completedAt = new Date().toISOString();
  const artifact = buildArtifact({
    action: input.action,
    actor: input.actor,
    details: input.details ?? {},
    result,
    deterministic: input.deterministic ?? true,
    seed: input.seed ?? null,
    codeIdentity: input.codeIdentity,
    startedAt,
    completedAt,
  });

  const verification = verifyArtifact(artifact);

  const mutation: ExecuteMutationInput = {
    stateKey: input.stateKey ?? "runtime",
    action: input.action,
    actor: input.actor,
    falsifier: input.falsifier,
    idempotencyKey: input.idempotencyKey,
    sequence: current.lastSequence + 1,
    expectedVersion: current.version,
    expectedHash: current.stateHash,
    details: {
      ...(input.details ?? {}),
      artifact,
      verification,
      committedBy: "runtime-controller",
    },
  };

  const { receipt, canonicalState } = await executeMutation(mutation);
  return { receipt, canonicalState, artifact, verification };
}
