import crypto from "crypto";
import type { PoolClient } from "pg";
import { withClient } from "./db";

export type RuntimeSnapshot = {
  bus: { tasks: Array<{ id: string; title: string; payload: unknown; status: "pending" | "in_progress" | "completed"; createdAt: string }> };
  lastAgentRun: unknown | null;
  metadata: Record<string, unknown>;
};

export type CanonicalState = {
  stateKey: string;
  version: number;
  stateHash: string;
  lastSequence: number;
  snapshot: RuntimeSnapshot;
  lastReceiptId: string | null;
  updatedAt?: string;
};

export type ExecuteMutationInput = {
  stateKey?: string;
  action: string;
  actor?: string;
  falsifier: string;
  idempotencyKey: string;
  sequence: number;
  expectedVersion: number;
  expectedHash: string;
  details?: Record<string, unknown>;
};

export type ExecutionReceipt = {
  receiptId: string;
  stateKey: string;
  idempotencyKey: string;
  sequence: number;
  expectedVersion: number;
  resultingVersion: number;
  expectedHash: string;
  resultingHash: string;
  actor: string;
  action: string;
  falsifier: string;
  committed: true;
  commitProof: string;
  details: Record<string, unknown>;
  createdAt: string;
};

export class ExecutionRejection extends Error {
  constructor(public reason: string, public status = 409, public context?: Record<string, unknown>) {
    super(reason);
  }
}

const EXECUTION_LOCK_KEY = 84512031;

function stableStringify(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map((v) => stableStringify(v)).join(",")}]`;
  const entries = Object.entries(value as Record<string, unknown>).sort(([a], [b]) => a.localeCompare(b));
  return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${stableStringify(v)}`).join(",")}}`;
}

export function hashObject(value: unknown) {
  return crypto.createHash("sha256").update(stableStringify(value)).digest("hex");
}

function defaultSnapshot(): RuntimeSnapshot {
  return { bus: { tasks: [] }, lastAgentRun: null, metadata: {} };
}

function makeId(prefix: string) {
  return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2, 10)}`;
}

async function appendLedgerEvent(client: PoolClient, entry: {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  details: unknown;
  payloadHash: string;
  prevHash: string | null;
  entryHash: string;
}) {
  await client.query(
    `INSERT INTO ledger_events (id, ts, actor, action, payload_hash, prev_hash, entry_hash, metadata)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
    [entry.id, entry.timestamp, entry.actor, entry.action, entry.payloadHash, entry.prevHash, entry.entryHash, entry.details ?? {}],
  );
}

function computeLedgerHash(input: string) {
  return crypto.createHash("sha256").update(input).digest("hex");
}

async function getOrCreateCanonicalState(client: PoolClient, stateKey: string): Promise<CanonicalState> {
  const result = await client.query(`SELECT state_key, version, state_hash, last_sequence, snapshot, last_receipt_id, updated_at FROM canonical_state WHERE state_key = $1 FOR UPDATE`, [stateKey]);
  if (result.rows[0]) {
    const row = result.rows[0];
    return {
      stateKey: row.state_key,
      version: Number(row.version),
      stateHash: row.state_hash,
      lastSequence: Number(row.last_sequence),
      snapshot: row.snapshot,
      lastReceiptId: row.last_receipt_id,
      updatedAt: new Date(row.updated_at).toISOString(),
    };
  }
  const snapshot = defaultSnapshot();
  const stateHash = hashObject(snapshot);
  await client.query(
    `INSERT INTO canonical_state (state_key, version, state_hash, last_sequence, snapshot, last_receipt_id)
     VALUES ($1, 0, $2, 0, $3, NULL)`,
    [stateKey, stateHash, snapshot],
  );
  return { stateKey, version: 0, stateHash, lastSequence: 0, snapshot, lastReceiptId: null };
}

function applyAction(snapshot: RuntimeSnapshot, input: ExecuteMutationInput): RuntimeSnapshot {
  const next = JSON.parse(JSON.stringify(snapshot)) as RuntimeSnapshot;
  const details = input.details ?? {};
  switch (input.action) {
    case "bus.add_task": {
      const title = String(details.title || "").trim();
      if (!title) throw new ExecutionRejection("task_title_required", 400);
      next.bus.tasks.push({
        id: makeId("task"),
        title,
        payload: details.payload ?? {},
        status: "pending",
        createdAt: new Date().toISOString(),
      });
      return next;
    }
    case "bus.update_task": {
      const taskId = String(details.taskId || "");
      const status = String(details.status || "");
      if (!taskId) throw new ExecutionRejection("task_id_required", 400);
      if (!["pending", "in_progress", "completed"].includes(status)) throw new ExecutionRejection("invalid_task_status", 400);
      const task = next.bus.tasks.find((item) => item.id === taskId);
      if (!task) throw new ExecutionRejection("task_not_found", 404, { taskId });
      task.status = status as "pending" | "in_progress" | "completed";
      return next;
    }
    case "bus.clear": {
      next.bus.tasks = [];
      return next;
    }
    case "agent.run.complete": {
      next.lastAgentRun = {
        result: details.result ?? null,
        source: "n8n",
        at: new Date().toISOString(),
        artifact: details.artifact ?? null,
        verification: details.verification ?? null,
      };
      next.metadata.lastAgentRunReceiptIntent = input.idempotencyKey;
      next.metadata.lastCommittedArtifactHash = (details.verification as Record<string, unknown> | undefined)?.artifactHash ?? null;
      return next;
    }
    case "controller.execute": {
      next.metadata.lastControllerExecution = {
        action: details.targetAction ?? input.action,
        artifact: details.artifact ?? null,
        verification: details.verification ?? null,
        at: new Date().toISOString(),
      };
      return next;
    }
    case "runtime.seed": {
      return details.snapshot as RuntimeSnapshot;
    }
    default:
      throw new ExecutionRejection("unsupported_action", 400, { action: input.action });
  }
}

async function insertRejection(client: PoolClient, input: ExecuteMutationInput, reason: string, context?: Record<string, unknown>) {
  const rejectionId = makeId("reject");
  await client.query(
    `INSERT INTO execution_rejections (rejection_id, state_key, attempted_sequence, attempted_version, attempted_hash, actor, action, falsifier, reason, details)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
    [
      rejectionId,
      input.stateKey ?? "runtime",
      input.sequence,
      input.expectedVersion,
      input.expectedHash,
      input.actor ?? "ui.operator",
      input.action,
      input.falsifier,
      reason,
      { input: input.details ?? {}, context: context ?? {} },
    ],
  );
}

export async function getCanonicalState(stateKey = "runtime"): Promise<CanonicalState> {
  return withClient(async (client) => {
    await client.query("BEGIN");
    try {
      await client.query(`SELECT pg_advisory_xact_lock($1)`, [EXECUTION_LOCK_KEY]);
      const state = await getOrCreateCanonicalState(client, stateKey);
      await client.query("COMMIT");
      return state;
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    }
  });
}

export async function getRecentReceipts(limit = 25): Promise<ExecutionReceipt[]> {
  return withClient(async (client) => {
    const result = await client.query(`SELECT * FROM execution_receipts ORDER BY created_at DESC LIMIT $1`, [limit]);
    return result.rows.map((row) => ({
      receiptId: row.receipt_id,
      stateKey: row.state_key,
      idempotencyKey: row.idempotency_key,
      sequence: Number(row.sequence),
      expectedVersion: Number(row.expected_version),
      resultingVersion: Number(row.resulting_version),
      expectedHash: row.expected_hash,
      resultingHash: row.resulting_hash,
      actor: row.actor,
      action: row.action,
      falsifier: row.falsifier,
      committed: Boolean(row.committed),
      commitProof: row.commit_proof,
      details: row.details ?? {},
      createdAt: new Date(row.created_at).toISOString(),
    }));
  });
}

export async function verifyReceipt(receiptId: string) {
  return withClient(async (client) => {
    const result = await client.query(`SELECT * FROM execution_receipts WHERE receipt_id = $1 LIMIT 1`, [receiptId]);
    const row = result.rows[0];
    if (!row) return { valid: false, reason: "receipt_not_found" };
    const state = await getOrCreateCanonicalState(client, row.state_key);
    const valid = state.lastReceiptId === row.receipt_id && state.stateHash === row.resulting_hash && state.version === Number(row.resulting_version);
    return {
      valid,
      reason: valid ? null : "receipt_commit_mismatch",
      canonicalState: state,
      receiptId,
    };
  });
}

export async function executeMutation(input: ExecuteMutationInput): Promise<{ receipt: ExecutionReceipt; canonicalState: CanonicalState }> {
  const stateKey = input.stateKey ?? "runtime";
  if (!input.falsifier || !String(input.falsifier).trim()) throw new ExecutionRejection("falsifier_required", 400);
  if (!input.idempotencyKey || !String(input.idempotencyKey).trim()) throw new ExecutionRejection("idempotency_key_required", 400);
  return withClient(async (client) => {
    await client.query("BEGIN");
    try {
      await client.query(`SELECT pg_advisory_xact_lock($1)`, [EXECUTION_LOCK_KEY]);

      const replay = await client.query(`SELECT * FROM execution_receipts WHERE idempotency_key = $1 LIMIT 1`, [input.idempotencyKey]);
      if (replay.rows[0]) {
        const row = replay.rows[0];
        const canonicalState = await getOrCreateCanonicalState(client, row.state_key);
        await client.query("COMMIT");
        return {
          receipt: {
            receiptId: row.receipt_id,
            stateKey: row.state_key,
            idempotencyKey: row.idempotency_key,
            sequence: Number(row.sequence),
            expectedVersion: Number(row.expected_version),
            resultingVersion: Number(row.resulting_version),
            expectedHash: row.expected_hash,
            resultingHash: row.resulting_hash,
            actor: row.actor,
            action: row.action,
            falsifier: row.falsifier,
            committed: true,
            commitProof: row.commit_proof,
            details: row.details ?? {},
            createdAt: new Date(row.created_at).toISOString(),
          },
          canonicalState,
        };
      }

      const current = await getOrCreateCanonicalState(client, stateKey);
      if (input.expectedHash !== current.stateHash) {
        await insertRejection(client, input, "pre_state_hash_mismatch", { currentHash: current.stateHash });
        throw new ExecutionRejection("pre_state_hash_mismatch", 409, { currentHash: current.stateHash, currentVersion: current.version });
      }
      if (input.expectedVersion !== current.version) {
        await insertRejection(client, input, "pre_state_version_mismatch", { currentVersion: current.version });
        throw new ExecutionRejection("pre_state_version_mismatch", 409, { currentHash: current.stateHash, currentVersion: current.version });
      }
      if (input.sequence !== current.lastSequence + 1) {
        await insertRejection(client, input, "sequence_gap_or_reorder", { currentSequence: current.lastSequence });
        throw new ExecutionRejection("sequence_gap_or_reorder", 409, { currentSequence: current.lastSequence });
      }

      const nextSnapshot = applyAction(current.snapshot, input);
      const nextHash = hashObject(nextSnapshot);
      const nextVersion = current.version + 1;
      const receiptId = makeId("rcpt");
      const createdAt = new Date().toISOString();
      const commitProof = `${stateKey}:${nextVersion}:${nextHash}`;

      await client.query(
        `UPDATE canonical_state
         SET version = $2, state_hash = $3, last_sequence = $4, snapshot = $5, last_receipt_id = $6, updated_at = NOW()
         WHERE state_key = $1`,
        [stateKey, nextVersion, nextHash, input.sequence, nextSnapshot, receiptId],
      );

      await client.query(
        `INSERT INTO execution_receipts (receipt_id, state_key, idempotency_key, sequence, expected_version, resulting_version, expected_hash, resulting_hash, actor, action, falsifier, committed, commit_proof, details, created_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,TRUE,$12,$13,$14)`,
        [
          receiptId,
          stateKey,
          input.idempotencyKey,
          input.sequence,
          current.version,
          nextVersion,
          current.stateHash,
          nextHash,
          input.actor ?? "ui.operator",
          input.action,
          input.falsifier,
          commitProof,
          input.details ?? {},
          createdAt,
        ],
      );

      const prevLedger = await client.query(`SELECT entry_hash FROM ledger_events ORDER BY ts DESC LIMIT 1`);
      const payloadHash = computeLedgerHash(stableStringify({ details: input.details ?? {}, receiptId, commitProof, expectedHash: current.stateHash, resultingHash: nextHash }));
      const prevHash = prevLedger.rows[0]?.entry_hash ?? null;
      const ledgerId = makeId("led");
      const entryHash = computeLedgerHash(`${ledgerId}|${createdAt}|${input.actor ?? "ui.operator"}|${input.action}|${payloadHash}|${prevHash ?? ""}`);
      await appendLedgerEvent(client, {
        id: ledgerId,
        timestamp: createdAt,
        actor: input.actor ?? "ui.operator",
        action: input.action,
        details: { ...input.details, receiptId, commitProof, canonicalStateKey: stateKey },
        payloadHash,
        prevHash,
        entryHash,
      });

      await client.query("COMMIT");
      return {
        receipt: {
          receiptId,
          stateKey,
          idempotencyKey: input.idempotencyKey,
          sequence: input.sequence,
          expectedVersion: current.version,
          resultingVersion: nextVersion,
          expectedHash: current.stateHash,
          resultingHash: nextHash,
          actor: input.actor ?? "ui.operator",
          action: input.action,
          falsifier: input.falsifier,
          committed: true,
          commitProof,
          details: input.details ?? {},
          createdAt,
        },
        canonicalState: {
          stateKey,
          version: nextVersion,
          stateHash: nextHash,
          lastSequence: input.sequence,
          snapshot: nextSnapshot,
          lastReceiptId: receiptId,
          updatedAt: createdAt,
        },
      };
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    }
  });
}
