CREATE TABLE IF NOT EXISTS controller_runs (
  run_id TEXT PRIMARY KEY,
  state_key TEXT NOT NULL,
  action TEXT NOT NULL,
  actor TEXT NOT NULL,
  receipt_id TEXT NOT NULL,
  artifact_hash TEXT NOT NULL,
  verification JSONB NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_controller_runs_created ON controller_runs (created_at DESC);
