"use client";

import { useState } from "react";

export function AgentCycleRunner() {
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  async function runCycle() {
    setRunning(true);
    setError(null);
    setResult(null);
    try {
      const res = await fetch("/api/agent-run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ falsifier: "n8n.webhook.completed" }),
      });
      const data = await res.json();
      if (!res.ok || data.success === false || data.committed !== true || !data.receipt?.receiptId) {
        setError(data.reason || data.message || "Agent cycle failed before canonical commit.");
      } else {
        setResult(data);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="card section">
      <h2>Run a live agent cycle</h2>
      <p className="muted">This runner only trusts canonical commit. No commit-backed receipt means no cycle happened.</p>
      <button className="primary" onClick={runCycle} disabled={running} style={{ marginBottom: "12px" }}>
        {running ? "Running..." : "Trigger atomic n8n cycle"}
      </button>
      {error && <p style={{ color: "#f66" }}>Error: {error}</p>}
      {result && (
        <pre className="output" style={{ maxHeight: "300px", overflow: "auto" }}>
{JSON.stringify({
  committed: result.committed,
  receiptId: result.receipt?.receiptId,
  stateHash: result.canonicalState?.stateHash,
  version: result.canonicalState?.version,
  verification: result.verification,
  summary: result.summary,
}, null, 2)}
</pre>
      )}
    </div>
  );
}
