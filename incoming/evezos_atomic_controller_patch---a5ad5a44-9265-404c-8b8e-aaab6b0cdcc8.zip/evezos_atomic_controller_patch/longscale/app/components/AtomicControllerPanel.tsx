"use client";

import { useEffect, useState } from "react";

export function AtomicControllerPanel() {
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/proof", { cache: "no-store" })
      .then((res) => res.json())
      .then(setData)
      .catch((err) => setError(err instanceof Error ? err.message : String(err)));
  }, []);

  if (error) return <div className="card section"><h2>Atomic controller</h2><p className="muted">{error}</p></div>;
  if (!data) return <div className="card section"><h2>Atomic controller</h2><p className="muted">Loading controller truth…</p></div>;

  const latestRun = data.controllerRuns?.[0];
  return (
    <div className="card section">
      <h2>Atomic controller</h2>
      <p className="muted">Execution is only real when artifact verification and canonical commit succeed in one path.</p>
      <div className="kv">
        <span>Mode</span><span>{data.runtime?.mode ?? "unknown"}</span>
        <span>Committed runs</span><span>{data.runtime?.controllerRunCount ?? 0}</span>
        <span>Latest run</span><span className="code">{latestRun?.runId ? `${latestRun.runId.slice(0, 24)}…` : "none"}</span>
        <span>Latest receipt</span><span className="code">{latestRun?.receiptId ? `${latestRun.receiptId.slice(0, 24)}…` : "none"}</span>
        <span>Artifact hash</span><span className="code">{latestRun?.artifactHash ? `${latestRun.artifactHash.slice(0, 16)}…` : "none"}</span>
      </div>
    </div>
  );
}
