import { NextRequest, NextResponse } from "next/server";
import { ExecutionRejection } from "../../../../lib/execution";
import { runAtomicControllerAction } from "../../../../lib/runtimeController";
import { withClient } from "../../../../lib/db";

async function persistAcceptedRun(args: {
  runId: string;
  stateKey: string;
  action: string;
  actor: string;
  receiptId: string;
  artifactHash: string;
  verification: Record<string, unknown>;
}) {
  await withClient(async (client) => {
    await client.query(
      `INSERT INTO controller_runs (run_id, state_key, action, actor, receipt_id, artifact_hash, verification)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT (run_id) DO NOTHING`,
      [args.runId, args.stateKey, args.action, args.actor, args.receiptId, args.artifactHash, args.verification],
    );
  });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const action = String(body.action || "controller.execute");
    const actor = String(body.actor || "ui.controller");
    const details = (body.details ?? {}) as Record<string, unknown>;
    const result = await runAtomicControllerAction({
      stateKey: String(body.stateKey || "runtime"),
      action,
      actor,
      falsifier: String(body.falsifier || "controller.verified"),
      idempotencyKey: String(body.idempotencyKey || `controller-${Date.now()}`),
      details,
      deterministic: body.deterministic !== false,
      seed: body.seed ? String(body.seed) : null,
      codeIdentity: String(body.codeIdentity || `api:${action}:v1`),
      trigger: async () => body.result ?? { ok: true, echoedDetails: details },
    });

    await persistAcceptedRun({
      runId: result.receipt.receiptId,
      stateKey: result.receipt.stateKey,
      action,
      actor,
      receiptId: result.receipt.receiptId,
      artifactHash: result.verification.artifactHash,
      verification: result.verification as unknown as Record<string, unknown>,
    });

    return NextResponse.json({
      success: true,
      committed: true,
      receipt: result.receipt,
      artifact: {
        artifactId: result.artifact.artifactId,
        resultHash: result.artifact.resultHash,
        environmentHash: result.artifact.environmentHash,
        durationMs: result.artifact.durationMs,
      },
      verification: result.verification,
      canonicalState: result.canonicalState,
    });
  } catch (error) {
    if (error instanceof ExecutionRejection) {
      return NextResponse.json({ success: false, committed: false, reason: error.reason, context: error.context ?? null }, { status: error.status });
    }
    return NextResponse.json({ success: false, committed: false, message: error instanceof Error ? error.message : "Controller execution failed." }, { status: 500 });
  }
}
