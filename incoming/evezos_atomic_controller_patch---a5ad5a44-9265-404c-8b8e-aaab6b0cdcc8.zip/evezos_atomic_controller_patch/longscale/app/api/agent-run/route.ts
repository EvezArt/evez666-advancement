import { NextRequest, NextResponse } from "next/server";
import { ExecutionRejection } from "../../../lib/execution";
import { runAtomicControllerAction } from "../../../lib/runtimeController";
import { withClient } from "../../../lib/db";

async function persistAcceptedRun(args: {
  runId: string;
  stateKey: string;
  action: string;
  actor: string;
  receiptId: string;
  artifactHash: string;
  verification: Record<string, unknown>;
}) {
  await withClient(async (client) => {
    await client.query(
      `INSERT INTO controller_runs (run_id, state_key, action, actor, receipt_id, artifact_hash, verification)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT (run_id) DO NOTHING`,
      [args.runId, args.stateKey, args.action, args.actor, args.receiptId, args.artifactHash, args.verification],
    );
  });
}

export async function POST(req: NextRequest) {
  const webhookUrl = process.env.N8N_AGENT_RUN_WEBHOOK_URL;
  if (!webhookUrl) {
    return NextResponse.json(
      { success: false, connected: false, message: "n8n agent-run webhook is not configured. Set N8N_AGENT_RUN_WEBHOOK_URL." },
      { status: 503 },
    );
  }

  try {
    const body = await req.json().catch(() => ({}));
    const result = await runAtomicControllerAction({
      stateKey: String(body?.stateKey || "runtime"),
      action: "agent.run.complete",
      actor: "runtime.controller",
      falsifier: String(body?.falsifier || "n8n.webhook.completed"),
      idempotencyKey: String(body?.idempotencyKey || `agent-run-${Date.now()}`),
      details: { request: body ?? {}, targetAction: "agent.run.complete" },
      deterministic: false,
      seed: null,
      codeIdentity: "api:agent-run:webhook:v2-atomic",
      trigger: async () => {
        const upstream = await fetch(webhookUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body ?? {}),
          cache: "no-store",
        });
        const data = await upstream.json().catch(() => ({}));
        if (!upstream.ok) {
          throw new Error(data.message || "Agent cycle failed upstream.");
        }
        return { upstreamStatus: upstream.status, payload: data };
      },
    });

    await persistAcceptedRun({
      runId: result.receipt.receiptId,
      stateKey: result.receipt.stateKey,
      action: "agent.run.complete",
      actor: "runtime.controller",
      receiptId: result.receipt.receiptId,
      artifactHash: result.verification.artifactHash,
      verification: result.verification as unknown as Record<string, unknown>,
    });

    return NextResponse.json({
      success: true,
      connected: true,
      committed: true,
      receipt: result.receipt,
      verification: result.verification,
      canonicalState: result.canonicalState,
      summary: {
        artifactId: result.artifact.artifactId,
        resultHash: result.artifact.resultHash,
        environmentHash: result.artifact.environmentHash,
      },
    }, { status: 200 });
  } catch (error) {
    if (error instanceof ExecutionRejection) {
      return NextResponse.json({ success: false, connected: true, committed: false, reason: error.reason, context: error.context ?? null }, { status: error.status });
    }
    return NextResponse.json(
      { success: false, connected: true, committed: false, message: error instanceof Error ? error.message : "Failed to reach n8n webhook." },
      { status: 502 },
    );
  }
}
