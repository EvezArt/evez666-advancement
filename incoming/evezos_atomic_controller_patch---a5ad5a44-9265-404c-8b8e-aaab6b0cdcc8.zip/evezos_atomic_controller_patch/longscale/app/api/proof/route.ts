import { NextResponse } from "next/server";
import { getCanonicalRegistry } from "../../../lib/canonical";
import { getCanonicalState, getRecentReceipts } from "../../../lib/execution";
import { isBusConnected, getMirroredTasks } from "../../../agents/bus";
import { isLedgerConnected, verifyLedger, getExecutionRejections } from "../../../agents/ledger";
import { getAgentManifest } from "../../../lib/registry";
import { withClient } from "../../../lib/db";

async function getControllerRuns(limit = 10) {
  return withClient(async (client) => {
    const result = await client.query(`SELECT * FROM controller_runs ORDER BY created_at DESC LIMIT $1`, [limit]);
    return result.rows.map((row) => ({
      runId: row.run_id,
      stateKey: row.state_key,
      action: row.action,
      actor: row.actor,
      receiptId: row.receipt_id,
      artifactHash: row.artifact_hash,
      verification: row.verification,
      createdAt: new Date(row.created_at).toISOString(),
    }));
  }).catch(() => []);
}

export async function GET() {
  const manifest = getAgentManifest();
  const registry = getCanonicalRegistry();
  const [busConnected, ledgerConnected, canonicalState, receipts, verification, rejections, mirrored, controllerRuns] = await Promise.all([
    isBusConnected(),
    isLedgerConnected(),
    getCanonicalState().catch(() => null),
    getRecentReceipts(10).catch(() => []),
    verifyLedger(),
    getExecutionRejections(10).catch(() => []),
    getMirroredTasks().catch(() => []),
    getControllerRuns(10),
  ]);

  const latestReceipt = receipts[0] ?? null;
  const latestRun = controllerRuns[0] ?? null;
  const authoritative = Boolean(
    canonicalState &&
    verification.connected &&
    verification.valid &&
    latestReceipt &&
    latestReceipt.receiptId === canonicalState.lastReceiptId &&
    latestRun &&
    latestRun.receiptId === latestReceipt.receiptId,
  );

  return NextResponse.json({
    service: "evezos-proof",
    generatedAt: new Date().toISOString(),
    canonical: registry.canonical,
    nonCanonical: registry.nonCanonical,
    runtime: {
      authoritative,
      mode: "atomic-controller",
      stateKey: canonicalState?.stateKey ?? "runtime",
      version: canonicalState?.version ?? 0,
      stateHash: canonicalState?.stateHash ?? null,
      lastSequence: canonicalState?.lastSequence ?? 0,
      lastReceiptId: canonicalState?.lastReceiptId ?? null,
      updatedAt: canonicalState?.updatedAt ?? null,
      busConnected,
      mirroredTaskCount: mirrored.length,
      controllerRunCount: controllerRuns.length,
      agentCount: manifest.agents.length,
      enabledAgents: manifest.agents.filter((a) => !String(a.status).startsWith("disabled")).length,
    },
    receipts,
    controllerRuns,
    rejections,
    ledgerVerification: verification,
    issues: [
      ...(authoritative ? [] : ["canonical state is not fully authoritative yet"]),
      ...(latestRun ? [] : ["no atomic controller runs have been committed yet"]),
      ...(registry.nonCanonical.length ? ["non-canonical deploy surfaces still exist and must not drive truth"] : []),
      ...(rejections.length ? [`${rejections.length} recent mutations were rejected at ingress`] : []),
    ],
  });
}
