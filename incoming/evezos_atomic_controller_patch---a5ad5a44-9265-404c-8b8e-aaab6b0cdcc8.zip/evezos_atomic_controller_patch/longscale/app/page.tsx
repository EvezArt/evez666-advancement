import { ChatPanel } from "./components/ChatPanel";
import { AgentCycleRunner } from "./components/AgentCycleRunner";
import { LedgerView } from "./components/LedgerView";
import { BusManager } from "./components/BusManager";
import { TreasuryStatus } from "./components/TreasuryStatus";
import { OpportunitiesLive } from "./components/OpportunitiesLive";
import { RegistryStatus } from "./components/RegistryStatus";
import { AuthorityProof } from "./components/AuthorityProof";
import { AtomicControllerPanel } from "./components/AtomicControllerPanel";

export default function Page() {
  return (
    <main className="container">
      <section className="hero">
        <div className="card heroMain">
          <div className="badge">EVEZOS // grounded live-only build</div>
          <h1 className="title">One registry. One mission bus. One ledger. No fake state.</h1>
          <p className="sub">This cutover binds the UI to manifest-owned routes, Redis-backed queue state, and a Postgres-backed hash chain. If an upstream is not wired, the UI says not connected instead of inventing money or outcomes.</p>
          <div className="agentRow">
            <span className="agentTag">registry-aware</span>
            <span className="agentTag">Redis mission bus</span>
            <span className="agentTag">Postgres ledger</span>
            <span className="agentTag">n8n webhook</span>
            <span className="agentTag">live-only</span>
          </div>
        </div>
      </section>

      <section className="grid" id="ops">
        <AuthorityProof />
        <AtomicControllerPanel />
        <TreasuryStatus />
        <RegistryStatus />
        <div className="card section">
          <h2>Live opportunities</h2>
          <OpportunitiesLive />
        </div>
        <div className="card section">
          <h2>Agent terminal</h2>
          <p className="muted">This terminal only works when a real provider proxy is configured.</p>
          <ChatPanel />
        </div>
        <AgentCycleRunner />
        <LedgerView />
        <BusManager />
      </section>
    </main>
  );
}
