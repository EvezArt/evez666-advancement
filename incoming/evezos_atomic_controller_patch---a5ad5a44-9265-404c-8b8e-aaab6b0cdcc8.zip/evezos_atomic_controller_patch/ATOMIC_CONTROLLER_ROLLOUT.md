# Atomic Controller Rollout

This patch upgrades the runtime from step-wise execution to controller-owned atomic execution.

## What changes
- `runtimeController.ts` becomes the only supported path for long-running execution results to become canonical state.
- `agent-run` stops returning raw upstream payloads as truth and only returns commit-backed results.
- `/api/proof` now reports committed controller runs.
- `controller_runs` records only accepted executions.

## Required cutover
1. Apply `migrations/002_atomic_controller.sql`.
2. Deploy route overlays.
3. Repoint board actions to controller-backed routes only.
4. Treat any surface not carrying `committed: true` + receipt as non-authoritative.

## What this does not solve by itself
- external worker retries outside the runtime
- infra-level DB role isolation
- non-canonical deploy rails still serving traffic
