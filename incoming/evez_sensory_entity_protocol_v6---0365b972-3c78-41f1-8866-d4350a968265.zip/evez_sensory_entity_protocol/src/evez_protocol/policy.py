from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from .profiles import load_profiles
from .storage import TraceStore


@dataclass(slots=True)
class PolicyPromotionResult:
    profile_name: str
    previous_threshold: float
    applied_threshold: float
    source: str
    reason: str
    actor: str
    applied_at: str
    profiles_path: str


class PolicyRegistry:
    def __init__(self, profiles_path: str | Path, store: TraceStore | None = None) -> None:
        self.profiles_path = Path(profiles_path)
        self.store = store

    def load(self) -> dict[str, dict[str, Any]]:
        return load_profiles(self.profiles_path)

    def export_bundle(self, limit: int = 10) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "generated_at": datetime.now(UTC).isoformat(),
            "profiles_path": str(self.profiles_path),
            "profiles": self.load(),
        }
        if self.store is not None:
            payload["latest_calibrations"] = self.store.list_calibrations(limit=limit)
            payload["recent_profile_revisions"] = self.store.list_profile_revisions(limit=limit)
        return payload

    def promote_threshold(
        self,
        *,
        profile_name: str,
        threshold: float,
        source: str,
        reason: str,
        actor: str = "system",
    ) -> PolicyPromotionResult:
        profiles = self.load()
        if profile_name not in profiles:
            raise KeyError(f"Unknown profile: {profile_name}")
        profile = profiles[profile_name]
        previous = float(profile.get("action_threshold", 0.72))
        applied = round(float(threshold), 6)
        profile["action_threshold"] = applied
        profile.setdefault("policy_metadata", {})
        profile["policy_metadata"].update(
            {
                "last_promoted_at": datetime.now(UTC).isoformat(),
                "last_promotion_source": source,
                "last_promotion_reason": reason,
                "last_promotion_actor": actor,
            }
        )
        self._write_profiles(profiles)
        result = PolicyPromotionResult(
            profile_name=profile_name,
            previous_threshold=previous,
            applied_threshold=applied,
            source=source,
            reason=reason,
            actor=actor,
            applied_at=datetime.now(UTC).isoformat(),
            profiles_path=str(self.profiles_path),
        )
        if self.store is not None:
            self.store.write_profile_revision(result)
        return result

    def promote_latest_calibration(
        self,
        *,
        profile_name: str,
        calibration_id: int | None = None,
        reason: str,
        actor: str = "system",
    ) -> PolicyPromotionResult:
        if self.store is None:
            raise RuntimeError("A TraceStore is required to promote from calibrations")
        calibration = self.store.get_latest_calibration(profile_name=profile_name, calibration_id=calibration_id)
        if not calibration:
            raise LookupError(f"No calibration found for profile: {profile_name}")
        source = f"calibration:{calibration['id']}"
        return self.promote_threshold(
            profile_name=profile_name,
            threshold=float(calibration["recommended_threshold"]),
            source=source,
            reason=reason,
            actor=actor,
        )

    def _write_profiles(self, profiles: dict[str, dict[str, Any]]) -> None:
        self.profiles_path.parent.mkdir(parents=True, exist_ok=True)
        self.profiles_path.write_text(json.dumps(profiles, indent=2, sort_keys=True) + "\n", encoding="utf-8")



def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Promote a calibrated threshold into the active profiles file")
    parser.add_argument("--profiles-path", required=True, help="Path to entity_profiles.json")
    parser.add_argument("--db-path", required=True, help="Path to SQLite DB used for calibrations/history")
    parser.add_argument("--profile", required=True, help="Profile to update")
    parser.add_argument("--reason", required=True, help="Why this promotion is being applied")
    parser.add_argument("--actor", default="cli", help="Actor name recorded in policy history")
    parser.add_argument("--threshold", type=float, help="Explicit threshold to apply")
    parser.add_argument("--calibration-id", type=int, help="Specific calibration id to promote")
    return parser



def main() -> None:
    args = build_parser().parse_args()
    store = TraceStore(args.db_path)
    registry = PolicyRegistry(args.profiles_path, store=store)
    if args.threshold is not None:
        result = registry.promote_threshold(
            profile_name=args.profile,
            threshold=args.threshold,
            source="manual",
            reason=args.reason,
            actor=args.actor,
        )
    else:
        result = registry.promote_latest_calibration(
            profile_name=args.profile,
            calibration_id=args.calibration_id,
            reason=args.reason,
            actor=args.actor,
        )
    print(json.dumps(asdict(result), indent=2))


if __name__ == "__main__":
    main()
