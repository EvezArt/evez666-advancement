from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class Settings:
    db_path: str = os.getenv("EVEZ_DB_PATH", str(Path("data") / "evez_protocol.db"))
    output_dir: str = os.getenv("EVEZ_OUTPUT_DIR", "output/service")
    daemon_batch_size: int = int(os.getenv("EVEZ_DAEMON_BATCH_SIZE", "10"))
    daemon_interval_seconds: float = float(os.getenv("EVEZ_DAEMON_INTERVAL_SECONDS", "60"))
    daemon_seed: int = int(os.getenv("EVEZ_DAEMON_SEED", "42"))
    api_key: str = os.getenv("EVEZ_API_KEY", "")
    profile_name: str = os.getenv("EVEZ_PROFILE", "baseline")
    profiles_path: str = os.getenv("EVEZ_PROFILES_PATH", str(Path("config") / "entity_profiles.json"))
    benchmark_iterations: int = int(os.getenv("EVEZ_BENCHMARK_ITERATIONS", "150"))


settings = Settings()
