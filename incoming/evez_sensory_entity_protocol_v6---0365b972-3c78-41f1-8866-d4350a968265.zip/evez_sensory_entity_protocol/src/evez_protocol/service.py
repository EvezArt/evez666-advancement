from __future__ import annotations

import html
from dataclasses import asdict
from datetime import UTC, datetime
from typing import Annotated, Any, Literal

from fastapi import Depends, FastAPI, Header, HTTPException, status
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

from .adapters import adapt_signal, list_adapters
from .calibration import ThresholdCalibrator, calibration_to_dict
from .config import settings
from .demo import build_entity
from .models import Commitment, DecisionTrace
from .policy import PolicyRegistry
from .profiles import load_profiles
from .runner import BenchmarkRunner, IterationRunner
from .storage import TraceStore


app = FastAPI(title="EVEZ Sensory Entity Protocol", version="0.6.0")
store = TraceStore(settings.db_path)
policy_registry = PolicyRegistry(settings.profiles_path, store=store)


class SignalPayload(BaseModel):
    event_id: str | None = None
    source: str = "api"
    goal: str = "max_profit"
    price: float = 100.0
    trend_strength: float = Field(default=0.5, ge=0.0, le=1.0)
    risk_score: float = Field(default=0.5, ge=0.0, le=1.0)
    liquidity: float = Field(default=0.5, ge=0.0, le=1.0)
    profile_name: str | None = None


class AdaptedIngestPayload(BaseModel):
    adapter_name: str = "generic"
    raw: dict[str, Any]
    profile_name: str | None = None
    goal: str | None = None
    event_id: str | None = None


class BatchPayload(BaseModel):
    iterations: int = Field(default=25, ge=1, le=10000)
    seed: int = 42
    outdir: str | None = None
    profile_name: str = Field(default=settings.profile_name)


class BenchmarkPayload(BaseModel):
    iterations: int = Field(default=settings.benchmark_iterations, ge=5, le=10000)
    seed: int = 42
    outdir: str | None = None
    profiles: list[str] | None = None


class FeedbackPayload(BaseModel):
    event_id: str
    run_id: str | None = None
    profile_name: str | None = None
    realized_return: float
    realized_risk: float = Field(ge=0.0)
    operator_verdict: Literal["good", "neutral", "bad"] = "neutral"
    notes: str = ""


class CalibrationPayload(BaseModel):
    profile_name: str = Field(default=settings.profile_name)
    limit: int = Field(default=5000, ge=5, le=50000)


class PolicyPromotionPayload(BaseModel):
    profile_name: str = Field(default=settings.profile_name)
    reason: str = Field(default="Apply latest calibration to active policy")
    actor: str = Field(default="api")
    calibration_id: int | None = None
    threshold: float | None = Field(default=None, ge=0.0, le=1.0)



def require_api_key(x_api_key: Annotated[str | None, Header()] = None) -> None:
    if settings.api_key and x_api_key != settings.api_key:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or missing API key")


def _profiles() -> dict[str, dict[str, Any]]:
    return load_profiles(settings.profiles_path)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "db_path": settings.db_path, "profile": settings.profile_name}


@app.get("/profiles", dependencies=[Depends(require_api_key)])
def profiles() -> dict[str, Any]:
    payload = _profiles()
    return {"default": settings.profile_name, "profiles": payload}


@app.get("/adapters", dependencies=[Depends(require_api_key)])
def adapters() -> dict[str, Any]:
    return {"adapters": list_adapters()}


@app.post("/ingest", dependencies=[Depends(require_api_key)])
def ingest(payload: SignalPayload) -> dict[str, Any]:
    event_id = payload.event_id or f"api-{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}"
    profile_name = payload.profile_name or settings.profile_name
    entity = build_entity(profile_name)
    trace = entity.ingest({**payload.model_dump(exclude={"profile_name"}), "event_id": event_id})
    run_id = f"single-{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}"
    store.write_trace(run_id=run_id, iteration=None, trace=trace, profile_name=profile_name)
    return _serialize_trace(trace, run_id=run_id, profile_name=profile_name)


@app.post("/ingest/adapted", dependencies=[Depends(require_api_key)])
def ingest_adapted(payload: AdaptedIngestPayload) -> dict[str, Any]:
    profile_name = payload.profile_name or settings.profile_name
    normalized = adapt_signal(payload.adapter_name, payload.raw)
    if payload.goal:
        normalized["goal"] = payload.goal
    if payload.event_id:
        normalized["event_id"] = payload.event_id
    entity = build_entity(profile_name)
    trace = entity.ingest(normalized)
    run_id = f"single-{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}"
    store.write_trace(run_id=run_id, iteration=None, trace=trace, profile_name=profile_name)
    response = _serialize_trace(trace, run_id=run_id, profile_name=profile_name)
    response["normalized_signal"] = normalized
    return response


@app.post("/batch", dependencies=[Depends(require_api_key)])
def batch(payload: BatchPayload) -> dict[str, Any]:
    runner = IterationRunner(seed=payload.seed, profile_name=payload.profile_name)
    summary = runner.run(
        iterations=payload.iterations,
        outdir=payload.outdir or settings.output_dir,
        trace_callback=lambda run_id, idx, trace: store.write_trace(
            run_id=run_id, iteration=idx, trace=trace, profile_name=payload.profile_name
        ),
    )
    store.write_summary(summary)
    return asdict(summary)


@app.post("/benchmark", dependencies=[Depends(require_api_key)])
def benchmark(payload: BenchmarkPayload) -> dict[str, Any]:
    available = list(_profiles().keys())
    selected = payload.profiles or available
    result = BenchmarkRunner(seed=payload.seed).run(
        profiles=selected,
        iterations=payload.iterations,
        outdir=payload.outdir or f"{settings.output_dir}/benchmark",
    )
    store.write_benchmark(result)
    return asdict(result)


@app.post("/feedback", dependencies=[Depends(require_api_key)])
def feedback(payload: FeedbackPayload) -> dict[str, Any]:
    store.write_feedback(
        event_id=payload.event_id,
        run_id=payload.run_id,
        profile_name=payload.profile_name,
        realized_return=payload.realized_return,
        realized_risk=payload.realized_risk,
        operator_verdict=payload.operator_verdict,
        notes=payload.notes,
    )
    return {"status": "recorded", **payload.model_dump()}


@app.post("/calibrate", dependencies=[Depends(require_api_key)])
def calibrate(payload: CalibrationPayload) -> dict[str, Any]:
    profiles_map = _profiles()
    if payload.profile_name not in profiles_map:
        raise HTTPException(status_code=404, detail="Unknown profile")
    baseline_threshold = float(profiles_map[payload.profile_name].get("action_threshold", 0.72))
    samples = store.fetch_feedback_samples(profile_name=payload.profile_name, limit=payload.limit)
    if not samples:
        raise HTTPException(status_code=400, detail="No feedback samples available for calibration")
    result = ThresholdCalibrator(baseline_threshold=baseline_threshold).calibrate(payload.profile_name, samples)
    store.write_calibration(result)
    return calibration_to_dict(result)




@app.get("/events/{event_id}/explain", dependencies=[Depends(require_api_key)])
def explain_event(event_id: str, run_id: str | None = None) -> dict[str, Any]:
    trace = store.get_full_trace(event_id=event_id, run_id=run_id)
    if not trace:
        raise HTTPException(status_code=404, detail="Unknown event")
    return {
        "trace": trace,
        "feedback": store.list_feedback_for_event(event_id=event_id, limit=20),
        "latest_calibration": store.get_latest_calibration(profile_name=trace.get("profile_name", settings.profile_name)),
    }


@app.get("/policy/export", dependencies=[Depends(require_api_key)])
def export_policy_bundle(limit: int = 10) -> dict[str, Any]:
    return policy_registry.export_bundle(limit=limit)


@app.post("/policy/promote", dependencies=[Depends(require_api_key)])
def promote_policy(payload: PolicyPromotionPayload) -> dict[str, Any]:
    if payload.threshold is not None:
        result = policy_registry.promote_threshold(
            profile_name=payload.profile_name,
            threshold=payload.threshold,
            source="manual",
            reason=payload.reason,
            actor=payload.actor,
        )
    else:
        try:
            result = policy_registry.promote_latest_calibration(
                profile_name=payload.profile_name,
                calibration_id=payload.calibration_id,
                reason=payload.reason,
                actor=payload.actor,
            )
        except LookupError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
    return asdict(result)


@app.get("/profile-revisions", dependencies=[Depends(require_api_key)])
def profile_revisions(limit: int = 20) -> list[dict[str, Any]]:
    return store.list_profile_revisions(limit=limit)


@app.get("/runs", dependencies=[Depends(require_api_key)])
def runs(limit: int = 20) -> list[dict[str, Any]]:
    return store.list_runs(limit=limit)


@app.get("/traces", dependencies=[Depends(require_api_key)])
def traces(limit: int = 50) -> list[dict[str, Any]]:
    return store.list_traces(limit=limit)


@app.get("/benchmarks", dependencies=[Depends(require_api_key)])
def benchmarks(limit: int = 20) -> list[dict[str, Any]]:
    return store.list_benchmarks(limit=limit)


@app.get("/feedback", dependencies=[Depends(require_api_key)])
def feedback_list(limit: int = 50) -> list[dict[str, Any]]:
    return store.list_feedback(limit=limit)


@app.get("/calibrations", dependencies=[Depends(require_api_key)])
def calibrations(limit: int = 20) -> list[dict[str, Any]]:
    return store.list_calibrations(limit=limit)


@app.get("/commitment-stats", dependencies=[Depends(require_api_key)])
def commitment_stats(limit: int = 200) -> dict[str, Any]:
    rows = store.list_traces(limit=limit)
    counts: dict[str, int] = {name.value: 0 for name in Commitment}
    for row in rows:
        counts[row["commitment"]] = counts.get(row["commitment"], 0) + 1
    total = sum(counts.values()) or 1
    rates = {key: round(value / total, 4) for key, value in counts.items()}
    return {"counts": counts, "rates": rates, "sample_size": total}


@app.get("/dashboard", response_class=HTMLResponse, dependencies=[Depends(require_api_key)])
def dashboard() -> str:
    runs = store.list_runs(limit=8)
    traces = store.list_traces(limit=12)
    benchmarks = store.list_benchmarks(limit=5)
    calibrations = store.list_calibrations(limit=5)
    revisions = store.list_profile_revisions(limit=5)
    stats = commitment_stats(limit=200)

    run_rows = "".join(
        f"<tr><td>{html.escape(row['run_id'])}</td><td>{html.escape(row.get('profile_name', 'baseline'))}</td><td>{row['iterations']}</td><td>{row['act_rate']}</td><td>{row['discard_rate']}</td></tr>"
        for row in runs
    ) or "<tr><td colspan='5'>No runs yet</td></tr>"
    trace_rows = "".join(
        f"<tr><td>{html.escape(row['event_id'])}</td><td>{html.escape(row['commitment'])}</td><td>{row['confidence']}</td><td>{html.escape(row['goal'])}</td><td>{html.escape(row['summary'])}</td></tr>"
        for row in traces
    ) or "<tr><td colspan='5'>No traces yet</td></tr>"
    benchmark_rows = "".join(
        f"<tr><td>{row['id']}</td><td>{html.escape(row['generated_at'])}</td><td>{html.escape(row['profiles_json'])}</td><td>{row['iterations_per_profile']}</td></tr>"
        for row in benchmarks
    ) or "<tr><td colspan='4'>No benchmarks yet</td></tr>"
    calibration_rows = "".join(
        f"<tr><td>{row['id']}</td><td>{html.escape(row['profile_name'])}</td><td>{row['baseline_threshold']}</td><td>{row['recommended_threshold']}</td><td>{row['sample_size']}</td></tr>"
        for row in calibrations
    ) or "<tr><td colspan='5'>No calibrations yet</td></tr>"
    revision_rows = "".join(
        f"<tr><td>{row['id']}</td><td>{html.escape(row['profile_name'])}</td><td>{row['previous_threshold']}</td><td>{row['applied_threshold']}</td><td>{html.escape(row['source'])}</td></tr>"
        for row in revisions
    ) or "<tr><td colspan='5'>No profile revisions yet</td></tr>"

    return f"""
    <!doctype html>
    <html>
      <head>
        <title>EVEZ Protocol Dashboard</title>
        <style>
          body {{ font-family: Arial, sans-serif; margin: 2rem; background: #0d1117; color: #e6edf3; }}
          h1, h2 {{ margin-bottom: 0.4rem; }}
          .cards {{ display: grid; grid-template-columns: repeat(4, minmax(160px, 1fr)); gap: 1rem; margin: 1rem 0 2rem; }}
          .card {{ background: #161b22; padding: 1rem; border-radius: 10px; border: 1px solid #30363d; }}
          table {{ width: 100%; border-collapse: collapse; margin-bottom: 2rem; }}
          th, td {{ border: 1px solid #30363d; padding: 0.6rem; text-align: left; vertical-align: top; }}
          th {{ background: #161b22; }}
          code {{ background: #161b22; padding: 0.15rem 0.35rem; border-radius: 4px; }}
        </style>
      </head>
      <body>
        <h1>EVEZ Sensory Entity Dashboard</h1>
        <p>Default profile: <code>{html.escape(settings.profile_name)}</code></p>
        <div class="cards">
          <div class="card"><strong>ACT</strong><div>{stats['counts'].get('ACT', 0)}</div></div>
          <div class="card"><strong>HOLD</strong><div>{stats['counts'].get('HOLD', 0)}</div></div>
          <div class="card"><strong>TEST</strong><div>{stats['counts'].get('TEST', 0)}</div></div>
          <div class="card"><strong>DISCARD</strong><div>{stats['counts'].get('DISCARD', 0)}</div></div>
        </div>
        <h2>Recent Runs</h2>
        <table><thead><tr><th>Run ID</th><th>Profile</th><th>Iterations</th><th>ACT rate</th><th>DISCARD rate</th></tr></thead><tbody>{run_rows}</tbody></table>
        <h2>Recent Traces</h2>
        <table><thead><tr><th>Event</th><th>Commitment</th><th>Confidence</th><th>Goal</th><th>Summary</th></tr></thead><tbody>{trace_rows}</tbody></table>
        <h2>Recent Benchmarks</h2>
        <table><thead><tr><th>ID</th><th>Generated At</th><th>Profiles</th><th>Iterations/Profile</th></tr></thead><tbody>{benchmark_rows}</tbody></table>
        <h2>Recent Calibrations</h2>
        <table><thead><tr><th>ID</th><th>Profile</th><th>Baseline Threshold</th><th>Recommended Threshold</th><th>Samples</th></tr></thead><tbody>{calibration_rows}</tbody></table>
        <h2>Recent Policy Promotions</h2>
        <table><thead><tr><th>ID</th><th>Profile</th><th>Previous Threshold</th><th>Applied Threshold</th><th>Source</th></tr></thead><tbody>{revision_rows}</tbody></table>
      </body>
    </html>
    """


def _serialize_trace(trace: DecisionTrace, run_id: str, profile_name: str) -> dict[str, Any]:
    payload = asdict(trace)
    payload["run_id"] = run_id
    payload["profile_name"] = profile_name
    return payload
