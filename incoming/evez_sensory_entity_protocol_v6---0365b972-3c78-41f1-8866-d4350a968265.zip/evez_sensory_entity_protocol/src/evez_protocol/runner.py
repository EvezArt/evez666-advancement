from __future__ import annotations

import argparse
import json
import random
import time
from collections import Counter
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable, Iterable

from .demo import build_entity
from .models import Commitment, DecisionTrace


@dataclass(slots=True)
class RunSummary:
    run_id: str
    profile_name: str
    iterations: int
    commitment_counts: dict[str, int]
    discarded_shift_counts: dict[str, int]
    average_confidence: float
    act_rate: float
    discard_rate: float
    started_at: str
    finished_at: str
    duration_seconds: float
    outdir: str


class SignalFactory:
    """Produces varied but bounded signals for repeated protocol evaluation."""

    def __init__(self, seed: int = 42) -> None:
        self._rng = random.Random(seed)

    def build(self, index: int) -> dict[str, Any]:
        profile = index % 6
        if profile in {0, 1}:
            trend = self._bounded(self._rng.uniform(0.82, 1.00))
            liquidity = self._bounded(self._rng.uniform(0.72, 1.00))
            risk = self._bounded(self._rng.uniform(0.03, 0.18))
            goal = "max_profit"
        elif profile in {2, 3}:
            trend = self._bounded(self._rng.uniform(0.58, 0.84))
            liquidity = self._bounded(self._rng.uniform(0.42, 0.82))
            risk = self._bounded(self._rng.uniform(0.18, 0.52))
            goal = ["max_profit", "neutrality"][index % 2]
        else:
            trend = self._bounded(self._rng.uniform(0.20, 0.62))
            liquidity = self._bounded(self._rng.uniform(0.18, 0.55))
            risk = self._bounded(self._rng.uniform(0.45, 0.92))
            goal = ["max_safety", "neutrality"][index % 2]
        price = round(80 + self._rng.uniform(-10, 70), 2)

        return {
            "event_id": f"iter-{index:05d}",
            "source": "batch-runner",
            "goal": goal,
            "price": price,
            "trend_strength": trend,
            "risk_score": risk,
            "liquidity": liquidity,
        }

    @staticmethod
    def _bounded(value: float) -> float:
        return max(0.0, min(1.0, value))


class IterationRunner:
    def __init__(self, seed: int = 42, profile_name: str = "baseline") -> None:
        self.profile_name = profile_name
        self.entity = build_entity(profile_name)
        self.factory = SignalFactory(seed=seed)

    def run(
        self,
        iterations: int,
        outdir: str | Path,
        sleep_seconds: float = 0.0,
        trace_callback: Callable[[str, int, DecisionTrace], None] | None = None,
    ) -> RunSummary:
        signals = [self.factory.build(idx) for idx in range(iterations)]
        return self.run_signals(signals=signals, outdir=outdir, sleep_seconds=sleep_seconds, trace_callback=trace_callback)

    def run_signals(
        self,
        signals: Iterable[dict[str, Any]],
        outdir: str | Path,
        sleep_seconds: float = 0.0,
        trace_callback: Callable[[str, int, DecisionTrace], None] | None = None,
    ) -> RunSummary:
        signal_list = list(signals)
        outpath = Path(outdir)
        outpath.mkdir(parents=True, exist_ok=True)
        run_id = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
        jsonl_path = outpath / f"decision_traces_{run_id}.jsonl"
        started = time.perf_counter()
        started_at = datetime.now(UTC).isoformat()

        commitment_counts: Counter[str] = Counter()
        discarded_shift_counts: Counter[str] = Counter()
        confidence_total = 0.0

        with jsonl_path.open("w", encoding="utf-8") as handle:
            for idx, signal in enumerate(signal_list):
                trace = self.entity.ingest(signal)
                confidence_total += trace.event.confidence
                commitment_counts[trace.commitment.value] += 1
                for shift in trace.discarded_by:
                    discarded_shift_counts[shift.value] += 1
                record = self._trace_record(idx, signal, trace)
                handle.write(json.dumps(record, separators=(",", ":")) + "\n")
                if trace_callback is not None:
                    trace_callback(run_id, idx, trace)
                if sleep_seconds > 0:
                    time.sleep(sleep_seconds)

        finished = time.perf_counter()
        finished_at = datetime.now(UTC).isoformat()
        duration = round(finished - started, 3)
        iterations = len(signal_list)

        summary = RunSummary(
            run_id=run_id,
            profile_name=self.profile_name,
            iterations=iterations,
            commitment_counts=dict(commitment_counts),
            discarded_shift_counts=dict(discarded_shift_counts),
            average_confidence=round(confidence_total / iterations, 4) if iterations else 0.0,
            act_rate=round(commitment_counts.get(Commitment.ACT.value, 0) / iterations, 4) if iterations else 0.0,
            discard_rate=round(commitment_counts.get(Commitment.DISCARD.value, 0) / iterations, 4) if iterations else 0.0,
            started_at=started_at,
            finished_at=finished_at,
            duration_seconds=duration,
            outdir=str(outpath.resolve()),
        )

        self._write_summary(outpath, summary)
        return summary

    @staticmethod
    def _trace_record(index: int, signal: dict[str, Any], trace: DecisionTrace) -> dict[str, Any]:
        payload = asdict(trace)
        payload["iteration"] = index
        payload["signal"] = signal
        return payload

    @staticmethod
    def _write_summary(outpath: Path, summary: RunSummary) -> None:
        summary_json = outpath / f"run_summary_{summary.run_id}.json"
        summary_md = outpath / f"run_summary_{summary.run_id}.md"
        summary_json.write_text(json.dumps(asdict(summary), indent=2), encoding="utf-8")
        lines = [
            f"# Run Summary {summary.run_id}",
            "",
            f"- Profile: {summary.profile_name}",
            f"- Iterations: {summary.iterations}",
            f"- Started: {summary.started_at}",
            f"- Finished: {summary.finished_at}",
            f"- Duration (s): {summary.duration_seconds}",
            f"- Average confidence: {summary.average_confidence}",
            f"- ACT rate: {summary.act_rate}",
            f"- DISCARD rate: {summary.discard_rate}",
            "",
            "## Commitment counts",
            "",
        ]
        for key, value in sorted(summary.commitment_counts.items()):
            lines.append(f"- {key}: {value}")
        lines.extend(["", "## Discarded-by counts", ""])
        if summary.discarded_shift_counts:
            for key, value in sorted(summary.discarded_shift_counts.items()):
                lines.append(f"- {key}: {value}")
        else:
            lines.append("- none")
        summary_md.write_text("\n".join(lines) + "\n", encoding="utf-8")


@dataclass(slots=True)
class BenchmarkResult:
    profiles: list[str]
    iterations_per_profile: int
    summaries: list[RunSummary]
    generated_at: str


class BenchmarkRunner:
    def __init__(self, seed: int = 42) -> None:
        self.seed = seed

    def run(self, profiles: list[str], iterations: int, outdir: str | Path) -> BenchmarkResult:
        results: list[RunSummary] = []
        base_out = Path(outdir)
        base_out.mkdir(parents=True, exist_ok=True)
        for offset, profile_name in enumerate(profiles):
            runner = IterationRunner(seed=self.seed + offset, profile_name=profile_name)
            profile_out = base_out / profile_name
            results.append(runner.run(iterations=iterations, outdir=profile_out))
        return BenchmarkResult(
            profiles=profiles,
            iterations_per_profile=iterations,
            summaries=results,
            generated_at=datetime.now(UTC).isoformat(),
        )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run repeated Sensory Entity protocol evaluations")
    parser.add_argument("--iterations", type=int, default=700, help="Number of iterations to execute")
    parser.add_argument("--outdir", type=str, default="output/run", help="Directory to write logs and summaries")
    parser.add_argument("--seed", type=int, default=42, help="Deterministic random seed")
    parser.add_argument("--sleep-seconds", type=float, default=0.0, help="Optional delay between iterations")
    parser.add_argument("--profile", type=str, default="baseline", help="Profile to execute")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    runner = IterationRunner(seed=args.seed, profile_name=args.profile)
    summary = runner.run(iterations=args.iterations, outdir=args.outdir, sleep_seconds=args.sleep_seconds)
    print(json.dumps(asdict(summary), indent=2))


if __name__ == "__main__":
    main()
