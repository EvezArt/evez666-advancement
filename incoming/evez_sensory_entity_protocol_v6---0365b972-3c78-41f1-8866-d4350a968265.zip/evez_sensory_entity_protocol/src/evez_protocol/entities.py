from __future__ import annotations

from dataclasses import asdict
from typing import Any, Callable

from .battery import InvarianceBattery
from .models import DecisionTrace

Generator = Callable[[dict[str, Any]], Any]


class SensoryEntity:
    def __init__(self, entity_id: str, generator: Generator, battery: InvarianceBattery) -> None:
        self.entity_id = entity_id
        self.generator = generator
        self.battery = battery

    def ingest(self, signal: dict[str, Any]) -> DecisionTrace:
        event = self.generator(signal)
        return self.battery.run(event)

    @staticmethod
    def as_dict(trace: DecisionTrace) -> dict[str, Any]:
        return asdict(trace)
