from __future__ import annotations

import json
import sqlite3
from dataclasses import asdict
from pathlib import Path
from typing import Any

from .calibration import CalibrationResult
from .models import DecisionTrace
from .runner import BenchmarkResult, RunSummary


SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    run_id TEXT PRIMARY KEY,
    profile_name TEXT NOT NULL DEFAULT 'baseline',
    started_at TEXT NOT NULL,
    finished_at TEXT NOT NULL,
    iterations INTEGER NOT NULL,
    duration_seconds REAL NOT NULL,
    average_confidence REAL NOT NULL,
    act_rate REAL NOT NULL,
    discard_rate REAL NOT NULL,
    commitment_counts_json TEXT NOT NULL,
    discarded_shift_counts_json TEXT NOT NULL,
    outdir TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS traces (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    iteration INTEGER,
    profile_name TEXT NOT NULL DEFAULT 'baseline',
    event_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    commitment TEXT NOT NULL,
    confidence REAL NOT NULL,
    hypothesis TEXT NOT NULL,
    proposed_action TEXT NOT NULL,
    goal TEXT NOT NULL,
    summary TEXT NOT NULL,
    discarded_by_json TEXT NOT NULL,
    refusal_signal_json TEXT NOT NULL,
    trace_json TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(run_id) REFERENCES runs(run_id)
);

CREATE TABLE IF NOT EXISTS benchmarks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    generated_at TEXT NOT NULL,
    profiles_json TEXT NOT NULL,
    iterations_per_profile INTEGER NOT NULL,
    result_json TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT,
    event_id TEXT NOT NULL,
    profile_name TEXT NOT NULL DEFAULT 'baseline',
    realized_return REAL NOT NULL,
    realized_risk REAL NOT NULL,
    operator_verdict TEXT NOT NULL DEFAULT 'neutral',
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS calibrations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_name TEXT NOT NULL,
    baseline_threshold REAL NOT NULL,
    recommended_threshold REAL NOT NULL,
    sample_size INTEGER NOT NULL,
    generated_at TEXT NOT NULL,
    result_json TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS profile_revisions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_name TEXT NOT NULL,
    previous_threshold REAL NOT NULL,
    applied_threshold REAL NOT NULL,
    source TEXT NOT NULL,
    reason TEXT NOT NULL,
    actor TEXT NOT NULL,
    applied_at TEXT NOT NULL,
    profiles_path TEXT NOT NULL,
    result_json TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_traces_run_id ON traces(run_id);
CREATE INDEX IF NOT EXISTS idx_traces_event_id ON traces(event_id);
CREATE INDEX IF NOT EXISTS idx_traces_commitment ON traces(commitment);
CREATE INDEX IF NOT EXISTS idx_feedback_event_id ON feedback(event_id);
CREATE INDEX IF NOT EXISTS idx_feedback_profile_name ON feedback(profile_name);
CREATE INDEX IF NOT EXISTS idx_calibrations_profile_name ON calibrations(profile_name);
CREATE INDEX IF NOT EXISTS idx_profile_revisions_profile_name ON profile_revisions(profile_name);
"""


class TraceStore:
    def __init__(self, db_path: str | Path) -> None:
        self.db_path = str(db_path)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _initialize(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.executescript(SCHEMA)
            self._ensure_column(conn, "runs", "profile_name", "TEXT NOT NULL DEFAULT 'baseline'")
            self._ensure_column(conn, "traces", "profile_name", "TEXT NOT NULL DEFAULT 'baseline'")
            conn.commit()

    @staticmethod
    def _ensure_column(conn: sqlite3.Connection, table: str, column: str, definition: str) -> None:
        existing = {row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        if column not in existing:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")

    def write_summary(self, summary: RunSummary) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO runs (
                    run_id, profile_name, started_at, finished_at, iterations, duration_seconds,
                    average_confidence, act_rate, discard_rate,
                    commitment_counts_json, discarded_shift_counts_json, outdir
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    summary.run_id,
                    summary.profile_name,
                    summary.started_at,
                    summary.finished_at,
                    summary.iterations,
                    summary.duration_seconds,
                    summary.average_confidence,
                    summary.act_rate,
                    summary.discard_rate,
                    json.dumps(summary.commitment_counts, separators=(",", ":")),
                    json.dumps(summary.discarded_shift_counts, separators=(",", ":")),
                    summary.outdir,
                ),
            )
            conn.commit()

    def write_trace(self, run_id: str, iteration: int | None, trace: DecisionTrace, profile_name: str = "baseline") -> None:
        payload = asdict(trace)
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO traces (
                    run_id, iteration, profile_name, event_id, entity_id, commitment, confidence,
                    hypothesis, proposed_action, goal, summary,
                    discarded_by_json, refusal_signal_json, trace_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    iteration,
                    profile_name,
                    trace.event.event_id,
                    trace.event.entity_id,
                    trace.commitment.value,
                    trace.event.confidence,
                    trace.event.hypothesis,
                    trace.event.proposed_action,
                    trace.event.goal,
                    trace.summary,
                    json.dumps([shift.value for shift in trace.discarded_by], separators=(",", ":")),
                    json.dumps(trace.refusal_signal, separators=(",", ":")),
                    json.dumps(payload, separators=(",", ":")),
                ),
            )
            conn.commit()

    def write_benchmark(self, result: BenchmarkResult) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO benchmarks (
                    generated_at, profiles_json, iterations_per_profile, result_json
                ) VALUES (?, ?, ?, ?)
                """,
                (
                    result.generated_at,
                    json.dumps(result.profiles, separators=(",", ":")),
                    result.iterations_per_profile,
                    json.dumps(asdict(result), separators=(",", ":")),
                ),
            )
            conn.commit()

    def write_feedback(
        self,
        *,
        event_id: str,
        realized_return: float,
        realized_risk: float,
        operator_verdict: str = "neutral",
        notes: str = "",
        run_id: str | None = None,
        profile_name: str | None = None,
    ) -> None:
        inferred = self.get_trace_context(event_id=event_id, run_id=run_id)
        final_profile = profile_name or inferred.get("profile_name", "baseline")
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO feedback (
                    run_id, event_id, profile_name, realized_return, realized_risk, operator_verdict, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id or inferred.get("run_id"),
                    event_id,
                    final_profile,
                    realized_return,
                    realized_risk,
                    operator_verdict,
                    notes,
                ),
            )
            conn.commit()

    def write_calibration(self, result: CalibrationResult) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO calibrations (
                    profile_name, baseline_threshold, recommended_threshold, sample_size, generated_at, result_json
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    result.profile_name,
                    result.baseline_threshold,
                    result.recommended_threshold,
                    result.sample_size,
                    result.generated_at,
                    json.dumps(asdict(result), separators=(",", ":")),
                ),
            )
            conn.commit()

    def write_profile_revision(self, result: Any) -> None:
        payload = asdict(result)
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO profile_revisions (
                    profile_name, previous_threshold, applied_threshold, source,
                    reason, actor, applied_at, profiles_path, result_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    payload["profile_name"],
                    payload["previous_threshold"],
                    payload["applied_threshold"],
                    payload["source"],
                    payload["reason"],
                    payload["actor"],
                    payload["applied_at"],
                    payload["profiles_path"],
                    json.dumps(payload, separators=(",", ":")),
                ),
            )
            conn.commit()

    def list_runs(self, limit: int = 20) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT run_id, profile_name, started_at, finished_at, iterations, duration_seconds,
                       average_confidence, act_rate, discard_rate,
                       commitment_counts_json, discarded_shift_counts_json, outdir
                FROM runs
                ORDER BY finished_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def list_traces(self, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT id, run_id, iteration, profile_name, event_id, entity_id, commitment,
                       confidence, hypothesis, proposed_action, goal, summary, created_at
                FROM traces
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def list_benchmarks(self, limit: int = 20) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT id, generated_at, profiles_json, iterations_per_profile, created_at
                FROM benchmarks
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def list_feedback(self, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT id, run_id, event_id, profile_name, realized_return, realized_risk,
                       operator_verdict, notes, created_at
                FROM feedback
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def list_feedback_for_event(self, event_id: str, limit: int = 20) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT id, run_id, event_id, profile_name, realized_return, realized_risk,
                       operator_verdict, notes, created_at
                FROM feedback
                WHERE event_id = ?
                ORDER BY id DESC
                LIMIT ?
                """,
                (event_id, limit),
            ).fetchall()
        return [dict(row) for row in rows]

    def list_calibrations(self, limit: int = 20) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT id, profile_name, baseline_threshold, recommended_threshold,
                       sample_size, generated_at, created_at
                FROM calibrations
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def list_profile_revisions(self, limit: int = 20) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT id, profile_name, previous_threshold, applied_threshold,
                       source, reason, actor, applied_at, profiles_path, created_at
                FROM profile_revisions
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def get_trace_context(self, event_id: str, run_id: str | None = None) -> dict[str, Any]:
        query = (
            "SELECT run_id, profile_name, confidence, discarded_by_json, trace_json "
            "FROM traces WHERE event_id = ? "
        )
        params: list[Any] = [event_id]
        if run_id is not None:
            query += "AND run_id = ? "
            params.append(run_id)
        query += "ORDER BY id DESC LIMIT 1"
        with self._connect() as conn:
            row = conn.execute(query, params).fetchone()
        return dict(row) if row else {}

    def get_full_trace(self, event_id: str, run_id: str | None = None) -> dict[str, Any]:
        query = (
            "SELECT id, run_id, iteration, profile_name, event_id, entity_id, commitment, confidence, "
            "hypothesis, proposed_action, goal, summary, discarded_by_json, refusal_signal_json, trace_json, created_at "
            "FROM traces WHERE event_id = ? "
        )
        params: list[Any] = [event_id]
        if run_id is not None:
            query += "AND run_id = ? "
            params.append(run_id)
        query += "ORDER BY id DESC LIMIT 1"
        with self._connect() as conn:
            row = conn.execute(query, params).fetchone()
        if not row:
            return {}
        item = dict(row)
        item["discarded_by"] = json.loads(item.pop("discarded_by_json") or "[]")
        item["refusal_signal"] = json.loads(item.pop("refusal_signal_json") or "[]")
        item["trace"] = json.loads(item.pop("trace_json") or "{}")
        return item

    def get_latest_calibration(self, profile_name: str, calibration_id: int | None = None) -> dict[str, Any]:
        query = (
            "SELECT id, profile_name, baseline_threshold, recommended_threshold, sample_size, generated_at, result_json "
            "FROM calibrations WHERE profile_name = ? "
        )
        params: list[Any] = [profile_name]
        if calibration_id is not None:
            query += "AND id = ? "
            params.append(calibration_id)
        query += "ORDER BY id DESC LIMIT 1"
        with self._connect() as conn:
            row = conn.execute(query, params).fetchone()
        return dict(row) if row else {}

    def fetch_feedback_samples(self, profile_name: str, limit: int = 5000) -> list[dict[str, Any]]:
        with self._connect() as conn:
            feedback_rows = conn.execute(
                """
                SELECT id, event_id, run_id, profile_name, realized_return, realized_risk, operator_verdict
                FROM feedback
                WHERE profile_name = ?
                ORDER BY id DESC
                LIMIT ?
                """,
                (profile_name, limit),
            ).fetchall()

        samples: list[dict[str, Any]] = []
        for row in feedback_rows:
            item = dict(row)
            context = self.get_trace_context(event_id=item["event_id"], run_id=item.get("run_id"))
            discarded = json.loads(context.get("discarded_by_json") or "[]")
            samples.append(
                {
                    "event_id": item.get("event_id"),
                    "run_id": item.get("run_id"),
                    "profile_name": item.get("profile_name"),
                    "realized_return": float(item.get("realized_return") or 0.0),
                    "realized_risk": float(item.get("realized_risk") or 0.0),
                    "operator_verdict": item.get("operator_verdict") or "neutral",
                    "confidence": float(context.get("confidence") or 0.0),
                    "has_defeater": bool(discarded),
                }
            )
        return samples
