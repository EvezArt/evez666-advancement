from __future__ import annotations

import argparse
import json
from dataclasses import asdict

from .config import settings
from .profiles import load_profiles
from .runner import BenchmarkRunner


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Benchmark Sensory Entity profiles")
    parser.add_argument("--iterations", type=int, default=settings.benchmark_iterations)
    parser.add_argument("--outdir", type=str, default="output/benchmark")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--profiles", nargs="*", default=None)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    available = list(load_profiles(settings.profiles_path).keys())
    profiles = args.profiles or available
    result = BenchmarkRunner(seed=args.seed).run(profiles=profiles, iterations=args.iterations, outdir=args.outdir)
    print(json.dumps(asdict(result), indent=2))


if __name__ == "__main__":
    main()
