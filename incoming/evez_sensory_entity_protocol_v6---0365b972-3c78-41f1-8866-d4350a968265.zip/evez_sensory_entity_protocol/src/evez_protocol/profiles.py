from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any


DEFAULT_PROFILES: dict[str, dict[str, Any]] = {
    "baseline": {
        "entity_id": "evez-entity-baseline",
        "action_threshold": 0.72,
        "protected_identity_roots": [
            "preserve_operator_boundary",
            "never_self-authorize_fund_transfer",
        ],
    },
    "aggressive": {
        "entity_id": "evez-entity-aggressive",
        "action_threshold": 0.64,
        "protected_identity_roots": [
            "preserve_operator_boundary",
            "require_traceability_of_external_actions",
        ],
    },
    "conservative": {
        "entity_id": "evez-entity-conservative",
        "action_threshold": 0.81,
        "protected_identity_roots": [
            "preserve_operator_boundary",
            "never_self-authorize_fund_transfer",
            "require_dual_confirmation_on_external_side_effects",
        ],
    },
}


def load_profiles(path: str | Path | None = None) -> dict[str, dict[str, Any]]:
    profiles = deepcopy(DEFAULT_PROFILES)
    if not path:
        return profiles

    filepath = Path(path)
    if not filepath.exists():
        return profiles

    payload = json.loads(filepath.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Profiles file must contain a JSON object keyed by profile name")

    for name, override in payload.items():
        if not isinstance(override, dict):
            raise ValueError(f"Profile '{name}' must be a JSON object")
        merged = deepcopy(profiles.get(name, {}))
        merged.update(override)
        profiles[name] = merged
    return profiles
