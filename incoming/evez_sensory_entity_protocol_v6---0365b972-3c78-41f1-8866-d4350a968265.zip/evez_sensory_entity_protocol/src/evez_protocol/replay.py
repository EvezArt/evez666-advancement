from __future__ import annotations

import argparse
import csv
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, Iterable

from .adapters import adapt_signal
from .config import settings
from .runner import IterationRunner, RunSummary
from .storage import TraceStore


class ReplayRunner(IterationRunner):
    def __init__(self, profile_name: str = 'baseline', adapter_name: str = 'generic') -> None:
        super().__init__(seed=0, profile_name=profile_name)
        self.adapter_name = adapter_name

    def run_records(
        self,
        records: Iterable[dict[str, Any]],
        outdir: str | Path,
        store: TraceStore | None = None,
    ) -> RunSummary:
        records = list(records)
        adapted = [adapt_signal(self.adapter_name, record) for record in records]
        trace_callback = None
        if store is not None:
            trace_callback = lambda run_id, idx, trace: store.write_trace(run_id=run_id, iteration=idx, trace=trace, profile_name=self.profile_name)
        summary = self.run_signals(signals=adapted, outdir=outdir, trace_callback=trace_callback)
        if store is not None:
            store.write_summary(summary)
        return summary


def load_records(path: str | Path) -> list[dict[str, Any]]:
    filepath = Path(path)
    if filepath.suffix.lower() == '.csv':
        with filepath.open('r', encoding='utf-8', newline='') as handle:
            return list(csv.DictReader(handle))
    if filepath.suffix.lower() == '.jsonl':
        with filepath.open('r', encoding='utf-8') as handle:
            return [json.loads(line) for line in handle if line.strip()]
    payload = json.loads(filepath.read_text(encoding='utf-8'))
    if isinstance(payload, list):
        return payload
    raise ValueError('Replay input must be CSV, JSONL, or a JSON array')


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description='Replay raw records through an adapter and the protocol engine')
    parser.add_argument('--input', required=True, help='Path to CSV, JSONL, or JSON array file')
    parser.add_argument('--adapter', default='generic', help='Adapter name')
    parser.add_argument('--profile', default=settings.profile_name, help='Profile name')
    parser.add_argument('--outdir', default='output/replay', help='Output directory')
    parser.add_argument('--persist', action='store_true', help='Persist replay traces and summary into SQLite')
    return parser


def main() -> None:
    args = build_parser().parse_args()
    runner = ReplayRunner(profile_name=args.profile, adapter_name=args.adapter)
    store = TraceStore(settings.db_path) if args.persist else None
    summary = runner.run_records(records=load_records(args.input), outdir=args.outdir, store=store)
    print(json.dumps(asdict(summary), indent=2))


if __name__ == '__main__':
    main()
