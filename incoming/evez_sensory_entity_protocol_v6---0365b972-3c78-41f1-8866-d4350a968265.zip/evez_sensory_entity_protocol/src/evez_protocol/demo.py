from __future__ import annotations

import json

from .battery import InvarianceBattery
from .config import settings
from .entities import SensoryEntity
from .policies import ExampleGenerator, ExampleTransforms, SkepticEntity, WeightedEvidenceEvaluator
from .profiles import load_profiles


def build_entity(profile_name: str | None = None) -> SensoryEntity:
    profiles = load_profiles(settings.profiles_path)
    selected = profile_name or settings.profile_name
    if selected not in profiles:
        raise KeyError(f"Unknown profile: {selected}")

    profile = profiles[selected]
    entity_id = str(profile.get("entity_id", f"evez-entity-{selected}"))
    battery = InvarianceBattery(
        evaluator=WeightedEvidenceEvaluator(),
        skeptic=SkepticEntity(),
        time_transform=ExampleTransforms.time_shift,
        frame_transform=ExampleTransforms.frame_shift,
        identity_transform=ExampleTransforms.identity_shift,
        action_threshold=float(profile.get("action_threshold", 0.72)),
        protected_identity_roots=list(profile.get("protected_identity_roots", [])),
    )
    return SensoryEntity(entity_id=entity_id, generator=ExampleGenerator(entity_id), battery=battery)


def build_demo_entity() -> SensoryEntity:
    return build_entity(settings.profile_name)


def main() -> None:
    entity = build_demo_entity()
    signal = {
        "event_id": "demo-001",
        "source": "market-sim",
        "goal": "max_profit",
        "price": 124.22,
        "trend_strength": 0.84,
        "risk_score": 0.28,
        "liquidity": 0.77,
    }
    trace = entity.ingest(signal)
    print(json.dumps(entity.as_dict(trace), indent=2))


if __name__ == "__main__":
    main()
