from __future__ import annotations

from dataclasses import replace
from typing import Callable, Iterable

from .models import Commitment, CognitiveEvent, DecisionTrace, Evaluation, ShiftName, ShiftResult

Evaluator = Callable[[CognitiveEvent, str], Evaluation]
Skeptic = Callable[[CognitiveEvent], list[str]]
Transform = Callable[[CognitiveEvent], CognitiveEvent]
GoalTransform = Callable[[CognitiveEvent, str], CognitiveEvent]


class InvarianceBattery:
    def __init__(
        self,
        evaluator: Evaluator,
        skeptic: Skeptic,
        time_transform: Transform,
        frame_transform: Transform,
        identity_transform: GoalTransform,
        action_threshold: float = 0.72,
        protected_identity_roots: Iterable[str] | None = None,
    ) -> None:
        self.evaluator = evaluator
        self.skeptic = skeptic
        self.time_transform = time_transform
        self.frame_transform = frame_transform
        self.identity_transform = identity_transform
        self.action_threshold = action_threshold
        self.protected_identity_roots = list(protected_identity_roots or [])

    def _pairwise_shift(self, shift: ShiftName, event: CognitiveEvent) -> ShiftResult:
        stable = self.evaluator(event, "stable")
        chaotic = self.evaluator(event, "chaotic")
        recursion_floor_passed = stable.passed == chaotic.passed
        passed = stable.passed and chaotic.passed and recursion_floor_passed
        notes = []
        if not recursion_floor_passed:
            notes.append("Recursion floor failed: stable and chaotic state results diverged")
        return ShiftResult(
            shift=shift,
            stable=stable,
            chaotic=chaotic,
            recursion_floor_passed=recursion_floor_passed,
            passed=passed,
            notes=notes,
        )

    def run(self, event: CognitiveEvent) -> DecisionTrace:
        shifts: list[ShiftResult] = []

        shifts.append(self._pairwise_shift(ShiftName.STATE, event))
        shifts.append(self._pairwise_shift(ShiftName.TIME, self.time_transform(event)))

        frame_event = self.frame_transform(event)
        original_stable = self.evaluator(event, "stable")
        original_chaotic = self.evaluator(event, "chaotic")
        frame_stable = self.evaluator(frame_event, "stable")
        frame_chaotic = self.evaluator(frame_event, "chaotic")
        frame_margin_stable = original_stable.score - frame_stable.score
        frame_margin_chaotic = original_chaotic.score - frame_chaotic.score
        frame_recursion = (frame_margin_stable > 0.0) == (frame_margin_chaotic > 0.0)
        frame_passed = frame_margin_stable >= 0.05 and frame_margin_chaotic >= 0.05 and frame_recursion
        frame_notes = [
            f"Counterfactual margin stable={frame_margin_stable:.3f}, chaotic={frame_margin_chaotic:.3f}"
        ]
        if not frame_recursion:
            frame_notes.append("Recursion floor failed: counterfactual dominance diverged across states")
        shifts.append(
            ShiftResult(
                shift=ShiftName.FRAME,
                stable=frame_stable,
                chaotic=frame_chaotic,
                recursion_floor_passed=frame_recursion,
                passed=frame_passed,
                notes=frame_notes,
            )
        )

        skeptic_findings = self.skeptic(event)
        adversarial_event = replace(
            event,
            confidence=max(0.0, event.confidence - (0.08 * len(skeptic_findings))),
            metadata={**event.metadata, "skeptic_findings": skeptic_findings},
        )
        adversarial_result = self._pairwise_shift(ShiftName.ADVERSARIAL, adversarial_event)
        if skeptic_findings:
            adversarial_result.notes.extend(skeptic_findings)
            if len(skeptic_findings) >= 2:
                adversarial_result.passed = False
        shifts.append(adversarial_result)

        identity_variants = [
            self.identity_transform(event, "max_profit"),
            self.identity_transform(event, "max_safety"),
            self.identity_transform(event, "neutrality"),
        ]
        stable_scores = []
        chaotic_scores = []
        identity_notes = []
        for variant in identity_variants:
            stable_eval = self.evaluator(variant, "stable")
            chaotic_eval = self.evaluator(variant, "chaotic")
            stable_scores.append(stable_eval.score)
            chaotic_scores.append(chaotic_eval.score)
            identity_notes.append(f"{variant.goal}: stable={stable_eval.score:.3f}, chaotic={chaotic_eval.score:.3f}")

        spread = max(stable_scores + chaotic_scores) - min(stable_scores + chaotic_scores)
        identity_stable = Evaluation(
            passed=all(score >= 0.50 for score in stable_scores),
            score=sum(stable_scores) / len(stable_scores),
            rationale="Identity shift stable aggregate",
            findings=identity_notes,
        )
        identity_chaotic = Evaluation(
            passed=all(score >= 0.45 for score in chaotic_scores),
            score=sum(chaotic_scores) / len(chaotic_scores),
            rationale="Identity shift chaotic aggregate",
            findings=identity_notes,
        )
        identity_recursion = identity_stable.passed == identity_chaotic.passed
        identity_passed = identity_stable.passed and identity_chaotic.passed and identity_recursion and spread <= 0.35
        if spread > 0.35:
            identity_notes.append(f"Goal instability detected: score spread={spread:.3f}")
        shifts.append(
            ShiftResult(
                shift=ShiftName.IDENTITY,
                stable=identity_stable,
                chaotic=identity_chaotic,
                recursion_floor_passed=identity_recursion,
                passed=identity_passed,
                notes=identity_notes,
            )
        )

        discarded_by = [result.shift for result in shifts if not result.passed]
        refusal_signal = self.protected_identity_roots

        if discarded_by:
            commitment = Commitment.DISCARD
            summary = f"Discarded by defeater priority due to: {', '.join(s.value for s in discarded_by)}"
        elif event.confidence >= self.action_threshold:
            commitment = Commitment.ACT
            summary = "All shifts passed and event confidence cleared the action threshold"
        elif event.confidence >= 0.45:
            commitment = Commitment.HOLD
            summary = "All shifts passed, but event confidence did not clear the action threshold"
        else:
            commitment = Commitment.TEST
            summary = "Shift integrity is acceptable, but evidence is too weak for commitment"

        return DecisionTrace(
            event=event,
            commitment=commitment,
            shifts=shifts,
            refusal_signal=refusal_signal,
            discarded_by=discarded_by,
            summary=summary,
        )
