from __future__ import annotations

import json
import time
from dataclasses import asdict

from .config import settings
from .runner import IterationRunner
from .storage import TraceStore


def main() -> None:
    store = TraceStore(settings.db_path)
    while True:
        runner = IterationRunner(seed=settings.daemon_seed, profile_name=settings.profile_name)
        summary = runner.run(
            iterations=settings.daemon_batch_size,
            outdir=settings.output_dir,
            trace_callback=lambda run_id, idx, trace: store.write_trace(
                run_id=run_id, iteration=idx, trace=trace, profile_name=settings.profile_name
            ),
        )
        store.write_summary(summary)
        print(json.dumps(asdict(summary), indent=2))
        time.sleep(settings.daemon_interval_seconds)


if __name__ == "__main__":
    main()
