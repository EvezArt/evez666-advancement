from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Protocol


def bounded(value: float, minimum: float = 0.0, maximum: float = 1.0) -> float:
    return max(minimum, min(maximum, value))


class SignalAdapter(Protocol):
    def adapt(self, raw: dict[str, Any]) -> dict[str, Any]: ...


@dataclass(slots=True)
class GenericSignalAdapter:
    """Pass-through adapter for already-normalized payloads."""

    def adapt(self, raw: dict[str, Any]) -> dict[str, Any]:
        return {
            'event_id': str(raw.get('event_id', 'evt-generic')),
            'source': str(raw.get('source', 'generic-adapter')),
            'goal': str(raw.get('goal', 'max_profit')),
            'price': float(raw.get('price', 0.0)),
            'trend_strength': bounded(float(raw.get('trend_strength', 0.0))),
            'risk_score': bounded(float(raw.get('risk_score', 0.5))),
            'liquidity': bounded(float(raw.get('liquidity', 0.5))),
        }


@dataclass(slots=True)
class OHLCVSignalAdapter:
    """Normalizes candle-like market data into protocol features."""

    def adapt(self, raw: dict[str, Any]) -> dict[str, Any]:
        open_price = max(float(raw.get('open', raw.get('price', 1.0))), 1e-9)
        high = max(float(raw.get('high', open_price)), open_price)
        low = min(float(raw.get('low', open_price)), open_price)
        close = float(raw.get('close', open_price))
        volume = max(float(raw.get('volume', 0.0)), 0.0)
        prev_close = max(float(raw.get('prev_close', open_price)), 1e-9)

        intraday_return = (close - open_price) / open_price
        relative_strength = (close - prev_close) / prev_close
        range_width = max(high - low, 1e-9)
        close_location = (close - low) / range_width
        volatility = range_width / open_price
        volume_term = math.log10(volume + 1.0) / 6.0

        trend_strength = bounded((0.45 * ((intraday_return + 1) / 2)) + (0.35 * ((relative_strength + 1) / 2)) + (0.20 * close_location))
        liquidity = bounded((0.65 * volume_term) + (0.35 * (1.0 - bounded(volatility * 4.0))))
        risk_score = bounded((0.65 * bounded(volatility * 4.5)) + (0.35 * bounded(abs(relative_strength) * 2.0)))

        return {
            'event_id': str(raw.get('event_id', raw.get('timestamp', 'evt-ohlcv'))),
            'source': str(raw.get('source', 'ohlcv-adapter')),
            'goal': str(raw.get('goal', 'max_profit')),
            'price': close,
            'trend_strength': trend_strength,
            'risk_score': risk_score,
            'liquidity': liquidity,
            'raw_context': {
                'open': open_price,
                'high': high,
                'low': low,
                'close': close,
                'volume': volume,
                'prev_close': prev_close,
            },
        }


@dataclass(slots=True)
class TelemetrySignalAdapter:
    """Normalizes system telemetry into protocol features for daemon health or ops workflows."""

    def adapt(self, raw: dict[str, Any]) -> dict[str, Any]:
        success_rate = bounded(float(raw.get('success_rate', 0.5)))
        error_rate = bounded(float(raw.get('error_rate', 0.5)))
        queue_depth = bounded(float(raw.get('queue_depth', 0.5)))
        saturation = bounded(float(raw.get('saturation', 0.5)))
        latency = bounded(float(raw.get('latency_score', 0.5)))

        trend_strength = bounded((0.55 * success_rate) + (0.25 * (1.0 - error_rate)) + (0.20 * (1.0 - queue_depth)))
        liquidity = bounded((0.55 * (1.0 - saturation)) + (0.45 * latency))
        risk_score = bounded((0.45 * error_rate) + (0.35 * queue_depth) + (0.20 * saturation))

        return {
            'event_id': str(raw.get('event_id', 'evt-telemetry')),
            'source': str(raw.get('source', 'telemetry-adapter')),
            'goal': str(raw.get('goal', 'max_safety')),
            'price': float(raw.get('throughput', 0.0)),
            'trend_strength': trend_strength,
            'risk_score': risk_score,
            'liquidity': liquidity,
            'raw_context': {
                'success_rate': success_rate,
                'error_rate': error_rate,
                'queue_depth': queue_depth,
                'saturation': saturation,
                'latency_score': latency,
            },
        }


ADAPTERS: dict[str, SignalAdapter] = {
    'generic': GenericSignalAdapter(),
    'ohlcv': OHLCVSignalAdapter(),
    'telemetry': TelemetrySignalAdapter(),
}


def adapt_signal(adapter_name: str, raw: dict[str, Any]) -> dict[str, Any]:
    if adapter_name not in ADAPTERS:
        raise KeyError(f'Unknown adapter: {adapter_name}')
    return ADAPTERS[adapter_name].adapt(raw)


def list_adapters() -> list[str]:
    return sorted(ADAPTERS.keys())
