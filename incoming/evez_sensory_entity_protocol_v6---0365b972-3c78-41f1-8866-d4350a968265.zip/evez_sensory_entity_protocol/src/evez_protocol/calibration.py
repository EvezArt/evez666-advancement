from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from typing import Any

from .models import Commitment


@dataclass(slots=True)
class CalibrationCandidate:
    threshold: float
    mean_utility: float
    act_rate: float
    hold_rate: float
    discard_rate: float


@dataclass(slots=True)
class CalibrationResult:
    profile_name: str
    baseline_threshold: float
    recommended_threshold: float
    sample_size: int
    candidates: list[CalibrationCandidate]
    generated_at: str
    notes: list[str]


class ThresholdCalibrator:
    def __init__(self, baseline_threshold: float) -> None:
        self.baseline_threshold = baseline_threshold

    def calibrate(self, profile_name: str, samples: list[dict[str, Any]]) -> CalibrationResult:
        thresholds = [round(0.45 + step * 0.025, 3) for step in range(19)]
        candidates: list[CalibrationCandidate] = []
        for threshold in thresholds:
            candidates.append(self._score_threshold(samples, threshold))
        best = max(candidates, key=lambda item: (item.mean_utility, -abs(item.threshold - self.baseline_threshold)))
        notes = [
            'Recommendation is based on realized-return, realized-risk, and operator verdict feedback.',
            'Threshold search only affects non-discarded events; defeater-priority discards remain immutable.',
        ]
        if len(samples) < 20:
            notes.append('Sample size is small; treat this calibration as provisional.')
        return CalibrationResult(
            profile_name=profile_name,
            baseline_threshold=self.baseline_threshold,
            recommended_threshold=best.threshold,
            sample_size=len(samples),
            candidates=candidates,
            generated_at=datetime.now(UTC).isoformat(),
            notes=notes,
        )

    def _score_threshold(self, samples: list[dict[str, Any]], threshold: float) -> CalibrationCandidate:
        utilities: list[float] = []
        counts = {name.value: 0 for name in Commitment}
        for sample in samples:
            decision = self._decision_for_sample(sample, threshold)
            counts[decision.value] += 1
            utilities.append(self._utility(sample, decision))
        total = len(samples) or 1
        return CalibrationCandidate(
            threshold=threshold,
            mean_utility=round(sum(utilities) / total, 4),
            act_rate=round(counts[Commitment.ACT.value] / total, 4),
            hold_rate=round(counts[Commitment.HOLD.value] / total, 4),
            discard_rate=round(counts[Commitment.DISCARD.value] / total, 4),
        )

    @staticmethod
    def _decision_for_sample(sample: dict[str, Any], threshold: float) -> Commitment:
        if sample.get('has_defeater', False):
            return Commitment.DISCARD
        confidence = float(sample.get('confidence', 0.0))
        if confidence >= threshold:
            return Commitment.ACT
        if confidence >= 0.45:
            return Commitment.HOLD
        return Commitment.TEST

    @staticmethod
    def _utility(sample: dict[str, Any], decision: Commitment) -> float:
        realized_return = float(sample.get('realized_return', 0.0))
        realized_risk = float(sample.get('realized_risk', 0.0))
        verdict = sample.get('operator_verdict', 'neutral')
        verdict_term = {'good': 0.25, 'neutral': 0.0, 'bad': -0.25}.get(verdict, 0.0)

        if decision == Commitment.ACT:
            utility = (1.20 * realized_return) - (0.65 * realized_risk) + verdict_term
        elif decision == Commitment.HOLD:
            utility = (0.45 * realized_return) - (0.20 * realized_risk) + (0.35 * verdict_term)
        elif decision == Commitment.TEST:
            utility = (0.20 * realized_return) - (0.10 * realized_risk)
        else:
            utility = (-1.00 * realized_return) + (0.35 * realized_risk) - verdict_term
        return round(utility, 6)


def calibration_to_dict(result: CalibrationResult) -> dict[str, Any]:
    return asdict(result)
