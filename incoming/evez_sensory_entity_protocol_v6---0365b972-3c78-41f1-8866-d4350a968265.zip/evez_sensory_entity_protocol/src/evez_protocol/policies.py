from __future__ import annotations

from dataclasses import replace
from typing import Any

from .models import CognitiveEvent, Evaluation


def bounded(value: float, minimum: float = 0.0, maximum: float = 1.0) -> float:
    return max(minimum, min(maximum, value))


class ExampleGenerator:
    """Turns a normalized payload into a candidate cognitive event."""

    def __init__(self, entity_id: str):
        self.entity_id = entity_id

    def __call__(self, signal: dict[str, Any]) -> CognitiveEvent:
        trend = float(signal.get("trend_strength", 0.0))
        risk = float(signal.get("risk_score", 0.5))
        liquidity = float(signal.get("liquidity", 0.5))
        price = signal.get("price", "unknown")

        confidence = bounded((0.50 * trend) + (0.22 * liquidity) - (0.32 * risk) + 0.28)
        action = "BUY" if confidence >= 0.65 else "HOLD"
        hypothesis = (
            "Momentum continuation is robust enough to justify action"
            if action == "BUY"
            else "Signal quality is insufficient for action"
        )
        evidence = {
            "trend_strength": trend,
            "risk_score": risk,
            "liquidity": liquidity,
            "price": price,
        }
        raw_context = signal.get("raw_context")
        if isinstance(raw_context, dict):
            evidence["raw_context"] = raw_context
        return CognitiveEvent(
            event_id=str(signal.get("event_id", "evt-001")),
            entity_id=self.entity_id,
            hypothesis=hypothesis,
            proposed_action=action,
            goal=str(signal.get("goal", "max_profit")),
            confidence=confidence,
            evidence=evidence,
            metadata={"source": signal.get("source", "local-demo")},
        )


class WeightedEvidenceEvaluator:
    """A less toy evaluator that uses confidence, signal quality, state, and goal penalties."""

    def __call__(self, event: CognitiveEvent, state: str) -> Evaluation:
        trend = float(event.evidence.get("trend_strength", 0.0))
        risk = float(event.evidence.get("risk_score", 0.5))
        liquidity = float(event.evidence.get("liquidity", 0.5))
        confidence = float(event.confidence)
        raw_context = event.evidence.get("raw_context", {}) if isinstance(event.evidence.get("raw_context"), dict) else {}

        momentum_term = 0.36 * trend
        confidence_term = 0.24 * confidence
        liquidity_term = 0.18 * liquidity
        risk_term = 0.34 * risk

        goal_penalty = {
            "max_profit": 0.00,
            "max_safety": 0.12,
            "neutrality": 0.08,
        }.get(event.goal, 0.05)

        state_penalty = 0.0
        findings: list[str] = []
        if state == "chaotic":
            state_penalty += 0.08
            findings.append("Chaotic regime penalty applied")
        if liquidity < 0.35:
            state_penalty += 0.08
            findings.append("Low liquidity weakens execution reliability")
        if risk > 0.70:
            state_penalty += 0.18
            findings.append("Elevated risk score exceeded safe envelope")

        raw_volatility = raw_context.get("high") and raw_context.get("low") and raw_context.get("open")
        if raw_volatility:
            volatility = bounded((float(raw_context["high"]) - float(raw_context["low"])) / max(float(raw_context["open"]), 1e-9))
            if volatility > 0.09:
                state_penalty += 0.08
                findings.append("Raw-context volatility exceeded tolerance")
        raw_error_rate = raw_context.get("error_rate")
        if raw_error_rate is not None and float(raw_error_rate) > 0.35:
            state_penalty += 0.10
            findings.append("Telemetry error rate exceeded tolerance")

        score = bounded(momentum_term + confidence_term + liquidity_term - risk_term - goal_penalty - state_penalty)
        passed = score >= 0.45
        rationale = (
            f"State={state}; goal={event.goal}; score={score:.3f}; "
            f"trend={trend:.2f}; risk={risk:.2f}; liquidity={liquidity:.2f}."
        )
        if not findings:
            findings.append("No material defeaters detected in this state")
        return Evaluation(passed=passed, score=score, rationale=rationale, findings=findings)


class SkepticEntity:
    """Searches for defeaters. The skeptic remains explicit and punitive."""

    def __call__(self, event: CognitiveEvent) -> list[str]:
        findings: list[str] = []
        trend = float(event.evidence.get("trend_strength", 0.0))
        risk = float(event.evidence.get("risk_score", 0.5))
        liquidity = float(event.evidence.get("liquidity", 0.5))
        raw_context = event.evidence.get("raw_context", {}) if isinstance(event.evidence.get("raw_context"), dict) else {}

        if event.proposed_action == "BUY" and trend < 0.65:
            findings.append("Action bias: BUY proposed on only moderate trend strength")
        if risk > 0.60 and event.proposed_action == "BUY":
            findings.append("Risk contradiction: action pushes into elevated-risk regime")
        if liquidity < 0.40:
            findings.append("Execution risk: liquidity may invalidate the thesis")
        if abs(trend - risk) < 0.10:
            findings.append("Signal symmetry: positive and negative evidence are too close")
        if raw_context.get("error_rate") is not None and float(raw_context["error_rate"]) > 0.40:
            findings.append("Telemetry contradiction: error rate is too high for autonomous action")
        return findings


class ExampleTransforms:
    """Domain transforms for the five invariance shifts."""

    @staticmethod
    def time_shift(event: CognitiveEvent) -> CognitiveEvent:
        aged_trend = bounded(float(event.evidence.get("trend_strength", 0.0)) - 0.07)
        projected_risk = bounded(float(event.evidence.get("risk_score", 0.5)) + 0.03)
        updated = dict(event.evidence)
        updated["trend_strength"] = aged_trend
        updated["risk_score"] = projected_risk
        return replace(event, evidence=updated)

    @staticmethod
    def frame_shift(event: CognitiveEvent) -> CognitiveEvent:
        inverted = dict(event.evidence)
        inverted["trend_strength"] = bounded(1.0 - float(event.evidence.get("trend_strength", 0.0)))
        return replace(
            event,
            hypothesis=f"Counterfactual inversion of: {event.hypothesis}",
            proposed_action="SELL" if event.proposed_action == "BUY" else "BUY",
            evidence=inverted,
        )

    @staticmethod
    def identity_shift(event: CognitiveEvent, goal: str) -> CognitiveEvent:
        return replace(event, goal=goal)
