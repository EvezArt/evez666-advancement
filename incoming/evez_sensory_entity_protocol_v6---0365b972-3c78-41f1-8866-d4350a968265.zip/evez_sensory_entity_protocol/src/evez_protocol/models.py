from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Commitment(str, Enum):
    ACT = "ACT"
    HOLD = "HOLD"
    TEST = "TEST"
    DISCARD = "DISCARD"


class ShiftName(str, Enum):
    TIME = "time_shift"
    STATE = "state_shift"
    FRAME = "frame_shift"
    ADVERSARIAL = "adversarial_shift"
    IDENTITY = "identity_goal_shift"


@dataclass(slots=True)
class CognitiveEvent:
    event_id: str
    entity_id: str
    hypothesis: str
    proposed_action: str
    goal: str
    confidence: float
    evidence: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class Evaluation:
    passed: bool
    score: float
    rationale: str
    findings: list[str] = field(default_factory=list)


@dataclass(slots=True)
class ShiftResult:
    shift: ShiftName
    stable: Evaluation
    chaotic: Evaluation
    recursion_floor_passed: bool
    passed: bool
    notes: list[str] = field(default_factory=list)


@dataclass(slots=True)
class DecisionTrace:
    event: CognitiveEvent
    commitment: Commitment
    shifts: list[ShiftResult]
    refusal_signal: list[str]
    discarded_by: list[ShiftName]
    summary: str
