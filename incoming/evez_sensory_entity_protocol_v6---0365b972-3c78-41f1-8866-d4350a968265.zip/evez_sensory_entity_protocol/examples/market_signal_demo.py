from evez_protocol.demo import build_demo_entity


def run() -> None:
    entity = build_demo_entity()
    signals = [
        {
            "event_id": "strong-buy",
            "source": "local-book",
            "goal": "max_profit",
            "price": 100.0,
            "trend_strength": 0.91,
            "risk_score": 0.22,
            "liquidity": 0.83,
        },
        {
            "event_id": "fragile-signal",
            "source": "local-book",
            "goal": "max_profit",
            "price": 100.0,
            "trend_strength": 0.61,
            "risk_score": 0.64,
            "liquidity": 0.33,
        },
    ]

    for signal in signals:
        trace = entity.ingest(signal)
        print(f"\\n=== {signal['event_id']} => {trace.commitment.value} ===")
        print(trace.summary)
        for shift in trace.shifts:
            print(f"- {shift.shift.value}: passed={shift.passed}, stable={shift.stable.score:.3f}, chaotic={shift.chaotic.score:.3f}")


if __name__ == "__main__":
    run()
