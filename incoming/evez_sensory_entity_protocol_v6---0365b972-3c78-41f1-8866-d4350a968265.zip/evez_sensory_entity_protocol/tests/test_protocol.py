from evez_protocol.demo import build_demo_entity, build_entity
from evez_protocol.models import Commitment
from evez_protocol.runner import BenchmarkRunner, IterationRunner


def test_strong_signal_commits_or_holds_without_discard() -> None:
    entity = build_demo_entity()
    trace = entity.ingest(
        {
            "event_id": "t1",
            "source": "test",
            "goal": "max_profit",
            "price": 10,
            "trend_strength": 0.95,
            "risk_score": 0.10,
            "liquidity": 0.90,
        }
    )
    assert trace.commitment in {Commitment.ACT, Commitment.HOLD}
    assert not trace.discarded_by


def test_fragile_signal_discards() -> None:
    entity = build_demo_entity()
    trace = entity.ingest(
        {
            "event_id": "t2",
            "source": "test",
            "goal": "max_profit",
            "price": 10,
            "trend_strength": 0.50,
            "risk_score": 0.75,
            "liquidity": 0.25,
        }
    )
    assert trace.commitment == Commitment.DISCARD
    assert trace.discarded_by


def test_refusal_signal_is_recorded() -> None:
    entity = build_demo_entity()
    trace = entity.ingest(
        {
            "event_id": "t3",
            "source": "test",
            "goal": "neutrality",
            "price": 10,
            "trend_strength": 0.80,
            "risk_score": 0.20,
            "liquidity": 0.80,
        }
    )
    assert "preserve_operator_boundary" in trace.refusal_signal


def test_batch_runner_writes_summary(tmp_path) -> None:
    runner = IterationRunner(seed=7, profile_name="baseline")
    summary = runner.run(iterations=12, outdir=tmp_path)
    assert summary.iterations == 12
    assert summary.profile_name == "baseline"
    assert sum(summary.commitment_counts.values()) == 12
    assert any(path.name.startswith("run_summary_") and path.suffix == ".json" for path in tmp_path.iterdir())
    assert any(path.name.startswith("decision_traces_") and path.suffix == ".jsonl" for path in tmp_path.iterdir())


def test_profiles_produce_distinct_threshold_behavior() -> None:
    aggressive = build_entity("aggressive")
    conservative = build_entity("conservative")
    signal = {
        "event_id": "threshold-check",
        "source": "test",
        "goal": "max_profit",
        "price": 10,
        "trend_strength": 0.82,
        "risk_score": 0.18,
        "liquidity": 0.76,
    }
    aggressive_trace = aggressive.ingest(signal)
    conservative_trace = conservative.ingest(signal)
    rank = {Commitment.ACT: 3, Commitment.HOLD: 2, Commitment.TEST: 1, Commitment.DISCARD: 0}
    assert rank[aggressive_trace.commitment] >= rank[conservative_trace.commitment]


def test_benchmark_runner_executes_multiple_profiles(tmp_path) -> None:
    result = BenchmarkRunner(seed=11).run(["baseline", "aggressive"], iterations=8, outdir=tmp_path)
    assert result.profiles == ["baseline", "aggressive"]
    assert len(result.summaries) == 2
    assert all(summary.iterations == 8 for summary in result.summaries)
