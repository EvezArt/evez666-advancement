from pathlib import Path

from fastapi.testclient import TestClient

from evez_protocol.adapters import adapt_signal
from evez_protocol.calibration import ThresholdCalibrator
from evez_protocol.models import Commitment, CognitiveEvent, DecisionTrace, Evaluation, ShiftName, ShiftResult
from evez_protocol.service import app
from evez_protocol.storage import TraceStore
import evez_protocol.service as service_module


client = TestClient(app)


def make_trace(event_id: str, confidence: float, commitment: Commitment, discarded: bool = False) -> DecisionTrace:
    shift = ShiftResult(
        shift=ShiftName.STATE,
        stable=Evaluation(passed=not discarded, score=0.8, rationale='stable'),
        chaotic=Evaluation(passed=not discarded, score=0.8, rationale='chaotic'),
        recursion_floor_passed=True,
        passed=not discarded,
    )
    return DecisionTrace(
        event=CognitiveEvent(
            event_id=event_id,
            entity_id='test-entity',
            hypothesis='test',
            proposed_action='BUY',
            goal='max_profit',
            confidence=confidence,
            evidence={'trend_strength': 0.8, 'risk_score': 0.2, 'liquidity': 0.7},
            metadata={},
        ),
        commitment=commitment,
        shifts=[shift],
        refusal_signal=['preserve_operator_boundary'],
        discarded_by=[ShiftName.STATE] if discarded else [],
        summary='test summary',
    )


def test_ohlcv_adapter_normalizes_market_payload() -> None:
    payload = adapt_signal(
        'ohlcv',
        {
            'event_id': 'ohlcv-1',
            'open': 100,
            'high': 105,
            'low': 99,
            'close': 104,
            'volume': 250000,
            'prev_close': 98,
        },
    )
    assert payload['event_id'] == 'ohlcv-1'
    assert 0.0 <= payload['trend_strength'] <= 1.0
    assert 0.0 <= payload['risk_score'] <= 1.0
    assert 0.0 <= payload['liquidity'] <= 1.0
    assert payload['price'] == 104


def test_calibrator_prefers_lower_threshold_when_positive_feedback_is_confident() -> None:
    samples = [
        {'confidence': 0.68, 'has_defeater': False, 'realized_return': 0.7, 'realized_risk': 0.1, 'operator_verdict': 'good'},
        {'confidence': 0.66, 'has_defeater': False, 'realized_return': 0.5, 'realized_risk': 0.1, 'operator_verdict': 'good'},
        {'confidence': 0.62, 'has_defeater': False, 'realized_return': 0.45, 'realized_risk': 0.15, 'operator_verdict': 'good'},
        {'confidence': 0.84, 'has_defeater': False, 'realized_return': -0.4, 'realized_risk': 0.5, 'operator_verdict': 'bad'},
    ]
    result = ThresholdCalibrator(baseline_threshold=0.72).calibrate('baseline', samples)
    assert result.sample_size == 4
    assert 0.45 <= result.recommended_threshold <= 0.72


def test_feedback_and_calibration_roundtrip(tmp_path: Path) -> None:
    temp_store = TraceStore(tmp_path / 'roundtrip.db')
    original_store = service_module.store
    service_module.store = temp_store
    try:
        response = client.post(
            '/ingest/adapted',
            json={
                'adapter_name': 'ohlcv',
                'raw': {
                    'event_id': 'svc-cal-1',
                    'open': 100,
                    'high': 106,
                    'low': 99,
                    'close': 105,
                    'volume': 300000,
                    'prev_close': 98,
                },
            },
        )
        assert response.status_code == 200
        feedback = client.post(
            '/feedback',
            json={
                'event_id': 'svc-cal-1',
                'realized_return': 0.55,
                'realized_risk': 0.12,
                'operator_verdict': 'good',
                'notes': 'strong follow-through',
            },
        )
        assert feedback.status_code == 200
        calibrated = client.post('/calibrate', json={'profile_name': 'baseline', 'limit': 100})
        assert calibrated.status_code == 200
        data = calibrated.json()
        assert data['profile_name'] == 'baseline'
        assert data['sample_size'] >= 1
        assert 'recommended_threshold' in data
    finally:
        service_module.store = original_store
