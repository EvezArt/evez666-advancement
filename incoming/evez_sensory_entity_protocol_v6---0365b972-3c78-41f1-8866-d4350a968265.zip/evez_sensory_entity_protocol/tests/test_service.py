from fastapi.testclient import TestClient

from evez_protocol.config import settings
from evez_protocol.service import app


client = TestClient(app)


def test_health_endpoint() -> None:
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"


def test_ingest_endpoint_returns_commitment() -> None:
    response = client.post(
        "/ingest",
        json={
            "source": "test",
            "goal": "max_profit",
            "price": 101.0,
            "trend_strength": 0.85,
            "risk_score": 0.12,
            "liquidity": 0.81,
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["commitment"] in {"ACT", "HOLD", "TEST", "DISCARD"}
    assert data["profile_name"] == settings.profile_name


def test_dashboard_endpoint_returns_html() -> None:
    response = client.get("/dashboard")
    assert response.status_code == 200
    assert "EVEZ Sensory Entity Dashboard" in response.text


def test_profiles_endpoint_lists_default_profile() -> None:
    response = client.get("/profiles")
    assert response.status_code == 200
    data = response.json()
    assert settings.profile_name == data["default"]
    assert "baseline" in data["profiles"]


def test_api_key_is_enforced_when_configured(monkeypatch) -> None:
    monkeypatch.setattr(settings, "api_key", "secret-token")
    unauthorized = client.get("/profiles")
    authorized = client.get("/profiles", headers={"x-api-key": "secret-token"})
    monkeypatch.setattr(settings, "api_key", "")
    assert unauthorized.status_code == 401
    assert authorized.status_code == 200
