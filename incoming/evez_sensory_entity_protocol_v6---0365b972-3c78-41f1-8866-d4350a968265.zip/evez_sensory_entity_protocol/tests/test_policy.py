import json
from pathlib import Path

from fastapi.testclient import TestClient

from evez_protocol.service import app
from evez_protocol.storage import TraceStore
import evez_protocol.service as service_module


client = TestClient(app)


def _write_profiles(path: Path) -> None:
    path.write_text(
        json.dumps(
            {
                "baseline": {
                    "entity_id": "test-baseline",
                    "action_threshold": 0.72,
                    "protected_identity_roots": ["preserve_operator_boundary"],
                }
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )


def test_policy_promotion_roundtrip(tmp_path: Path) -> None:
    temp_store = TraceStore(tmp_path / 'policy.db')
    profiles_path = tmp_path / 'entity_profiles.json'
    _write_profiles(profiles_path)

    original_store = service_module.store
    original_registry = service_module.policy_registry
    original_profiles_path = service_module.settings.profiles_path

    service_module.store = temp_store
    service_module.settings.profiles_path = str(profiles_path)
    service_module.policy_registry = service_module.PolicyRegistry(service_module.settings.profiles_path, store=temp_store)
    try:
        ingest = client.post(
            '/ingest/adapted',
            json={
                'adapter_name': 'ohlcv',
                'raw': {
                    'event_id': 'policy-evt-1',
                    'open': 100,
                    'high': 106,
                    'low': 99,
                    'close': 105,
                    'volume': 300000,
                    'prev_close': 98,
                },
            },
        )
        assert ingest.status_code == 200
        feedback = client.post(
            '/feedback',
            json={
                'event_id': 'policy-evt-1',
                'realized_return': 0.8,
                'realized_risk': 0.05,
                'operator_verdict': 'good',
            },
        )
        assert feedback.status_code == 200
        calibrated = client.post('/calibrate', json={'profile_name': 'baseline', 'limit': 100})
        assert calibrated.status_code == 200
        promoted = client.post(
            '/policy/promote',
            json={'profile_name': 'baseline', 'reason': 'apply tested threshold', 'actor': 'pytest'},
        )
        assert promoted.status_code == 200
        result = promoted.json()
        assert result['profile_name'] == 'baseline'
        revisions = client.get('/profile-revisions')
        assert revisions.status_code == 200
        assert len(revisions.json()) >= 1
        exported = client.get('/policy/export')
        assert exported.status_code == 200
        bundle = exported.json()
        assert 'profiles' in bundle
        assert bundle['profiles']['baseline']['action_threshold'] == result['applied_threshold']
        explain = client.get('/events/policy-evt-1/explain')
        assert explain.status_code == 200
        explain_data = explain.json()
        assert explain_data['trace']['event_id'] == 'policy-evt-1'
        assert len(explain_data['feedback']) >= 1
    finally:
        service_module.store = original_store
        service_module.policy_registry = original_registry
        service_module.settings.profiles_path = original_profiles_path
