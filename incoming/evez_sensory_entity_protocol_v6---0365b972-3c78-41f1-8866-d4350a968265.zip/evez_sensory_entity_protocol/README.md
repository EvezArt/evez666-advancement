# EVEZ Sensory Entity Protocol

This repository turns the Sensory Entity Proof Grammar & Invariance Protocol into a deployable decision engine. A Sensory Entity consumes normalized signals, generates a Cognitive Event, stress-tests it through the Invariance Battery, applies defeater priority, and commits the event as `ACT`, `HOLD`, `TEST`, or `DISCARD`. The project is structured to outlive a notebook or chat session: it runs as a package, an API service, a daemon, a Docker container, or a systemd-managed process.

## What is included

- Sensory Entity runtime
- Invariance Battery with recursion-floor enforcement
- Skeptic Entity adversarial review
- refusal-signal tracking for protected identity roots
- batch runner for repeated evaluations
- benchmark runner for comparing profiles
- FastAPI service with SQLite persistence
- daemon loop for continuous execution
- dashboard for recent runs, traces, benchmarks, and calibrations
- signal adapters for normalized payloads, OHLCV market candles, and system telemetry
- feedback capture and threshold calibration from stored outcomes
- replay CLI for CSV / JSONL / JSON datasets
- Docker and systemd deployment surfaces

## Profiles

Profiles allow the same engine to run with different commitment thresholds and protected roots. The repository ships with `baseline`, `aggressive`, and `conservative` profiles in `config/entity_profiles.json`. Calibration does not mutate those files automatically; it writes recommended thresholds into SQLite so an operator can review them before promoting a change.

## API endpoints

- `GET /health`
- `GET /profiles`
- `GET /adapters`
- `POST /ingest`
- `POST /ingest/adapted`
- `POST /batch`
- `POST /benchmark`
- `POST /feedback`
- `POST /calibrate`
- `GET /runs`
- `GET /traces`
- `GET /benchmarks`
- `GET /feedback`
- `GET /calibrations`
- `GET /commitment-stats`
- `GET /dashboard`

If `EVEZ_API_KEY` is set, every endpoint except `/health` requires the `x-api-key` header.

## Local run

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
pytest
uvicorn evez_protocol.service:app --reload
```

## Batch, replay, and benchmark runs

```bash
evez-batch --profile baseline --iterations 700 --outdir output/700_now
evez-replay --adapter ohlcv --input examples/sample_ohlcv.csv --outdir output/replay --persist
evez-benchmark --iterations 150 --outdir output/benchmark
```

## Feedback and calibration loop

1. Ingest or replay signals and store traces.
2. Record realized outcomes through `POST /feedback`.
3. Run `POST /calibrate` for a profile.
4. Review the recommended threshold and candidate utility curve in the stored calibration result.
5. Decide whether to promote the recommendation into `config/entity_profiles.json`.

This keeps the engine honest: thresholds can be adjusted from actual observed outcomes instead of staying frozen at arbitrary defaults.

## Deployment

Use Docker Compose or the included systemd service. Point a real signal producer at `POST /ingest` or `POST /ingest/adapted`, replay historical data through `evez-replay`, and record outcomes through `POST /feedback`. Replace the example generator and evaluator with your production scoring logic when you are ready to connect live telemetry or market data.

## Policy Control Plane

The service can now promote calibrated thresholds into the active `entity_profiles.json` file and preserve a revision history in SQLite. This closes the loop between observed outcomes and active daemon policy. Use `POST /policy/promote` to apply the latest calibration for a profile, `GET /policy/export` to snapshot active profiles plus recent calibrations, and `GET /events/{event_id}/explain` to retrieve the full stored trace with linked feedback. The CLI entry point `evez-policy-promote` mirrors the same workflow for non-HTTP environments.

