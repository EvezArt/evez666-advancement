#!/usr/bin/env bash
set -euo pipefail
python -m evez_protocol.daemon --batch-size "${EVEZ_DAEMON_BATCH_SIZE:-10}" --interval-seconds "${EVEZ_DAEMON_INTERVAL_SECONDS:-60}"
