#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python -m evez_protocol.runner \
  --iterations 700 \
  --outdir output/700_in_48 \
  --sleep-seconds 246.857
