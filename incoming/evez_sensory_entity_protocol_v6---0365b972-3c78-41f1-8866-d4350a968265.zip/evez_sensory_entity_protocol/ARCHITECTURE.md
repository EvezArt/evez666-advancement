# EVEZ Sensory Entity Protocol Architecture

## Runtime planes

### 1. Ingestion plane
External systems send structured signals to the API or write them into a worker path. A signal becomes a `CognitiveEvent` through the generator policy.

### 2. Protocol plane
The `InvarianceBattery` runs five rotations on the event:
- state shift
- time shift
- frame shift
- adversarial shift
- identity / goal shift

The recursion floor is evaluated inside each shift. Defeater priority discards any event that fails a shift.

### 3. Commitment plane
The engine emits `ACT`, `HOLD`, `TEST`, or `DISCARD` with a full `DecisionTrace`.

### 4. Persistence plane
Each batch run writes summaries and traces to disk. The service also persists traces and run summaries to SQLite for later inspection.

### 5. Automation plane
The daemon executes repeated batches. CI verifies code integrity on push and pull request. Docker and systemd make the service durable on standard infrastructure.

## Durable deployment targets

### Minimum durable target
- GitHub repo
- GitHub Actions CI
- one VPS running Docker Compose

### Better durable target
- reverse proxy in front of FastAPI
- daemon worker on separate process
- nightly backup of SQLite or migration to Postgres

### Long-life target
- queue-backed ingestion
- multiple domain-specific entities
- signal connector registry
- operator console / dashboard

## Core boundary
The current build is a protocol engine, not a self-directing agent. It can evaluate and commit traces, but it does not self-authorize privileged actions. That boundary is encoded in refusal roots and should remain explicit.

## Policy control plane

Calibrations are no longer dead-end analytics. The service can now promote a recommended threshold into the active profile file, persist a revision record in SQLite, and export the current policy bundle for deployment or audit. This gives the daemon a durable, inspectable path from feedback to active configuration without manual JSON edits.
