from typing import Union
from .services.content_agent import ContentAgentService
from .services.research_agent import ResearchAgentService
from .services.team_pulse import TeamPulseService
from .services.sales_pipeline import SalesPipelineService
from .services.dev_status import DevStatusService
from .services.agent_control import AgentControlService
from .services.workspace_assistant import WorkspaceAssistantService
from .services.core_workspace import CoreWorkspaceService
from .net.environment import Environment


class EvezAgentnetRestApiSdk:
    """
    Main SDK client class for EvezAgentnetRestApiSdk.
    Provides centralized configuration and access to all service endpoints.
    Supports authentication, environment management, and global timeout settings.
    """

    def __init__(
        self, base_url: Union[Environment, str, None] = None, timeout: int = 60000
    ):
        """
        Initializes EvezAgentnetRestApiSdk the SDK class.
        """

        self._base_url = (
            base_url.value if isinstance(base_url, Environment) else base_url
        )
        self.content_agent = ContentAgentService(base_url=self._base_url)
        self.research_agent = ResearchAgentService(base_url=self._base_url)
        self.team_pulse = TeamPulseService(base_url=self._base_url)
        self.sales_pipeline = SalesPipelineService(base_url=self._base_url)
        self.dev_status = DevStatusService(base_url=self._base_url)
        self.agent_control = AgentControlService(base_url=self._base_url)
        self.workspace_assistant = WorkspaceAssistantService(base_url=self._base_url)
        self.core_workspace = CoreWorkspaceService(base_url=self._base_url)
        self.set_timeout(timeout)

    def set_base_url(self, base_url: Union[Environment, str]):
        """
        Sets the base URL for the entire SDK.

        :param Union[Environment, str] base_url: The base URL to be set.
        :return: The SDK instance.
        """
        self._base_url = (
            base_url.value if isinstance(base_url, Environment) else base_url
        )

        self.content_agent.set_base_url(self._base_url)
        self.research_agent.set_base_url(self._base_url)
        self.team_pulse.set_base_url(self._base_url)
        self.sales_pipeline.set_base_url(self._base_url)
        self.dev_status.set_base_url(self._base_url)
        self.agent_control.set_base_url(self._base_url)
        self.workspace_assistant.set_base_url(self._base_url)
        self.core_workspace.set_base_url(self._base_url)

        return self

    def set_timeout(self, timeout: int):
        """
        Sets the timeout for the entire SDK.

        :param int timeout: The timeout (ms) to be set.
        :return: The SDK instance.
        """
        self.content_agent.set_timeout(timeout)
        self.research_agent.set_timeout(timeout)
        self.team_pulse.set_timeout(timeout)
        self.sales_pipeline.set_timeout(timeout)
        self.dev_status.set_timeout(timeout)
        self.agent_control.set_timeout(timeout)
        self.workspace_assistant.set_timeout(timeout)
        self.core_workspace.set_timeout(timeout)

        return self


# c029837e0e474b76bc487506e8799df5e3335891efe4fb02bda7a1441840310c
