from pydantic import Field
from typing import Optional
from typing import Union
from .utils.base_model import BaseModel


class AgentStateChangeRequest(BaseModel):
    """AgentStateChangeRequest

    :param agent_id: agent_id, defaults to None
    :type agent_id: str, optional
    :param state: state, defaults to None
    :type state: str, optional
    """

    agent_id: Optional[str] = Field(
        alias="agentId", serialization_alias="agentId", default=None
    )
    state: Optional[str] = Field(default=None)
