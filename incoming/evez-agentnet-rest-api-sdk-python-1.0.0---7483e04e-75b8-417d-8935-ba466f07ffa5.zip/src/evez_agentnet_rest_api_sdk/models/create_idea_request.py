from pydantic import Field
from typing import Optional
from typing import Union
from .utils.base_model import BaseModel


class CreateIdeaRequest(BaseModel):
    """CreateIdeaRequest

    :param title: title, defaults to None
    :type title: str, optional
    :param description: description, defaults to None
    :type description: str, optional
    """

    title: Optional[str] = Field(default=None)
    description: Optional[str] = Field(default=None)
