from .create_idea_request import CreateIdeaRequest
from .draft_workflow_request import DraftWorkflowRequest
from .submit_finding_request import SubmitFindingRequest
from .move_deal_request import MoveDealRequest
from .create_pr_request import CreatePrRequest
from .schedule_command_request import ScheduleCommandRequest
from .agent_state_change_request import AgentStateChangeRequest
from .suggest_next_action_request import SuggestNextActionRequest

# Rebuild models to resolve circular forward references
# This ensures Pydantic can properly validate models that reference each other
CreateIdeaRequest.model_rebuild()
DraftWorkflowRequest.model_rebuild()
SubmitFindingRequest.model_rebuild()
MoveDealRequest.model_rebuild()
CreatePrRequest.model_rebuild()
ScheduleCommandRequest.model_rebuild()
AgentStateChangeRequest.model_rebuild()
SuggestNextActionRequest.model_rebuild()
