from pydantic import Field
from typing import Optional
from typing import Union
from .utils.base_model import BaseModel


class DraftWorkflowRequest(BaseModel):
    """DraftWorkflowRequest

    :param idea_id: idea_id, defaults to None
    :type idea_id: str, optional
    """

    idea_id: Optional[str] = Field(
        alias="ideaId", serialization_alias="ideaId", default=None
    )
