from pydantic import Field
from typing import Optional
from typing import Union
from .utils.base_model import BaseModel


class CreatePrRequest(BaseModel):
    """CreatePrRequest

    :param issue_id: issue_id, defaults to None
    :type issue_id: str, optional
    :param branch: branch, defaults to None
    :type branch: str, optional
    """

    issue_id: Optional[str] = Field(
        alias="issueId", serialization_alias="issueId", default=None
    )
    branch: Optional[str] = Field(default=None)
