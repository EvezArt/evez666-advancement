from pydantic import Field
from typing import Optional
from typing import Union
from .utils.base_model import BaseModel


class MoveDealRequest(BaseModel):
    """MoveDealRequest

    :param deal_id: deal_id, defaults to None
    :type deal_id: str, optional
    :param stage: stage, defaults to None
    :type stage: str, optional
    """

    deal_id: Optional[str] = Field(
        alias="dealId", serialization_alias="dealId", default=None
    )
    stage: Optional[str] = Field(default=None)
