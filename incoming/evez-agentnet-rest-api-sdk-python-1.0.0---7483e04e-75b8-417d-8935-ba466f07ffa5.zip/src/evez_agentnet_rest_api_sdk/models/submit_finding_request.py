from pydantic import Field
from typing import Optional
from typing import Union
from .utils.base_model import BaseModel


class SubmitFindingRequest(BaseModel):
    """SubmitFindingRequest

    :param question_id: question_id, defaults to None
    :type question_id: str, optional
    :param finding: finding, defaults to None
    :type finding: str, optional
    """

    question_id: Optional[str] = Field(
        alias="questionId", serialization_alias="questionId", default=None
    )
    finding: Optional[str] = Field(default=None)
