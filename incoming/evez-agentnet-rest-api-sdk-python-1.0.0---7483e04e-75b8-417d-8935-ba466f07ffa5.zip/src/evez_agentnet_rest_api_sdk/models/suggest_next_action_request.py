from pydantic import Field
from typing import Optional
from typing import Union
from .utils.base_model import BaseModel


class SuggestNextActionRequest(BaseModel):
    """SuggestNextActionRequest

    :param user_id: user_id, defaults to None
    :type user_id: str, optional
    :param context: context, defaults to None
    :type context: str, optional
    """

    user_id: Optional[str] = Field(
        alias="userId", serialization_alias="userId", default=None
    )
    context: Optional[str] = Field(default=None)
