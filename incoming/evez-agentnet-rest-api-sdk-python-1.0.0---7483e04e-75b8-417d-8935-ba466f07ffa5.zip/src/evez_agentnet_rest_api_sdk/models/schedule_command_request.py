from pydantic import Field
from typing import Optional
from typing import Union
from .utils.base_model import BaseModel


class ScheduleCommandRequest(BaseModel):
    """ScheduleCommandRequest

    :param role: role, defaults to None
    :type role: str, optional
    :param command: command, defaults to None
    :type command: str, optional
    :param run_at: run_at, defaults to None
    :type run_at: str, optional
    """

    role: Optional[str] = Field(default=None)
    command: Optional[str] = Field(default=None)
    run_at: Optional[str] = Field(
        alias="runAt", serialization_alias="runAt", default=None
    )
