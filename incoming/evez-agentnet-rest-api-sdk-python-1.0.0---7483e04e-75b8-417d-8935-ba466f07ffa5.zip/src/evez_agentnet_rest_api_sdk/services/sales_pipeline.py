from typing import Any, Optional
from .utils.validator import Validator
from .utils.base_service import BaseService
from ..net.transport.serializer import Serializer
from ..net.sdk_config import SdkConfig
from ..net.environment.environment import Environment
from ..models.utils.cast_models import cast_models
from ..models import MoveDealRequest


class SalesPipelineService(BaseService):
    """
    Service class for SalesPipelineService operations.
    Provides methods to interact with SalesPipelineService-related API endpoints.
    Inherits common functionality from BaseService including authentication and request handling.
    """

    def __init__(self, *args, **kwargs):
        """Initialize the service and method-level configurations."""
        super().__init__(*args, **kwargs)
        self._list_deals_config: SdkConfig = {"environment": Environment.API}
        self._move_deal_config: SdkConfig = {"environment": Environment.API}

    def set_list_deals_config(self, config: SdkConfig):
        """
        Sets method-level configuration for list_deals.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._list_deals_config = config
        return self

    def set_move_deal_config(self, config: SdkConfig):
        """
        Sets method-level configuration for move_deal.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._move_deal_config = config
        return self

    @cast_models
    def list_deals(self, *, request_config: Optional[SdkConfig] = None) -> Any:
        """list_deals

        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        resolved_config = self._get_resolved_config(
            self._list_deals_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/sales/deals",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("GET")
        )

        response, _, _ = self.send_request(serialized_request)
        return response

    @cast_models
    def move_deal(
        self,
        request_body: MoveDealRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Any:
        """move_deal

        :param request_body: The request body.
        :type request_body: MoveDealRequest
        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        Validator(MoveDealRequest).is_nullable().validate(request_body)

        resolved_config = self._get_resolved_config(
            self._move_deal_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/sales/deals/move",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("POST")
            .set_body(request_body)
        )

        response, _, _ = self.send_request(serialized_request)
        return response
