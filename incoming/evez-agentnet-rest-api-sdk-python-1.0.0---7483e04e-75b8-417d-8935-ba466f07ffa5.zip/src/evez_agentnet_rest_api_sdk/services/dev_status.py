from typing import Any, Optional
from .utils.validator import Validator
from .utils.base_service import BaseService
from ..net.transport.serializer import Serializer
from ..net.sdk_config import SdkConfig
from ..net.environment.environment import Environment
from ..models.utils.cast_models import cast_models
from ..models import CreatePrRequest


class DevStatusService(BaseService):
    """
    Service class for DevStatusService operations.
    Provides methods to interact with DevStatusService-related API endpoints.
    Inherits common functionality from BaseService including authentication and request handling.
    """

    def __init__(self, *args, **kwargs):
        """Initialize the service and method-level configurations."""
        super().__init__(*args, **kwargs)
        self._list_issues_config: SdkConfig = {"environment": Environment.API}
        self._create_pr_config: SdkConfig = {"environment": Environment.API}
        self._weekly_engineering_digest_config: SdkConfig = {
            "environment": Environment.API
        }

    def set_list_issues_config(self, config: SdkConfig):
        """
        Sets method-level configuration for list_issues.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._list_issues_config = config
        return self

    def set_create_pr_config(self, config: SdkConfig):
        """
        Sets method-level configuration for create_pr.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._create_pr_config = config
        return self

    def set_weekly_engineering_digest_config(self, config: SdkConfig):
        """
        Sets method-level configuration for weekly_engineering_digest.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._weekly_engineering_digest_config = config
        return self

    @cast_models
    def list_issues(self, *, request_config: Optional[SdkConfig] = None) -> Any:
        """list_issues

        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        resolved_config = self._get_resolved_config(
            self._list_issues_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/dev/issues",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("GET")
        )

        response, _, _ = self.send_request(serialized_request)
        return response

    @cast_models
    def create_pr(
        self,
        request_body: CreatePrRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Any:
        """create_pr

        :param request_body: The request body.
        :type request_body: CreatePrRequest
        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        Validator(CreatePrRequest).is_nullable().validate(request_body)

        resolved_config = self._get_resolved_config(
            self._create_pr_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/dev/prs",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("POST")
            .set_body(request_body)
        )

        response, _, _ = self.send_request(serialized_request)
        return response

    @cast_models
    def weekly_engineering_digest(
        self, *, request_config: Optional[SdkConfig] = None
    ) -> Any:
        """weekly_engineering_digest

        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        resolved_config = self._get_resolved_config(
            self._weekly_engineering_digest_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/dev/weekly-digest",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("GET")
        )

        response, _, _ = self.send_request(serialized_request)
        return response
