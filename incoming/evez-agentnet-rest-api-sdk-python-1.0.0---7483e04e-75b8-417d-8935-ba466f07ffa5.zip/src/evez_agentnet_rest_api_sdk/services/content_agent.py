from typing import Any, Optional
from .utils.validator import Validator
from .utils.base_service import BaseService
from ..net.transport.serializer import Serializer
from ..net.sdk_config import SdkConfig
from ..net.environment.environment import Environment
from ..models.utils.cast_models import cast_models
from ..models import CreateIdeaRequest, DraftWorkflowRequest


class ContentAgentService(BaseService):
    """
    Service class for ContentAgentService operations.
    Provides methods to interact with ContentAgentService-related API endpoints.
    Inherits common functionality from BaseService including authentication and request handling.
    """

    def __init__(self, *args, **kwargs):
        """Initialize the service and method-level configurations."""
        super().__init__(*args, **kwargs)
        self._list_ideas_config: SdkConfig = {"environment": Environment.API}
        self._create_idea_config: SdkConfig = {"environment": Environment.API}
        self._draft_workflow_config: SdkConfig = {"environment": Environment.API}
        self._weekly_content_plan_config: SdkConfig = {"environment": Environment.API}

    def set_list_ideas_config(self, config: SdkConfig):
        """
        Sets method-level configuration for list_ideas.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._list_ideas_config = config
        return self

    def set_create_idea_config(self, config: SdkConfig):
        """
        Sets method-level configuration for create_idea.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._create_idea_config = config
        return self

    def set_draft_workflow_config(self, config: SdkConfig):
        """
        Sets method-level configuration for draft_workflow.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._draft_workflow_config = config
        return self

    def set_weekly_content_plan_config(self, config: SdkConfig):
        """
        Sets method-level configuration for weekly_content_plan.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._weekly_content_plan_config = config
        return self

    @cast_models
    def list_ideas(self, *, request_config: Optional[SdkConfig] = None) -> Any:
        """list_ideas

        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        resolved_config = self._get_resolved_config(
            self._list_ideas_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/content/ideas",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("GET")
        )

        response, _, _ = self.send_request(serialized_request)
        return response

    @cast_models
    def create_idea(
        self,
        request_body: CreateIdeaRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Any:
        """create_idea

        :param request_body: The request body.
        :type request_body: CreateIdeaRequest
        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        Validator(CreateIdeaRequest).is_nullable().validate(request_body)

        resolved_config = self._get_resolved_config(
            self._create_idea_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/content/ideas",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("POST")
            .set_body(request_body)
        )

        response, _, _ = self.send_request(serialized_request)
        return response

    @cast_models
    def draft_workflow(
        self,
        request_body: DraftWorkflowRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Any:
        """draft_workflow

        :param request_body: The request body.
        :type request_body: DraftWorkflowRequest
        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        Validator(DraftWorkflowRequest).is_nullable().validate(request_body)

        resolved_config = self._get_resolved_config(
            self._draft_workflow_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/content/drafts",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("POST")
            .set_body(request_body)
        )

        response, _, _ = self.send_request(serialized_request)
        return response

    @cast_models
    def weekly_content_plan(self, *, request_config: Optional[SdkConfig] = None) -> Any:
        """weekly_content_plan

        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        resolved_config = self._get_resolved_config(
            self._weekly_content_plan_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/content/plans/weekly",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("GET")
        )

        response, _, _ = self.send_request(serialized_request)
        return response
