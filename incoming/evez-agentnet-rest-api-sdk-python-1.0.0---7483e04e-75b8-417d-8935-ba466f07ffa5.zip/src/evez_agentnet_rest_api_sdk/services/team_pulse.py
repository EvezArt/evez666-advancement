from typing import Any, Optional
from .utils.validator import Validator
from .utils.base_service import BaseService
from ..net.transport.serializer import Serializer
from ..net.sdk_config import SdkConfig
from ..net.environment.environment import Environment
from ..models.utils.cast_models import cast_models


class TeamPulseService(BaseService):
    """
    Service class for TeamPulseService operations.
    Provides methods to interact with TeamPulseService-related API endpoints.
    Inherits common functionality from BaseService including authentication and request handling.
    """

    def __init__(self, *args, **kwargs):
        """Initialize the service and method-level configurations."""
        super().__init__(*args, **kwargs)
        self._get_daily_pulse_config: SdkConfig = {"environment": Environment.API}
        self._list_triggers_config: SdkConfig = {"environment": Environment.API}

    def set_get_daily_pulse_config(self, config: SdkConfig):
        """
        Sets method-level configuration for get_daily_pulse.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._get_daily_pulse_config = config
        return self

    def set_list_triggers_config(self, config: SdkConfig):
        """
        Sets method-level configuration for list_triggers.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._list_triggers_config = config
        return self

    @cast_models
    def get_daily_pulse(self, *, request_config: Optional[SdkConfig] = None) -> Any:
        """get_daily_pulse

        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        resolved_config = self._get_resolved_config(
            self._get_daily_pulse_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/pulse/daily",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("GET")
        )

        response, _, _ = self.send_request(serialized_request)
        return response

    @cast_models
    def list_triggers(self, *, request_config: Optional[SdkConfig] = None) -> Any:
        """list_triggers

        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        resolved_config = self._get_resolved_config(
            self._list_triggers_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/pulse/triggers",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("GET")
        )

        response, _, _ = self.send_request(serialized_request)
        return response
