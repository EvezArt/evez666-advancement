from typing import Any, Optional
from .utils.validator import Validator
from .utils.base_service import BaseService
from ..net.transport.serializer import Serializer
from ..net.sdk_config import SdkConfig
from ..net.environment.environment import Environment
from ..models.utils.cast_models import cast_models
from ..models import SubmitFindingRequest


class ResearchAgentService(BaseService):
    """
    Service class for ResearchAgentService operations.
    Provides methods to interact with ResearchAgentService-related API endpoints.
    Inherits common functionality from BaseService including authentication and request handling.
    """

    def __init__(self, *args, **kwargs):
        """Initialize the service and method-level configurations."""
        super().__init__(*args, **kwargs)
        self._list_questions_config: SdkConfig = {"environment": Environment.API}
        self._submit_finding_config: SdkConfig = {"environment": Environment.API}
        self._daily_morning_brief_config: SdkConfig = {"environment": Environment.API}

    def set_list_questions_config(self, config: SdkConfig):
        """
        Sets method-level configuration for list_questions.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._list_questions_config = config
        return self

    def set_submit_finding_config(self, config: SdkConfig):
        """
        Sets method-level configuration for submit_finding.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._submit_finding_config = config
        return self

    def set_daily_morning_brief_config(self, config: SdkConfig):
        """
        Sets method-level configuration for daily_morning_brief.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._daily_morning_brief_config = config
        return self

    @cast_models
    def list_questions(self, *, request_config: Optional[SdkConfig] = None) -> Any:
        """list_questions

        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        resolved_config = self._get_resolved_config(
            self._list_questions_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/research/questions",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("GET")
        )

        response, _, _ = self.send_request(serialized_request)
        return response

    @cast_models
    def submit_finding(
        self,
        request_body: SubmitFindingRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Any:
        """submit_finding

        :param request_body: The request body.
        :type request_body: SubmitFindingRequest
        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        Validator(SubmitFindingRequest).is_nullable().validate(request_body)

        resolved_config = self._get_resolved_config(
            self._submit_finding_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/research/findings",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("POST")
            .set_body(request_body)
        )

        response, _, _ = self.send_request(serialized_request)
        return response

    @cast_models
    def daily_morning_brief(self, *, request_config: Optional[SdkConfig] = None) -> Any:
        """daily_morning_brief

        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        resolved_config = self._get_resolved_config(
            self._daily_morning_brief_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/research/briefs/daily",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("GET")
        )

        response, _, _ = self.send_request(serialized_request)
        return response
