from typing import Any, Optional
from .utils.validator import Validator
from .utils.base_service import BaseService
from ..net.transport.serializer import Serializer
from ..net.sdk_config import SdkConfig
from ..net.environment.environment import Environment
from ..models.utils.cast_models import cast_models
from ..models import AgentStateChangeRequest, ScheduleCommandRequest


class AgentControlService(BaseService):
    """
    Service class for AgentControlService operations.
    Provides methods to interact with AgentControlService-related API endpoints.
    Inherits common functionality from BaseService including authentication and request handling.
    """

    def __init__(self, *args, **kwargs):
        """Initialize the service and method-level configurations."""
        super().__init__(*args, **kwargs)
        self._schedule_command_config: SdkConfig = {"environment": Environment.API}
        self._agent_state_change_config: SdkConfig = {"environment": Environment.API}

    def set_schedule_command_config(self, config: SdkConfig):
        """
        Sets method-level configuration for schedule_command.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._schedule_command_config = config
        return self

    def set_agent_state_change_config(self, config: SdkConfig):
        """
        Sets method-level configuration for agent_state_change.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._agent_state_change_config = config
        return self

    @cast_models
    def schedule_command(
        self,
        request_body: ScheduleCommandRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Any:
        """schedule_command

        :param request_body: The request body.
        :type request_body: ScheduleCommandRequest
        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        Validator(ScheduleCommandRequest).is_nullable().validate(request_body)

        resolved_config = self._get_resolved_config(
            self._schedule_command_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/agents/control/schedule",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("POST")
            .set_body(request_body)
        )

        response, _, _ = self.send_request(serialized_request)
        return response

    @cast_models
    def agent_state_change(
        self,
        request_body: AgentStateChangeRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Any:
        """agent_state_change

        :param request_body: The request body.
        :type request_body: AgentStateChangeRequest
        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        Validator(AgentStateChangeRequest).is_nullable().validate(request_body)

        resolved_config = self._get_resolved_config(
            self._agent_state_change_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/agents/control/state",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("POST")
            .set_body(request_body)
        )

        response, _, _ = self.send_request(serialized_request)
        return response
