from typing import Any, Optional
from .utils.validator import Validator
from .utils.base_service import BaseService
from ..net.transport.serializer import Serializer
from ..net.sdk_config import SdkConfig
from ..net.environment.environment import Environment
from ..models.utils.cast_models import cast_models


class CoreWorkspaceService(BaseService):
    """
    Service class for CoreWorkspaceService operations.
    Provides methods to interact with CoreWorkspaceService-related API endpoints.
    Inherits common functionality from BaseService including authentication and request handling.
    """

    def __init__(self, *args, **kwargs):
        """Initialize the service and method-level configurations."""
        super().__init__(*args, **kwargs)
        self._workspace_state_config: SdkConfig = {"environment": Environment.API}

    def set_workspace_state_config(self, config: SdkConfig):
        """
        Sets method-level configuration for workspace_state.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._workspace_state_config = config
        return self

    @cast_models
    def workspace_state(self, *, request_config: Optional[SdkConfig] = None) -> Any:
        """workspace_state

        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        resolved_config = self._get_resolved_config(
            self._workspace_state_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/workspace/state",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("GET")
        )

        response, _, _ = self.send_request(serialized_request)
        return response
