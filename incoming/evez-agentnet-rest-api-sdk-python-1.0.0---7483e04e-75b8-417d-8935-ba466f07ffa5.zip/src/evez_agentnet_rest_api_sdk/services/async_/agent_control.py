from typing import Awaitable, Optional, Any
from .utils.to_async import to_async
from ..agent_control import AgentControlService
from ...net.sdk_config import SdkConfig
from ...models import ScheduleCommandRequest, AgentStateChangeRequest


class AgentControlServiceAsync(AgentControlService):
    """
    Async Wrapper for AgentControlServiceAsync
    """

    def schedule_command(
        self,
        request_body: ScheduleCommandRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Awaitable[Any]:
        return to_async(super().schedule_command)(
            request_body, request_config=request_config
        )

    def agent_state_change(
        self,
        request_body: AgentStateChangeRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Awaitable[Any]:
        return to_async(super().agent_state_change)(
            request_body, request_config=request_config
        )
