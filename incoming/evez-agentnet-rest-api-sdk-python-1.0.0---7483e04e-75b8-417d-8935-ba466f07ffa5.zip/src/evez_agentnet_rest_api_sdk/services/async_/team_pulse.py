from typing import Awaitable, Optional, Any
from .utils.to_async import to_async
from ..team_pulse import TeamPulseService
from ...net.sdk_config import SdkConfig


class TeamPulseServiceAsync(TeamPulseService):
    """
    Async Wrapper for TeamPulseServiceAsync
    """

    def get_daily_pulse(
        self, *, request_config: Optional[SdkConfig] = None
    ) -> Awaitable[Any]:
        return to_async(super().get_daily_pulse)(request_config=request_config)

    def list_triggers(
        self, *, request_config: Optional[SdkConfig] = None
    ) -> Awaitable[Any]:
        return to_async(super().list_triggers)(request_config=request_config)
