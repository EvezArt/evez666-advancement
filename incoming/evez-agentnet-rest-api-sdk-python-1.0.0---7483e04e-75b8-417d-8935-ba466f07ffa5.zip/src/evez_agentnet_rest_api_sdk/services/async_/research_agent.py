from typing import Awaitable, Optional, Any
from .utils.to_async import to_async
from ..research_agent import ResearchAgentService
from ...net.sdk_config import SdkConfig
from ...models import SubmitFindingRequest


class ResearchAgentServiceAsync(ResearchAgentService):
    """
    Async Wrapper for ResearchAgentServiceAsync
    """

    def list_questions(
        self, *, request_config: Optional[SdkConfig] = None
    ) -> Awaitable[Any]:
        return to_async(super().list_questions)(request_config=request_config)

    def submit_finding(
        self,
        request_body: SubmitFindingRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Awaitable[Any]:
        return to_async(super().submit_finding)(
            request_body, request_config=request_config
        )

    def daily_morning_brief(
        self, *, request_config: Optional[SdkConfig] = None
    ) -> Awaitable[Any]:
        return to_async(super().daily_morning_brief)(request_config=request_config)
