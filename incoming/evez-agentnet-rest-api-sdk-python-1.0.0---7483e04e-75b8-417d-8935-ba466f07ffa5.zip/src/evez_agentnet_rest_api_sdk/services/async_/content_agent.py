from typing import Awaitable, Optional, Any
from .utils.to_async import to_async
from ..content_agent import ContentAgentService
from ...net.sdk_config import SdkConfig
from ...models import CreateIdeaRequest, DraftWorkflowRequest


class ContentAgentServiceAsync(ContentAgentService):
    """
    Async Wrapper for ContentAgentServiceAsync
    """

    def list_ideas(
        self, *, request_config: Optional[SdkConfig] = None
    ) -> Awaitable[Any]:
        return to_async(super().list_ideas)(request_config=request_config)

    def create_idea(
        self,
        request_body: CreateIdeaRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Awaitable[Any]:
        return to_async(super().create_idea)(
            request_body, request_config=request_config
        )

    def draft_workflow(
        self,
        request_body: DraftWorkflowRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Awaitable[Any]:
        return to_async(super().draft_workflow)(
            request_body, request_config=request_config
        )

    def weekly_content_plan(
        self, *, request_config: Optional[SdkConfig] = None
    ) -> Awaitable[Any]:
        return to_async(super().weekly_content_plan)(request_config=request_config)
