from typing import Awaitable, Optional, Any
from .utils.to_async import to_async
from ..core_workspace import CoreWorkspaceService
from ...net.sdk_config import SdkConfig


class CoreWorkspaceServiceAsync(CoreWorkspaceService):
    """
    Async Wrapper for CoreWorkspaceServiceAsync
    """

    def workspace_state(
        self, *, request_config: Optional[SdkConfig] = None
    ) -> Awaitable[Any]:
        return to_async(super().workspace_state)(request_config=request_config)
