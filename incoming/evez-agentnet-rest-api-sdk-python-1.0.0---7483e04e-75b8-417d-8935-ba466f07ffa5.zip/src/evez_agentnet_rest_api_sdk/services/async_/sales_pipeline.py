from typing import Awaitable, Optional, Any
from .utils.to_async import to_async
from ..sales_pipeline import SalesPipelineService
from ...net.sdk_config import SdkConfig
from ...models import MoveDealRequest


class SalesPipelineServiceAsync(SalesPipelineService):
    """
    Async Wrapper for SalesPipelineServiceAsync
    """

    def list_deals(
        self, *, request_config: Optional[SdkConfig] = None
    ) -> Awaitable[Any]:
        return to_async(super().list_deals)(request_config=request_config)

    def move_deal(
        self,
        request_body: MoveDealRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Awaitable[Any]:
        return to_async(super().move_deal)(request_body, request_config=request_config)
