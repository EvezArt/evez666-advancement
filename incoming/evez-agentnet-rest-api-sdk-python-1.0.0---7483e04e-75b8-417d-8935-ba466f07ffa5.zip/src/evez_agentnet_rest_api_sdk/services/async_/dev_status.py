from typing import Awaitable, Optional, Any
from .utils.to_async import to_async
from ..dev_status import DevStatusService
from ...net.sdk_config import SdkConfig
from ...models import CreatePrRequest


class DevStatusServiceAsync(DevStatusService):
    """
    Async Wrapper for DevStatusServiceAsync
    """

    def list_issues(
        self, *, request_config: Optional[SdkConfig] = None
    ) -> Awaitable[Any]:
        return to_async(super().list_issues)(request_config=request_config)

    def create_pr(
        self,
        request_body: CreatePrRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Awaitable[Any]:
        return to_async(super().create_pr)(request_body, request_config=request_config)

    def weekly_engineering_digest(
        self, *, request_config: Optional[SdkConfig] = None
    ) -> Awaitable[Any]:
        return to_async(super().weekly_engineering_digest)(
            request_config=request_config
        )
