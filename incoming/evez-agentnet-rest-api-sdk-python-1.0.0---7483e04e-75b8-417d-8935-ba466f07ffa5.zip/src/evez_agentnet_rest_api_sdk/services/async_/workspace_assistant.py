from typing import Awaitable, Optional, Any
from .utils.to_async import to_async
from ..workspace_assistant import WorkspaceAssistantService
from ...net.sdk_config import SdkConfig
from ...models import SuggestNextActionRequest


class WorkspaceAssistantServiceAsync(WorkspaceAssistantService):
    """
    Async Wrapper for WorkspaceAssistantServiceAsync
    """

    def suggest_next_action(
        self,
        request_body: SuggestNextActionRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Awaitable[Any]:
        return to_async(super().suggest_next_action)(
            request_body, request_config=request_config
        )
