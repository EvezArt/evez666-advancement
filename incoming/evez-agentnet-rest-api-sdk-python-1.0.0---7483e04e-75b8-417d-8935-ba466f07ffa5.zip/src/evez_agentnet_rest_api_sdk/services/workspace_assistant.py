from typing import Any, Optional
from .utils.validator import Validator
from .utils.base_service import BaseService
from ..net.transport.serializer import Serializer
from ..net.sdk_config import SdkConfig
from ..net.environment.environment import Environment
from ..models.utils.cast_models import cast_models
from ..models import SuggestNextActionRequest


class WorkspaceAssistantService(BaseService):
    """
    Service class for WorkspaceAssistantService operations.
    Provides methods to interact with WorkspaceAssistantService-related API endpoints.
    Inherits common functionality from BaseService including authentication and request handling.
    """

    def __init__(self, *args, **kwargs):
        """Initialize the service and method-level configurations."""
        super().__init__(*args, **kwargs)
        self._suggest_next_action_config: SdkConfig = {"environment": Environment.API}

    def set_suggest_next_action_config(self, config: SdkConfig):
        """
        Sets method-level configuration for suggest_next_action.

        :param SdkConfig config: Configuration dictionary to override service-level defaults.
        :return: The service instance for method chaining.
        """
        self._suggest_next_action_config = config
        return self

    @cast_models
    def suggest_next_action(
        self,
        request_body: SuggestNextActionRequest,
        *,
        request_config: Optional[SdkConfig] = None,
    ) -> Any:
        """suggest_next_action

        :param request_body: The request body.
        :type request_body: SuggestNextActionRequest
        ...
        :raises RequestError: Raised when a request fails, with optional HTTP status code and details.
        ...
        :return: The parsed response data.
        :rtype: Any
        """

        Validator(SuggestNextActionRequest).is_nullable().validate(request_body)

        resolved_config = self._get_resolved_config(
            self._suggest_next_action_config, request_config
        )

        serialized_request = (
            Serializer(
                f"{resolved_config.get('base_url') or self.base_url or Environment.API.url or Environment.DEFAULT.url}/workspace/assistant/next-action",
                [],
                resolved_config,
            )
            .serialize()
            .set_method("POST")
            .set_body(request_body)
        )

        response, _, _ = self.send_request(serialized_request)
        return response
