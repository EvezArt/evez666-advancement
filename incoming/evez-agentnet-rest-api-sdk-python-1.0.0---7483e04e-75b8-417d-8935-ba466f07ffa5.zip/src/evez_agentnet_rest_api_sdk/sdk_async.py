from typing import Union
from .net.environment import Environment
from .sdk import EvezAgentnetRestApiSdk
from .services.async_.content_agent import ContentAgentServiceAsync
from .services.async_.research_agent import ResearchAgentServiceAsync
from .services.async_.team_pulse import TeamPulseServiceAsync
from .services.async_.sales_pipeline import SalesPipelineServiceAsync
from .services.async_.dev_status import DevStatusServiceAsync
from .services.async_.agent_control import AgentControlServiceAsync
from .services.async_.workspace_assistant import WorkspaceAssistantServiceAsync
from .services.async_.core_workspace import CoreWorkspaceServiceAsync


class EvezAgentnetRestApiSdkAsync(EvezAgentnetRestApiSdk):
    """
    EvezAgentnetRestApiSdkAsync is the asynchronous version of the EvezAgentnetRestApiSdk SDK Client.
    """

    def __init__(
        self, base_url: Union[Environment, str, None] = None, timeout: int = 60000
    ):
        super().__init__(base_url=base_url, timeout=timeout)

        self.content_agent = ContentAgentServiceAsync(base_url=self._base_url)
        self.research_agent = ResearchAgentServiceAsync(base_url=self._base_url)
        self.team_pulse = TeamPulseServiceAsync(base_url=self._base_url)
        self.sales_pipeline = SalesPipelineServiceAsync(base_url=self._base_url)
        self.dev_status = DevStatusServiceAsync(base_url=self._base_url)
        self.agent_control = AgentControlServiceAsync(base_url=self._base_url)
        self.workspace_assistant = WorkspaceAssistantServiceAsync(
            base_url=self._base_url
        )
        self.core_workspace = CoreWorkspaceServiceAsync(base_url=self._base_url)
