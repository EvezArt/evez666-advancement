from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment

sdk = EvezAgentnetRestApiSdk(base_url=Environment.DEFAULT.value, timeout=10000)

result = sdk.content_agent.list_ideas()

print(result)
