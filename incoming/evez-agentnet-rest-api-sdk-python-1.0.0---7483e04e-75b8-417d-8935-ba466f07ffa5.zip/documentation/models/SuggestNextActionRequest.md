# SuggestNextActionRequest

**Properties**

| Name    | Type | Required | Description |
| :------ | :--- | :------- | :---------- |
| user_id | str  | ❌       |             |
| context | str  | ❌       |             |
