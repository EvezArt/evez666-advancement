# ScheduleCommandRequest

**Properties**

| Name    | Type | Required | Description |
| :------ | :--- | :------- | :---------- |
| role    | str  | ❌       |             |
| command | str  | ❌       |             |
| run_at  | str  | ❌       |             |
