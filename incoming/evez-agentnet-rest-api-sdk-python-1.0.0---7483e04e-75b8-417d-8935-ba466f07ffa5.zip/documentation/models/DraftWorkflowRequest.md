# DraftWorkflowRequest

**Properties**

| Name    | Type | Required | Description |
| :------ | :--- | :------- | :---------- |
| idea_id | str  | ❌       |             |
