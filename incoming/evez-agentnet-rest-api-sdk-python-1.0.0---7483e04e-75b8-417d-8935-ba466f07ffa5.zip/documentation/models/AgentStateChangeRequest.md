# AgentStateChangeRequest

**Properties**

| Name     | Type | Required | Description |
| :------- | :--- | :------- | :---------- |
| agent_id | str  | ❌       |             |
| state    | str  | ❌       |             |
