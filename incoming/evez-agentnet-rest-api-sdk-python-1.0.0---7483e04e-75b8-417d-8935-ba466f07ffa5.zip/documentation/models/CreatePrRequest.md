# CreatePrRequest

**Properties**

| Name     | Type | Required | Description |
| :------- | :--- | :------- | :---------- |
| issue_id | str  | ❌       |             |
| branch   | str  | ❌       |             |
