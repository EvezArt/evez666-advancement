# SubmitFindingRequest

**Properties**

| Name        | Type | Required | Description |
| :---------- | :--- | :------- | :---------- |
| question_id | str  | ❌       |             |
| finding     | str  | ❌       |             |
