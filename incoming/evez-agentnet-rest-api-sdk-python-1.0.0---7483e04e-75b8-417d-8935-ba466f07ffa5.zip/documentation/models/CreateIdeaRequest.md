# CreateIdeaRequest

**Properties**

| Name        | Type | Required | Description |
| :---------- | :--- | :------- | :---------- |
| title       | str  | ❌       |             |
| description | str  | ❌       |             |
