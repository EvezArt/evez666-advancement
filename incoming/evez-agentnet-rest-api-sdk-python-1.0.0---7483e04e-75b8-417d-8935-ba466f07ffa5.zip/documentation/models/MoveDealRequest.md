# MoveDealRequest

**Properties**

| Name    | Type | Required | Description |
| :------ | :--- | :------- | :---------- |
| deal_id | str  | ❌       |             |
| stage   | str  | ❌       |             |
