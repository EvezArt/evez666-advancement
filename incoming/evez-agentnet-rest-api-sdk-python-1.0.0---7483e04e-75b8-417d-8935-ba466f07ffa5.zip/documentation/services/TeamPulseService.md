# TeamPulseService

A list of all methods in the `TeamPulseService` service. Click on the method name to view detailed information about that method.

| Methods                             | Description |
| :---------------------------------- | :---------- |
| [get_daily_pulse](#get_daily_pulse) |             |
| [list_triggers](#list_triggers)     |             |

## get_daily_pulse

- HTTP Method: `GET`
- Endpoint: `/pulse/daily`

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

result = sdk.team_pulse.get_daily_pulse()

print(result)
```

## list_triggers

- HTTP Method: `GET`
- Endpoint: `/pulse/triggers`

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

result = sdk.team_pulse.list_triggers()

print(result)
```
