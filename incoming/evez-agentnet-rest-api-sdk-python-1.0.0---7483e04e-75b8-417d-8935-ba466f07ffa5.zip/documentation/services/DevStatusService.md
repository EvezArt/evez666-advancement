# DevStatusService

A list of all methods in the `DevStatusService` service. Click on the method name to view detailed information about that method.

| Methods                                                 | Description |
| :------------------------------------------------------ | :---------- |
| [list_issues](#list_issues)                             |             |
| [create_pr](#create_pr)                                 |             |
| [weekly_engineering_digest](#weekly_engineering_digest) |             |

## list_issues

- HTTP Method: `GET`
- Endpoint: `/dev/issues`

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

result = sdk.dev_status.list_issues()

print(result)
```

## create_pr

- HTTP Method: `POST`
- Endpoint: `/dev/prs`

**Parameters**

| Name         | Type                                            | Required | Description       |
| :----------- | :---------------------------------------------- | :------- | :---------------- |
| request_body | [CreatePrRequest](../models/CreatePrRequest.md) | ✅       | The request body. |

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment
from evez_agentnet_rest_api_sdk.models import CreatePrRequest

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

request_body = CreatePrRequest(
    issue_id="iss_1",
    branch="fix/webhooks"
)

result = sdk.dev_status.create_pr(request_body=request_body)

print(result)
```

## weekly_engineering_digest

- HTTP Method: `GET`
- Endpoint: `/dev/weekly-digest`

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

result = sdk.dev_status.weekly_engineering_digest()

print(result)
```
