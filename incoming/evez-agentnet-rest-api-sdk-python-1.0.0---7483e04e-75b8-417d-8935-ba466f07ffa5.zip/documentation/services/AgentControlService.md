# AgentControlService

A list of all methods in the `AgentControlService` service. Click on the method name to view detailed information about that method.

| Methods                                   | Description |
| :---------------------------------------- | :---------- |
| [schedule_command](#schedule_command)     |             |
| [agent_state_change](#agent_state_change) |             |

## schedule_command

- HTTP Method: `POST`
- Endpoint: `/agents/control/schedule`

**Parameters**

| Name         | Type                                                          | Required | Description       |
| :----------- | :------------------------------------------------------------ | :------- | :---------------- |
| request_body | [ScheduleCommandRequest](../models/ScheduleCommandRequest.md) | ✅       | The request body. |

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment
from evez_agentnet_rest_api_sdk.models import ScheduleCommandRequest

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

request_body = ScheduleCommandRequest(
    role="editor",
    command="review-drafts",
    run_at="2024-06-09T09:00:00Z"
)

result = sdk.agent_control.schedule_command(request_body=request_body)

print(result)
```

## agent_state_change

- HTTP Method: `POST`
- Endpoint: `/agents/control/state`

**Parameters**

| Name         | Type                                                            | Required | Description       |
| :----------- | :-------------------------------------------------------------- | :------- | :---------------- |
| request_body | [AgentStateChangeRequest](../models/AgentStateChangeRequest.md) | ✅       | The request body. |

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment
from evez_agentnet_rest_api_sdk.models import AgentStateChangeRequest

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

request_body = AgentStateChangeRequest(
    agent_id="agent_1",
    state="idle"
)

result = sdk.agent_control.agent_state_change(request_body=request_body)

print(result)
```
