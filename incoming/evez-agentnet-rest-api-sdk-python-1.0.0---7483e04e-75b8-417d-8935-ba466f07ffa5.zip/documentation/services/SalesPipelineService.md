# SalesPipelineService

A list of all methods in the `SalesPipelineService` service. Click on the method name to view detailed information about that method.

| Methods                   | Description |
| :------------------------ | :---------- |
| [list_deals](#list_deals) |             |
| [move_deal](#move_deal)   |             |

## list_deals

- HTTP Method: `GET`
- Endpoint: `/sales/deals`

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

result = sdk.sales_pipeline.list_deals()

print(result)
```

## move_deal

- HTTP Method: `POST`
- Endpoint: `/sales/deals/move`

**Parameters**

| Name         | Type                                            | Required | Description       |
| :----------- | :---------------------------------------------- | :------- | :---------------- |
| request_body | [MoveDealRequest](../models/MoveDealRequest.md) | ✅       | The request body. |

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment
from evez_agentnet_rest_api_sdk.models import MoveDealRequest

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

request_body = MoveDealRequest(
    deal_id="deal_1",
    stage="negotiation"
)

result = sdk.sales_pipeline.move_deal(request_body=request_body)

print(result)
```
