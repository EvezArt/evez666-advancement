# CoreWorkspaceService

A list of all methods in the `CoreWorkspaceService` service. Click on the method name to view detailed information about that method.

| Methods                             | Description |
| :---------------------------------- | :---------- |
| [workspace_state](#workspace_state) |             |

## workspace_state

- HTTP Method: `GET`
- Endpoint: `/workspace/state`

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

result = sdk.core_workspace.workspace_state()

print(result)
```
