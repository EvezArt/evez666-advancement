# WorkspaceAssistantService

A list of all methods in the `WorkspaceAssistantService` service. Click on the method name to view detailed information about that method.

| Methods                                     | Description |
| :------------------------------------------ | :---------- |
| [suggest_next_action](#suggest_next_action) |             |

## suggest_next_action

- HTTP Method: `POST`
- Endpoint: `/workspace/assistant/next-action`

**Parameters**

| Name         | Type                                                              | Required | Description       |
| :----------- | :---------------------------------------------------------------- | :------- | :---------------- |
| request_body | [SuggestNextActionRequest](../models/SuggestNextActionRequest.md) | ✅       | The request body. |

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment
from evez_agentnet_rest_api_sdk.models import SuggestNextActionRequest

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

request_body = SuggestNextActionRequest(
    user_id="user_1",
    context="editing-draft"
)

result = sdk.workspace_assistant.suggest_next_action(request_body=request_body)

print(result)
```
