# ResearchAgentService

A list of all methods in the `ResearchAgentService` service. Click on the method name to view detailed information about that method.

| Methods                                     | Description |
| :------------------------------------------ | :---------- |
| [list_questions](#list_questions)           |             |
| [submit_finding](#submit_finding)           |             |
| [daily_morning_brief](#daily_morning_brief) |             |

## list_questions

- HTTP Method: `GET`
- Endpoint: `/research/questions`

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

result = sdk.research_agent.list_questions()

print(result)
```

## submit_finding

- HTTP Method: `POST`
- Endpoint: `/research/findings`

**Parameters**

| Name         | Type                                                      | Required | Description       |
| :----------- | :-------------------------------------------------------- | :------- | :---------------- |
| request_body | [SubmitFindingRequest](../models/SubmitFindingRequest.md) | ✅       | The request body. |

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment
from evez_agentnet_rest_api_sdk.models import SubmitFindingRequest

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

request_body = SubmitFindingRequest(
    question_id="q_1",
    finding="Agent orchestration automates multi-agent tasks"
)

result = sdk.research_agent.submit_finding(request_body=request_body)

print(result)
```

## daily_morning_brief

- HTTP Method: `GET`
- Endpoint: `/research/briefs/daily`

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

result = sdk.research_agent.daily_morning_brief()

print(result)
```
