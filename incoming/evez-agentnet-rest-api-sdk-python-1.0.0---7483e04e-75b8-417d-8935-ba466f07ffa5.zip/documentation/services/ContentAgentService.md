# ContentAgentService

A list of all methods in the `ContentAgentService` service. Click on the method name to view detailed information about that method.

| Methods                                     | Description |
| :------------------------------------------ | :---------- |
| [list_ideas](#list_ideas)                   |             |
| [create_idea](#create_idea)                 |             |
| [draft_workflow](#draft_workflow)           |             |
| [weekly_content_plan](#weekly_content_plan) |             |

## list_ideas

- HTTP Method: `GET`
- Endpoint: `/content/ideas`

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

result = sdk.content_agent.list_ideas()

print(result)
```

## create_idea

- HTTP Method: `POST`
- Endpoint: `/content/ideas`

**Parameters**

| Name         | Type                                                | Required | Description       |
| :----------- | :-------------------------------------------------- | :------- | :---------------- |
| request_body | [CreateIdeaRequest](../models/CreateIdeaRequest.md) | ✅       | The request body. |

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment
from evez_agentnet_rest_api_sdk.models import CreateIdeaRequest

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

request_body = CreateIdeaRequest(
    title="New content workflow",
    description="Automation suggestions"
)

result = sdk.content_agent.create_idea(request_body=request_body)

print(result)
```

## draft_workflow

- HTTP Method: `POST`
- Endpoint: `/content/drafts`

**Parameters**

| Name         | Type                                                      | Required | Description       |
| :----------- | :-------------------------------------------------------- | :------- | :---------------- |
| request_body | [DraftWorkflowRequest](../models/DraftWorkflowRequest.md) | ✅       | The request body. |

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment
from evez_agentnet_rest_api_sdk.models import DraftWorkflowRequest

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

request_body = DraftWorkflowRequest(
    idea_id="idea_1"
)

result = sdk.content_agent.draft_workflow(request_body=request_body)

print(result)
```

## weekly_content_plan

- HTTP Method: `GET`
- Endpoint: `/content/plans/weekly`

**Return Type**

`Any`

**Example Usage Code Snippet**

```python
from evez_agentnet_rest_api_sdk import EvezAgentnetRestApiSdk, Environment

sdk = EvezAgentnetRestApiSdk(
    base_url=Environment.DEFAULT.value,
    timeout=10000
)

result = sdk.content_agent.weekly_content_plan()

print(result)
```
