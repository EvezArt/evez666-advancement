---
name: openclaw-evezos-agent
description: Interact with OpenClaw + EVEZOS gateway to execute device commands (camera, microphone, speaker, notifications, system info, shell) and manage EVEZOS chain operations (verify, manifest, pending, confirm, reject, history, nodes, health). Use this skill to control connected devices and monitor the EVEZOS chain.
---

# Openclaw Evezos Agent

## Overview

This skill provides an interface to interact with the OpenClaw + EVEZOS gateway, enabling control over connected devices and management of the EVEZOS blockchain operations.

## Usage

This skill can be used in two primary modes:

### Interactive Loop

Run the agent in an interactive loop where you can continuously enter commands:

```bash
python3 agent.py
```

### One-Shot Execution

Execute a single command directly from the command line:

```bash
python3 agent.py "<your command here>"
```

**Examples:**

- `python3 agent.py "take a photo"`
- `python3 agent.py "where am i"`
- `python3 agent.py "say hello world"`
- `python3 agent.py "check my chain"`
- `python3 agent.py "send a notification: meeting in 5"`
- `python3 agent.py "list nodes"`
- `python3 agent.py "verify integrity"`
- `python3 agent.py "listen for 8 seconds"`
- `python3 agent.py "confirm <action_id>"`
- `python3 agent.py "reject <action_id>"`
- `python3 agent.py "show pending"`
- `python3 agent.py "manifest"`
- `python3 agent.py "run: ls -la ~/Downloads"`

## Environment Variables

The following optional environment variables can be set to configure the agent:

| Variable       | Description                                    | Default Value |
|----------------|------------------------------------------------|---------------|
| `GATEWAY_HOST` | Host of the OpenClaw gateway                   | `localhost`   |
| `GATEWAY_PORT` | Port of the gateway                            | `8888`        |
| `AGENT_TOKEN`  | Controller token                               | `devtoken`    |
| `AGENT_NODE`   | Default target node ID (empty for auto-pick) | `""`          |

## Commands

This skill supports the following commands, categorized by their function:

### Device Commands

These commands interact with connected devices through the OpenClaw gateway:

| Command               | Action Key         | Description                                                                 | Risk Score |
|-----------------------|--------------------|-----------------------------------------------------------------------------|------------|
| `take a photo`        | `camera.capture`   | Captures an image from the device's camera.                                 | 0.80       |
| `where am i`          | `location.get`     | Retrieves the device's current location (GPS coordinates).                  | 0.40       |
| `say <text>`          | `speaker.speak`    | Makes the device speak the provided text.                                   | 0.20       |
| `listen [for N s]`    | `microphone.listen`| Records audio from the device's microphone for a specified duration (default 8s). | 0.75       |
| `screenshot`          | `screen.capture`   | Captures a screenshot of the device's display.                              | 0.70       |
| `send a notification: <message>` | `notifications.send` | Sends a notification with the specified message to the device.              | 0.20       |
| `system info`         | `system.info`      | Retrieves system information from the device.                               | 0.05       |
| `run: <command>`      | `shell`            | Executes a shell command on the device (requires confirmation).             | 0.95       |

### EVEZOS / Chain Operations

These commands interact with the EVEZOS blockchain and agent operations:

| Command               | Action Key         | Description                                                                 |
|-----------------------|--------------------|-----------------------------------------------------------------------------|
| `verify`              | `verify`           | Checks the integrity of the EVEZOS chain.                                   |
| `manifest`            | `manifest`         | Builds an Ed25519-signed manifest of the chain.                             |
| `show pending`        | `pending_list`     | Lists actions that are quarantined and awaiting confirmation.               |
| `confirm <action_id>` | `confirm`          | Approves a quarantined command with the given action ID.                    |
| `reject <action_id>`  | `reject`           | Rejects a quarantined command with the given action ID.                     |
| `history`             | `history`          | Shows recent events recorded on the EVEZOS chain.                           |
| `nodes`               | `nodes`            | Lists known connected nodes.                                                |
| `health`              | `health`           | Checks the status of the OpenClaw gateway.                                  |

## Local Risk Fallback

When the OpenClaw gateway is unreachable, the agent uses a local risk fallback mechanism to determine command execution. Commands are scored for risk, and if the risk exceeds a certain threshold or the command is not explicitly allowed, it will be quarantined.

### Risk Scores

| Command               | Risk Score |
|-----------------------|------------|
| `system.info`         | 0.05       |
| `notifications.send`  | 0.20       |
| `speaker.speak`       | 0.20       |
| `location.get`        | 0.40       |
| `screen.capture`      | 0.70       |
| `microphone.listen`   | 0.75       |
| `camera.capture`      | 0.80       |
| `shell`               | 0.95       |

### Quarantine Threshold

Commands with a risk score of **0.60 or higher** are quarantined if the gateway is offline.

### Allowed Commands (Bypass Quarantine Offline)

The following commands are allowed to dispatch immediately even if the gateway is offline and their risk score is below the threshold:

- `system.info`
- `notifications.send`
- `speaker.speak`
- `location.get`

## Resources

This skill includes the `agent.py` script, which is the core executable for interacting with the OpenClaw + EVEZOS gateway.

### scripts/
- `agent.py`: The main script for the OpenClaw + EVEZOS Task Agent.

---

**Note:** The `references/` and `templates/` directories are not used by this skill and can be removed.
