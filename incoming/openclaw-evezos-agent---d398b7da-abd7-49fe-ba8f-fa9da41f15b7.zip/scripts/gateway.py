
import json
import time
import uuid
import hashlib
from flask import Flask, request, jsonify

app = Flask(__name__)

# In-memory state for the mock gateway
chain = []
pending_actions = {}
nodes = {
    "demo_node": {"paired": True, "type": "virtual_device", "status": "online"}
}

def get_chain_hash():
    if not chain:
        return "0" * 64
    return hashlib.sha256(json.dumps(chain[-1]).encode()).hexdigest()

@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        "status": "ok",
        "evezos": "active",
        "risk_scoring": "enabled",
        "ed25519": "ready",
        "version": "1.0.0-mock"
    })

@app.route('/api/nodes', methods=['GET'])
def get_nodes():
    return jsonify({"ok": True, "nodes": nodes})

@app.route('/api/chain', methods=['GET'])
def get_chain():
    return jsonify({"ok": True, "last_50": chain[-50:]})

@app.route('/api/verify', methods=['GET'])
def verify_chain():
    # Simple mock verification
    return jsonify({
        "ok": True, 
        "steps": len(chain), 
        "root_hash": get_chain_hash(),
        "issues": []
    })

@app.route('/api/manifest', methods=['GET'])
def get_manifest():
    root_hash = get_chain_hash()
    return jsonify({
        "ok": True,
        "spine_entries": len(chain),
        "chain_ok": True,
        "root_hash": root_hash,
        "ed25519_signature_b64": "mock_sig_" + root_hash[:16],
        "public_key_b64": "mock_pub_key_evezos_2026"
    })

@app.route('/api/pending', methods=['GET'])
def get_pending():
    return jsonify({"ok": True, "pending": list(pending_actions.values())})

@app.route('/api/simulate', methods=['POST'])
def simulate():
    data = request.json
    cmd_type = data.get("type")
    target = data.get("target")
    payload = data.get("payload", {})
    
    # Mock risk scoring
    risk_scores = {
        "system.info": 0.05,
        "notifications.send": 0.20,
        "speaker.speak": 0.20,
        "location.get": 0.40,
        "screen.capture": 0.70,
        "microphone.listen": 0.75,
        "camera.capture": 0.80,
        "shell": 0.95
    }
    risk = risk_scores.get(cmd_type, 0.50)
    threshold = 0.60
    
    quarantined = risk >= threshold
    action_id = f"act_{cmd_type.replace('.', '_')}_{str(uuid.uuid4())[:8]}"
    
    response = {
        "ok": True,
        "riskScore": risk,
        "quarantined": quarantined,
        "actionId": action_id if quarantined else None,
        "chain_step": len(chain) + 1,
        "chain_hash": hashlib.sha256(str(time.time()).encode()).hexdigest()
    }
    
    if quarantined:
        pending_actions[action_id] = {
            "action_id": action_id,
            "command": {"type": cmd_type, "payload": payload},
            "target_node": target,
            "risk": risk,
            "timestamp": time.time()
        }
    else:
        # Record in chain immediately
        chain.append({
            "_chain_step": len(chain) + 1,
            "_chain_hash": response["chain_hash"],
            "type": cmd_type,
            "payload": {**payload, "deviceId": target, "eventType": "dispatch"}
        })
        response["result"] = {"status": "success", "message": f"Executed {cmd_type}"}
        
    return jsonify(response)

@app.route('/api/confirm', methods=['POST'])
def confirm():
    data = request.json
    action_id = data.get("actionId")
    approved = data.get("approved")
    
    if action_id not in pending_actions:
        return jsonify({"ok": False, "error": "Action not found"}), 404
        
    action = pending_actions.pop(action_id)
    if approved:
        new_hash = hashlib.sha256(str(time.time()).encode()).hexdigest()
        chain.append({
            "_chain_step": len(chain) + 1,
            "_chain_hash": new_hash,
            "type": action["command"]["type"],
            "payload": {**action["command"]["payload"], "deviceId": action["target_node"], "eventType": "confirmed_dispatch"}
        })
        return jsonify({"ok": True, "message": "Action approved"})
    else:
        return jsonify({"ok": True, "message": "Action rejected"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8888)
