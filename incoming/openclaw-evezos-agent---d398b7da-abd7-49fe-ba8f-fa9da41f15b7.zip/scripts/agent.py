#!/usr/bin/env python3
"""
OpenClaw + EVEZOS Task Agent
─────────────────────────────
Just tell it what you want.  It figures out the rest.

Usage (interactive loop):
    python3 agent.py

Usage (one-shot):
    python3 agent.py "take a photo"
    python3 agent.py "where am i"
    python3 agent.py "say hello world"
    python3 agent.py "check my chain"
    python3 agent.py "send a notification: meeting in 5"
    python3 agent.py "list nodes"
    python3 agent.py "verify integrity"
    python3 agent.py "listen for 8 seconds"
    python3 agent.py "confirm <action_id>"
    python3 agent.py "reject <action_id>"
    python3 agent.py "show pending"
    python3 agent.py "manifest"
    python3 agent.py "run: ls -la ~/Downloads"   # high-risk, will ask first

Environment (all optional, sensible defaults):
    GATEWAY_HOST   host of the OpenClaw gateway (default: localhost)
    GATEWAY_PORT   port of the gateway          (default: 8888)
    AGENT_TOKEN    controller token             (default: devtoken)
    AGENT_NODE     default target node ID       (default: auto = first paired node)
"""
from __future__ import annotations

import json, os, re, sys, time, uuid
import urllib.request, urllib.error
from typing import Any, Dict, List, Optional, Tuple

# ── Config ────────────────────────────────────────────────────────────────────
GATEWAY_HOST = os.environ.get("GATEWAY_HOST", "localhost")
GATEWAY_PORT = int(os.environ.get("GATEWAY_PORT", "8888"))
AGENT_TOKEN  = os.environ.get("AGENT_TOKEN",  "devtoken")
DEFAULT_NODE = os.environ.get("AGENT_NODE",   "")   # empty = auto-pick first paired
BASE_URL     = f"http://{GATEWAY_HOST}:{GATEWAY_PORT}"

# ── ANSI colours (disabled if not a TTY) ─────────────────────────────────────
_TTY = sys.stdout.isatty()
def _c(code: str, text: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _TTY else text

def green(t):  return _c("32", t)
def red(t):    return _c("31", t)
def yellow(t): return _c("33", t)
def blue(t):   return _c("34", t)
def cyan(t):   return _c("36", t)
def bold(t):   return _c("1",  t)
def dim(t):    return _c("2",  t)

# ── HTTP helpers ──────────────────────────────────────────────────────────────
def _get(path: str) -> Dict:
    try:
        with urllib.request.urlopen(f"{BASE_URL}{path}", timeout=8) as r:
            return json.loads(r.read())
    except urllib.error.URLError as e:
        return {"ok": False, "error": str(e), "_unreachable": True}

def _post(path: str, body: Dict) -> Dict:
    data = json.dumps(body).encode()
    req  = urllib.request.Request(
        f"{BASE_URL}{path}", data=data,
        headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            return json.loads(r.read())
    except urllib.error.URLError as e:
        return {"ok": False, "error": str(e), "_unreachable": True}

# ── Intent parser ─────────────────────────────────────────────────────────────
# Each rule is (regex_pattern, action_key, capture_group_for_arg).
# Patterns are tried in order — first match wins.
_RULES: List[Tuple[str, str, Optional[int]]] = [
    # ── device / phone commands ───────────────────────────────────────────────
    (r"\b(photo|picture|camera|capture|snapshot)\b",         "camera.capture",        None),
    (r"\b(screenshot|screen\s*capture|screen)\b",            "screen.capture",        None),
    (r"\b(where\s+am\s+i|location|gps|coords?|position)\b",  "location.get",          None),
    (r"\b(say|speak|tts|voice|announce)\s+(.+)",             "speaker.speak",         2),
    (r"\b(listen|mic|microphone|hear|record)\b.*?(\d+)\s*s", "microphone.listen_n",   2),
    (r"\b(listen|mic|microphone|hear|record)\b",             "microphone.listen",     None),
    (r"\b(notify|notification|alert|ping)\s*:?\s*(.+)",      "notifications.send",    2),
    (r"\b(notify|notification|alert|ping)\b",                "notifications.send",    None),
    (r"\b(sys|system\s*info|device\s*info|info)\b",          "system.info",           None),
    # ── shell ─────────────────────────────────────────────────────────────────
    (r"\brun\s*:?\s*(.+)",                                   "shell",                 1),
    (r"\bexec(ute)?\s*:?\s*(.+)",                            "shell",                 2),
    (r"\bbash\s*:?\s*(.+)",                                  "shell",                 1),
    # ── EVEZOS / agent ops ────────────────────────────────────────────────────
    (r"\b(verify|check\s+chain|chain\s+ok|integrity)\b",     "verify",                None),
    (r"\b(manifest|sign|export\s+manifest)\b",               "manifest",              None),
    (r"\b(pending|confirm\w*\s+list|show\s+pending)\b",      "pending_list",          None),
    (r"\bconfirm\s+(\S+)",                                   "confirm",               1),
    (r"\breject\s+(\S+)",                                     "reject",                1),
    (r"\b(nodes?|list\s+nodes?|who.s\s+connected)\b",        "nodes",                 None),
    (r"\b(health|status|ping\s+server)\b",                   "health",                None),
    (r"\b(history|log|events?)\b",                           "history",               None),
    (r"\bhelp\b",                                            "help",                  None),
]

def parse_intent(prompt: str) -> Tuple[str, Optional[str]]:
    """
    Return (action_key, arg_string_or_None).
    Tries each rule in order; falls back to 'unknown'.
    """
    text = prompt.strip()
    lower = text.lower()
    for pattern, action, group in _RULES:
        m = re.search(pattern, lower, re.IGNORECASE)
        if m:
            arg = None
            if group is not None:
                # Capture arg from the original (non-lowered) text so casing is preserved
                m2 = re.search(pattern, text, re.IGNORECASE)
                if m2 and group <= len(m2.groups()):
                    arg = m2.group(group)
            return action, arg
    return "unknown", text   # pass original text as arg for fallback message

# ── Gateway interaction ───────────────────────────────────────────────────────
def _first_paired_node() -> Optional[str]:
    """Ask the gateway for the first paired node, or fall back to DEFAULT_NODE."""
    if DEFAULT_NODE:
        return DEFAULT_NODE
    data = _get("/api/nodes") if not _get("/api/nodes").get("_unreachable") else {}
    for nid, n in (data.get("nodes") or {}).items():
        if n.get("paired"):
            return nid
    return None

def _simulate(cmd_type: str, target: str, payload: Dict) -> Dict:
    """
    POST /api/simulate — the gateway scores, gates, and records in the chain.
    Returns the gateway's response verbatim.
    """
    return _post("/api/simulate", {
        "type":    cmd_type,
        "target":  target,
        "payload": payload,
    })

def _confirm_action(action_id: str, approved: bool) -> Dict:
    return _post("/api/confirm", {"actionId": action_id, "approved": approved})

# ── Dispatch each action ──────────────────────────────────────────────────────
def _run_action(action: str, arg: Optional[str], prompt: str) -> None:
    node = _first_paired_node() or "demo_node"

    # ── Health / meta ─────────────────────────────────────────────────────────
    if action == "health":
        r = _get("/health")
        if r.get("_unreachable"):
            _out_error(f"Gateway unreachable at {BASE_URL}")
            return
        _out_ok("Gateway is up", {
            "url":           BASE_URL,
            "evezos_chain":  r.get("evezos",  "?"),
            "risk_scoring":  r.get("risk_scoring", "?"),
            "ed25519":       r.get("ed25519", "?"),
        })

    elif action == "nodes":
        r = _get("/api/nodes") if not _get("/api/nodes").get("_unreachable") else _get("/health")
        # Nodes come from chain / registry — try best-effort
        chain = _get("/api/chain")
        # Extract unique deviceIds from the chain
        seen = {}
        for rec in (chain.get("last_50") or []):
            p = rec.get("payload", {})
            did = p.get("deviceId")
            if did and did not in seen:
                seen[did] = p.get("eventType", "seen_in_chain")
        if seen:
            _out_ok(f"Nodes seen in chain ({len(seen)})", seen)
        else:
            _out_info("No nodes found in chain yet. Connect a node to see activity.")

    elif action == "history":
        r = _get("/api/chain")
        records = r.get("last_50") or []
        if not records:
            _out_info("Chain is empty — no events recorded yet.")
            return
        _out_ok(f"Last {len(records)} chain events", None)
        for rec in records[-10:]:  # show 10 most recent
            step  = rec.get("_chain_step", "?")
            h     = str(rec.get("_chain_hash", ""))[:12]
            etype = rec.get("payload", {}).get("eventType", rec.get("type", "?"))
            print(f"  {dim(f'#{step}')}  {cyan(etype):<32} {dim(h+'…')}")

    elif action == "verify":
        r = _get("/api/verify")
        if r.get("_unreachable"):
            _out_error("Gateway unreachable — running local chain check is not available in this mode.")
            return
        if r.get("ok"):
            _out_ok(f"Chain intact — {r.get('steps', '?')} steps, root …{str(r.get('root_hash',''))[-12:]}", None)
        else:
            _out_error(f"Chain BROKEN — issues: {r.get('issues')}")

    elif action == "manifest":
        r = _get("/api/manifest")
        if r.get("_unreachable"):
            _out_error("Gateway unreachable")
            return
        _out_ok("Signed manifest", {
            "entries":      r.get("spine_entries"),
            "chain_ok":     r.get("chain_ok"),
            "root_hash":    str(r.get("root_hash", ""))[:32] + "…",
            "ed25519_sig":  str(r.get("ed25519_signature_b64", ""))[:32] + "…",
            "pub_key_fp":   str(r.get("public_key_b64", ""))[:20] + "…",
        })

    elif action == "pending_list":
        r = _get("/api/pending")
        items = r.get("pending") or []
        if not items:
            _out_info("No pending confirmations.")
            return
        _out_ok(f"{len(items)} pending action(s):", None)
        for item in items:
            risk = float(item.get("risk", 0))
            icon = "🔴" if risk >= 0.80 else "🟡"
            print(f"  {icon}  {bold(item.get('action_id','?'))}")
            print(f"     command : {item.get('command',{}).get('type','?')}")
            print(f"     target  : {item.get('target_node','?')}")
            print(f"     risk    : {risk:.2f}")
            print(f"     → confirm {item.get('action_id','?')}")

    elif action == "confirm":
        if not arg:
            _out_error("Provide an action_id.  e.g.  confirm act_camera_1234")
            return
        r = _confirm_action(arg.strip(), approved=True)
        if r.get("ok"):
            _out_ok(f"Action {arg} approved and dispatched.", None)
        else:
            _out_error(f"Confirm failed: {r.get('error', r)}")

    elif action == "reject":
        if not arg:
            _out_error("Provide an action_id.  e.g.  reject act_camera_1234")
            return
        r = _confirm_action(arg.strip(), approved=False)
        if r.get("ok"):
            _out_ok(f"Action {arg} rejected.", None)
        else:
            _out_error(f"Reject failed: {r.get('error', r)}")

    # ── Device commands routed through risk gate ──────────────────────────────
    elif action == "system.info":
        _dispatch_cmd("system.info", node, {})

    elif action == "location.get":
        _dispatch_cmd("location.get", node, {})

    elif action == "camera.capture":
        _dispatch_cmd("camera.capture", node, {})

    elif action == "screen.capture":
        _dispatch_cmd("screen.capture", node, {})

    elif action == "speaker.speak":
        text = arg or "Hello from the OpenClaw agent."
        _dispatch_cmd("speaker.speak", node, {"text": text})

    elif action == "microphone.listen":
        _dispatch_cmd("microphone.listen", node, {"lang": "en-US", "timeoutMs": 8000})

    elif action == "microphone.listen_n":
        ms = int(arg) * 1000 if arg else 8000
        _dispatch_cmd("microphone.listen", node, {"lang": "en-US", "timeoutMs": ms})

    elif action == "notifications.send":
        body = arg or "Message from OpenClaw agent"
        _dispatch_cmd("notifications.send", node, {"title": "OpenClaw", "body": body})

    elif action == "shell":
        if not arg:
            _out_error("Provide a shell command.  e.g.  run: ls -la")
            return
        # Shell is always high-risk — ask for confirmation before even sending
        print(yellow(f"  ⚠  Shell command: {bold(arg)}"))
        print(dim("     Risk score: 0.95  —  this will be quarantined by the EVEZ gate."))
        try:
            answer = input("     Send anyway? [y/N] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer = "n"
        if answer != "y":
            _out_info("Cancelled.")
            return
        _dispatch_cmd("shell", node, {"cmd": arg})

    elif action == "help":
        _print_help()

    else:
        # Unknown intent — show suggestions
        _out_info(f"Didn't understand: {bold(repr(prompt))}")
        print(dim("  Try one of these:"))
        examples = [
            "take a photo", "where am i", "say hello world",
            "send a notification: meeting in 5",
            "listen for 10 seconds", "system info",
            "verify", "manifest", "show pending",
            "confirm <action_id>", "reject <action_id>",
            "run: ls ~/Downloads", "nodes", "history", "health",
        ]
        for ex in examples:
            print(f"  {dim('·')} {ex}")


def _dispatch_cmd(cmd_type: str, node: str, payload: Dict) -> None:
    """
    Send command through the gateway's /api/simulate endpoint.
    That endpoint scores the risk, optionally quarantines, records in chain, and responds.
    """
    r = _simulate(cmd_type, node, payload)

    if r.get("_unreachable"):
        # Gateway is offline — show what *would* happen using local risk table
        from _local_risk import score as local_score
        risk, gated = local_score(cmd_type)
        _out_info(f"Gateway offline — local preview only")
        print(f"  command  : {bold(cmd_type)}")
        print(f"  target   : {node}")
        print(f"  risk     : {_risk_icon(risk)} {risk:.2f}")
        print(f"  outcome  : {'would be QUARANTINED' if gated else 'would DISPATCH immediately'}")
        return

    chain_step = r.get("chain_step", "?")
    chain_hash = str(r.get("chain_hash", ""))[:16]
    risk       = float(r.get("riskScore", 0))
    quarantined = r.get("quarantined", False)

    if quarantined:
        action_id = r.get("actionId", "?")
        print(f"\n  {yellow('⚠  Queued for confirmation')}")
        print(f"  command  : {bold(cmd_type)}")
        print(f"  risk     : {_risk_icon(risk)} {yellow(f'{risk:.2f}')}")
        print(f"  action   : {cyan(action_id)}")
        print(f"  chain    : step {chain_step}  {dim(chain_hash+'…')}")
        print(f"\n  To approve:  {bold(f'confirm {action_id}')}")
        print(f"  To reject:   {bold(f'reject {action_id}')}")
    else:
        result = r.get("result", {})
        _out_ok(f"Dispatched — {cmd_type}", {
            "risk":        f"{_risk_icon(risk)} {risk:.2f}  (below gate)",
            "chain_step":  chain_step,
            "chain_hash":  chain_hash + "…",
            **(result if isinstance(result, dict) else {"result": result}),
        })

def _risk_icon(risk: float) -> str:
    if risk >= 0.80: return "🔴"
    if risk >= 0.60: return "🟡"
    return "🟢"

# ── Output helpers ─────────────────────────────────────────────────────────────
def _out_ok(title: str, data: Optional[Dict]) -> None:
    print(f"\n  {green('✓')}  {bold(title)}")
    if data:
        for k, v in data.items():
            print(f"  {dim(f'{k:<14}')} {v}")

def _out_error(msg: str) -> None:
    print(f"\n  {red('✗')}  {bold(msg)}")

def _out_info(msg: str) -> None:
    print(f"\n  {blue('·')}  {msg}")

# ── Help ──────────────────────────────────────────────────────────────────────
def _print_help() -> None:
    print(f"""
  {bold('OpenClaw + EVEZOS Task Agent')}
  {dim('Just describe what you want. Examples:')}

  {cyan('Device commands')}
    take a photo          →  camera.capture   {dim('(risk 0.80 — needs confirm)')}
    where am i            →  location.get     {dim('(risk 0.40 — dispatches now)')}
    say hello world       →  speaker.speak    {dim('(risk 0.20)')}
    listen for 10 seconds →  microphone.listen {dim('(risk 0.75 — needs confirm)')}
    screenshot            →  screen.capture   {dim('(risk 0.70 — needs confirm)')}
    send a notification: meeting in 5         {dim('(risk 0.20)')}
    system info           →  system.info      {dim('(risk 0.05)')}
    run: ls ~/Downloads   →  shell            {dim('(risk 0.95 — always asks you first)')}

  {cyan('EVEZOS / chain ops')}
    verify                →  check chain integrity
    manifest              →  build Ed25519-signed manifest
    show pending          →  list quarantined actions
    confirm <action_id>   →  approve a quarantined command
    reject <action_id>    →  reject a quarantined command
    history               →  show recent chain events
    nodes                 →  list known nodes
    health                →  gateway status

  {cyan('Interactive mode')}
    python3 agent.py      {dim('(REPL loop — type prompts, Ctrl-C to exit)')}

  {cyan('One-shot mode')}
    python3 agent.py "take a photo"
""")

# ── REPL ──────────────────────────────────────────────────────────────────────
def _repl() -> None:
    print(f"\n  {bold('OpenClaw + EVEZOS Agent')}  {dim(f'→ {BASE_URL}')}")
    print(f"  {dim('Type what you want. Type  help  for examples. Ctrl-C to exit.')}\n")
    while True:
        try:
            raw = input(f"  {cyan('agent')} {dim('›')} ").strip()
        except (EOFError, KeyboardInterrupt):
            print(f"\n  {dim('bye.')}\n")
            break
        if not raw:
            continue
        if raw.lower() in ("exit", "quit", "q"):
            print(f"\n  {dim('bye.')}\n")
            break
        action, arg = parse_intent(raw)
        _run_action(action, arg, raw)
        print()


# ── Local risk fallback (used when gateway is offline) ───────────────────────
class _local_risk:
    SCORES = {
        "system.info":0.05,"notifications.send":0.20,"speaker.speak":0.20,
        "location.get":0.40,"screen.capture":0.70,"microphone.listen":0.75,
        "camera.capture":0.80,"shell":0.95,
    }
    THRESHOLD   = 0.60
    ALLOWED     = {"system.info","notifications.send","speaker.speak","location.get"}

    @classmethod
    def score(cls, cmd_type: str) -> Tuple[float, bool]:
        risk  = cls.SCORES.get(cmd_type, 0.30)
        gated = risk >= cls.THRESHOLD or cmd_type not in cls.ALLOWED
        return risk, gated


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if len(sys.argv) > 1:
        # One-shot: join all args into one prompt string
        prompt = " ".join(sys.argv[1:])
        action, arg = parse_intent(prompt)
        _run_action(action, arg, prompt)
        print()
    else:
        _repl()
